-keepattributes Exceptions,InnerClasses,Signature,Deprecated,SourceFile,LineNumberTable,*Annotation*,EnclosingMethod
-dontwarn com.m4399.pierce.**

-repackageclasses com.m4399.pierce

# JNI RegisterNatives 反向依赖，R8 无法从 Java 调用图推导其可达性。
# 保留整类及成员以禁止 shrink，但允许名称继续按 native.mapping 参与混淆。
-keep,allowobfuscation class com.m4399.pierce.core.* {
    *;
}

# PierceConfig：保留类名 + disableHooks 字段名，其它成员全部混淆
-keep class com.m4399.pierce.core.PierceConfig {
    public static boolean debugLog;
    public static boolean debuggable;
    public static boolean disableHooks;
    public static android.content.Context context;
}

# Pierce 类：保留类名 + 4 个 hook 接口方法名，其它成员全部混淆
-keep class com.m4399.pierce.core.Pierce {
    public static com.m4399.pierce.core.callback.MethodHook$Unhook hook(java.lang.ClassLoader, java.lang.String, java.lang.String, com.m4399.pierce.core.callback.MethodHook);
    public static com.m4399.pierce.core.callback.MethodHook$Unhook hook(java.lang.Class, java.lang.String, com.m4399.pierce.core.callback.MethodHook);
    public static com.m4399.pierce.core.callback.MethodHook$Unhook hook(java.lang.reflect.Member, com.m4399.pierce.core.callback.MethodHook);
    public static com.m4399.pierce.core.callback.MethodHook$Unhook hook(java.lang.reflect.Member, com.m4399.pierce.core.callback.MethodHook, boolean);

    #排查问题接口用
    public static long getArtMethodEntryPointFromCompiledCode(java.lang.reflect.Member);
    public static java.lang.String getArtMethodEntryPointHexString(java.lang.reflect.Member,int);
     public static java.lang.String dump();
}

# MethodHook 是 hook 方法参数类型 + 外部继承实现，必须保留类与公共方法名
-keep class com.m4399.pierce.core.callback.MethodHook { public *; }
-keep class com.m4399.pierce.core.callback.MethodHook$Unhook { public *; }

# MethodReplacement 是 MethodHook 的子类，外部继承使用；保留 public 与 protected replaceCall
-keep class com.m4399.pierce.core.callback.MethodReplacement {
    public *;
    protected java.lang.Object replaceCall(com.m4399.pierce.core.Pierce$CallFrame);
}

# CallFrame 作为 MethodHook 回调参数对外暴露，保留类名和公共方法名
-keep class com.m4399.pierce.core.Pierce$CallFrame { public *; }


# Pierce.HandleCallWrapClass：生成 dex中的bridge调用依赖，保留类名和 handleCall 方法
# 防止同一版本 debug与release覆盖安装，造成崩溃
# 测机 华为荣耀7 Android 6 崩溃信息只有
# 2026-06-11 13:41:40.274  1019-1044  Process                 com.m4399.pierce.demo                I  Sending signal. PID: 1019 SIG: 9
-keep class com.m4399.pierce.core.Pierce$HandleCallWrapClass {
    public static java.lang.Object handleCall(java.lang.Object, java.lang.Object, java.lang.Object[]);
}