#--------------对外开发的接口不混淆--------------------#

-keep class com.m4399.pierce.**{*;}

# Pierce.HandleCallWrapClass：生成 dex中的bridge调用依赖，保留类名和 handleCall 方法
# 同一个版本的aar包一个函数hook只生成一个dex，dex 缓存到磁盘。不同混淆版本的app引入同一个版本的aar，会出问题
-keep class com.m4399.pierce.core.Pierce$HandleCallWrapClass {
    public static java.lang.Object handleCall(java.lang.Object, java.lang.Object, java.lang.Object[]);
}
