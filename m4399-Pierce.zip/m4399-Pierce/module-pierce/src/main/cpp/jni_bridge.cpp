//
// Created by canyie on 2020/3/18.
//
#include "NamedGen.h"
#include "jni_bridge.h"
#include "utils/macros.h"
#include "utils/scoped_local_ref.h"
#include "utils/log.h"

jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    JNIEnv* env;
    if (UNLIKELY(vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK)) {
        LOGE("GetEnv return error");
        return JNI_ERR;
    }

    {
        ScopedLocalClassRef Pine(env, com___m4399___pierce___core___PierceNative);
        if(env->ExceptionCheck()){
            env->ExceptionDescribe();
        }

        if (UNLIKELY(Pine.IsNull())) {
            LOGE("Pierce class is null, %s", com___m4399___pierce___core___PierceNative);
            return JNI_ERR;
        }
        if (UNLIKELY(!register_Pine(env, Pine.Get()))) {
            LOGE("Pierce RegisterNatives error");
            return JNI_ERR;
        }
    }

    {
        ScopedLocalClassRef Ruler(env, com___m4399___pierce___core___NativeMark);
        if (UNLIKELY(Ruler.IsNull())) {
            LOGE("Ruler class is null, %s",com___m4399___pierce___core___NativeMark);
            return JNI_ERR;
        }
        if (UNLIKELY(!register_Ruler(env, Ruler.Get()))) {
            LOGE("Ruler register fail");
            return JNI_ERR;
        }
    }

    return JNI_VERSION_1_6;
}