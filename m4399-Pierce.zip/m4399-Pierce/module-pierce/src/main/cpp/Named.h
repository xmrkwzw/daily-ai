#ifndef M4399_PLUGINGAME_NAMED_H
#define M4399_PLUGINGAME_NAMED_H

/**
 * 宏说明
 * O_BEGIN  混淆数据定义域 开始标记
 * O_END    混淆数据定义域 结束标记
 * 所有的混淆数据必须定义在 BEGIN 和 END 之间
 *
 * O_CLASS  定义类混淆（源类名Key[其中点运算符.转换成三个连续下划线 ___ ], 混淆后类名value[其中点运算符.转换成斜杠 / ]）
 * O_FUNC   定义方法混淆（源方法名key， 混淆后方法名）
 */
#define O_BEGIN
#define O_CLASS(_cls, _name) static const char* _cls = #_name ;
#define O_FIELD(_type, _name, _o_name) static const char* _type##_##_name = #_o_name;
#define O_INTERFACE(_cls, _name) static const char* _cls = #_name ;
#define O_FUNC(_ret, _func, _name, ...) static const char* _func = #_name;
#define O_END

#define init0(...) O_init0
#define enableFastNative(...) O_enableFastNative
#define getArtMethod(...) O_getArtMethod
#define hook0(...) O_hook0
#define hookReplace0(...) O_hookReplace0
#define compile0(...) O_compile0
#define decompile0(...) O_decompile0
#define disableJitInline0(...) O_disableJitInline0
#define setJitCompilationAllowed0(...) O_setJitCompilationAllowed0
#define disableProfileSaver0(...) O_disableProfileSaver0
#define syncMethodInfo(...) O_syncMethodInfo
#define getObject0(...) O_getObject0
#define getAddress0(...) O_getAddress0
#define setDebuggable0(...) O_setDebuggable0
#define disableHiddenApiPolicy0(...) O_disableHiddenApiPolicy0
#define currentArtThread0(...) O_currentArtThread0
#define makeClassesVisiblyInitialized(...) O_makeClassesVisiblyInitialized
#define getArtMethodEntryPointFromCompiledCode(...) O_getArtMethodEntryPointFromCompiledCode
#define getArtMethodEntryPointHexString(...) O_getArtMethodEntryPointHexString
#define generateDex(...) O_generateDex
#define setLogFilePath(...) O_setLogFilePath
#define writeLogToFile(...) O_writeLogToFile

#define m1(...) O_m1
#define m2(...) O_m2
#define m(...) O_m

O_BEGIN

// Pierce$HookRecord class
O_CLASS(com___m4399___pierce___core___Pierce$HookRecord, com/m4399/pierce/core/Pierce$HookRecord)
O_FIELD(long, trampoline, trampoline)

// class com.m4399.module_pine.core.PierceNative
O_CLASS(com___m4399___pierce___core___PierceNative, com/m4399/pierce/core/PierceNative)
O_FIELD(int, arch, arch)
O_FIELD(long, openElf, openElf)
O_FIELD(long, findElfSymbol, findElfSymbol)
O_FIELD(long, closeElf, closeElf)
O_FIELD(long, getMethodDeclaringClass, getMethodDeclaringClass)
O_FIELD(long, syncMethodEntry, syncMethodEntry)
O_FIELD(long, suspendVM, suspendVM)
O_FIELD(long, resumeVM, resumeVM)

// Methods ordered exactly as in PierceNative class with corrected signatures
O_FUNC(void, init0(int, boolean, boolean, boolean, boolean, boolean), init0)
O_FUNC(void, enableFastNative(), enableFastNative)
O_FUNC(long, getArtMethod(java.lang.reflect.Member), getArtMethod)
O_FUNC(java.lang.reflect.Method, hook0(long, java.lang.Class, com.m4399.pierce.core.Pierce$HookRecord, java.lang.reflect.Member, java.lang.reflect.Method, java.lang.reflect.Method, boolean, boolean, boolean), hook0)
O_FUNC(java.lang.reflect.Method, hookReplace0(long, java.lang.Class, com.m4399.pierce.core.Pierce$HookRecord, java.lang.reflect.Member, java.lang.reflect.Method, java.lang.reflect.Method, boolean, boolean, boolean), hookReplace0)
O_FUNC(boolean, compile0(long, java.lang.reflect.Member), compile0)
O_FUNC(boolean, decompile0(java.lang.reflect.Member, boolean), decompile0)
O_FUNC(boolean, disableJitInline0(), disableJitInline0)
O_FUNC(void, setJitCompilationAllowed0(boolean, boolean), setJitCompilationAllowed0)
O_FUNC(boolean, disableProfileSaver0(), disableProfileSaver0)
O_FUNC(java.lang.Object, getObject0(long, long), getObject0)
O_FUNC(long, getAddress0(long, java.lang.Object), getAddress0)
O_FUNC(void, syncMethodInfo(java.lang.reflect.Member, java.lang.reflect.Method, boolean), syncMethodInfo)
O_FUNC(long, currentArtThread0(), currentArtThread0)
O_FUNC(void, setDebuggable0(boolean), setDebuggable0)
O_FUNC(void, disableHiddenApiPolicy0(boolean, boolean), disableHiddenApiPolicy0)
O_FUNC(void, makeClassesVisiblyInitialized(long), makeClassesVisiblyInitialized)
O_FUNC(long, getArtMethodEntryPointFromCompiledCode(java.lang.reflect.Member), getArtMethodEntryPointFromCompiledCode)
O_FUNC(java.lang.String, getArtMethodEntryPointHexString(java.lang.reflect.Member,int), getArtMethodEntryPointHexString)
O_FUNC(boolean, generateDex(java.lang.String,java.lang.reflect.Member,boolean,java.lang.reflect.Method,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String), generateDex)
O_FUNC(void, setLogFilePath(java.lang.String), setLogFilePath)
O_FUNC(boolean, writeLogToFile(java.lang.String, java.lang.String, java.lang.String), writeLogToFile)

// class com.m4399.pierce.core.NativeMark
O_CLASS(com___m4399___pierce___core___NativeMark, com/m4399/pierce/core/NativeMark)
O_FUNC(void, m1(float), m1)
O_FUNC(void, m2(), m2)

// interface com.m4399.pierce.core.NativeMark$I
O_INTERFACE(com___m4399___pierce___core___NativeMark$I, com/m4399/pierce/core/NativeMark$I)
O_FUNC(void, m(), m)

O_END
#endif //M4399_PLUGINGAME_NAMED_H