#ifndef M4399_PIERCE_THREADLOCALVAR_H
#define M4399_PIERCE_THREADLOCALVAR_H

#include <string>
#include "macros.h"

class ThreadLocalVar {
public:
    static void setTargetMethodDesc(const std::string &desc);

    static const std::string &getTargetMethodDesc();

private:
    DISALLOW_IMPLICIT_CONSTRUCTORS(ThreadLocalVar);

    static thread_local std::string targetMethodDesc_;
};


#endif
