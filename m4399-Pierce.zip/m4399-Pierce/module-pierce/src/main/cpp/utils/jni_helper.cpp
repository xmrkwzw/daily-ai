#include "jni_helper.h"

bool pierce::JNIHelper::SetStaticBooleanField(JNIEnv *env,
                                              jclass c,
                                              const char *name,
                                              bool value) {
    jfieldID field = env->GetStaticFieldID(c, name, "Z");
    if (LIKELY(field)) {
        env->SetStaticBooleanField(c, field, static_cast<jboolean>(value));
        return true;
    } else {
        return false;
    }
}

void pierce::JNIHelper::Throw(JNIEnv *env,
                              const char *class_name,
                              const char *msg) {
    jclass c = env->FindClass(class_name);
    if (UNLIKELY(!c)) {
        return;
    }
    env->ThrowNew(c, msg);
    env->DeleteLocalRef(c);
}

std::string pierce::JNIHelper::jstringToString(JNIEnv *env,
                                               jstring jStr) {
    if (!jStr) {
        return "";
    }

    jsize length = env->GetStringUTFLength(jStr);
    if (length == 0) {
        return "";
    }

    std::string str = "";
    const char *utfString = env->GetStringUTFChars(jStr, nullptr);
    if (nullptr != utfString) {
        str = std::string(utfString, length);
    }
    env->ReleaseStringUTFChars(jStr, utfString);

    return str;
}

bool pierce::JNIHelper::jbooleanToBool(jboolean paramJboolean) {
    bool ret = false;
    if (JNI_TRUE == paramJboolean) {
        ret = true;
    }
    return ret;
}

jboolean pierce::JNIHelper::boolToJoolean(bool paramBool) {
    return paramBool ? JNI_TRUE : JNI_FALSE;
}

std::string pierce::JNIHelper::getClassName(JNIEnv *env,
                                            jclass clazz) {
    jclass classClass = env->GetObjectClass(clazz);
    jmethodID getNameMethodID = env->GetMethodID(classClass, "getName", "()Ljava/lang/String;");
    jstring jstringName = (jstring) env->CallObjectMethod(clazz, getNameMethodID);
    std::string result = jstringToString(env, jstringName);
    env->DeleteLocalRef(jstringName);
    env->DeleteLocalRef(classClass);
    return result;
}

std::string pierce::JNIHelper::getMethodName(JNIEnv *env,
                                             jobject method) {
    jclass methodClass = env->GetObjectClass(method);
    jmethodID getNameMethodID = env->GetMethodID(methodClass, "getName", "()Ljava/lang/String;");
    jstring jstringName = (jstring) env->CallObjectMethod(method, getNameMethodID);
    std::string result = jstringToString(env, jstringName);
    env->DeleteLocalRef(jstringName);
    env->DeleteLocalRef(methodClass);
    return result;
}

std::string pierce::JNIHelper::getDeclaringClassName(JNIEnv *env, jobject method) {
    jclass methodClass = env->GetObjectClass(method);
    jmethodID getDeclaringClassMethodID = env->GetMethodID(methodClass, "getDeclaringClass", "()Ljava/lang/Class;");
    jclass declaringClass = (jclass) env->CallObjectMethod(method, getDeclaringClassMethodID);
    std::string result = getClassName(env, declaringClass);
    env->DeleteLocalRef(declaringClass);
    env->DeleteLocalRef(methodClass);
    return result;
}

std::string pierce::JNIHelper::methodToString(JNIEnv *env, jobject method) {
    jclass methodClass = env->GetObjectClass(method);
    jmethodID toStringMethod = env->GetMethodID(methodClass, "toString", "()Ljava/lang/String;");
    jstring jstringDesc = (jstring) env->CallObjectMethod(method, toStringMethod);
    std::string result = jstringToString(env, jstringDesc);
    env->DeleteLocalRef(jstringDesc);
    env->DeleteLocalRef(methodClass);
    return result;
}
