#include "ThreadLocalVar.h"

thread_local std::string ThreadLocalVar::targetMethodDesc_;

void ThreadLocalVar::setTargetMethodDesc(const std::string &desc) {
    targetMethodDesc_ = desc;
}

const std::string &ThreadLocalVar::getTargetMethodDesc() {
    return targetMethodDesc_;
}

