//
// Created by canyie on 2020/3/25.
//

#ifndef PINE_JNI_HELPER_H
#define PINE_JNI_HELPER_H

#include <jni.h>
#include "macros.h"

#include <string>

namespace pierce {
    class JNIHelper {
    public:
        static bool SetStaticBooleanField(JNIEnv *env,
                                          jclass c,
                                          const char *name,
                                          bool value);

        static void Throw(JNIEnv *env,
                          const char *class_name,
                          const char *msg);

        static std::string jstringToString(JNIEnv *env,
                                           jstring jStr);

        static bool jbooleanToBool(jboolean paramJboolean);

        static jboolean boolToJoolean(bool paramBool);


        static std::string getClassName(JNIEnv *env,
                                        jclass clazz);

        static std::string getMethodName(JNIEnv *env,
                                         jobject method);

        static std::string getDeclaringClassName(JNIEnv *env,
                                                 jobject method);

        static std::string methodToString(JNIEnv *env,
                                          jobject method);

    private:
        DISALLOW_IMPLICIT_CONSTRUCTORS(JNIHelper);
    };
}

#endif //PINE_JNI_HELPER_H
