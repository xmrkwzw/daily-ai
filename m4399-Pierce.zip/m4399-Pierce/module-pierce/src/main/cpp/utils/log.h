//
// Created by canyie on 2020/2/9.
//

#ifndef PINE_LOG_H
#define PINE_LOG_H

#include <cstdarg>
#include <android/log.h>
#include <cstdlib>
#include "../pine_config.h"
#include "FileLog.h"

#define LOG_TAG "NativePierce"

static inline void LogLevelV(int level,
                             bool debugOnly,
                             const char *fmt,
                             va_list ap) {
    if (debugOnly && !pierce::PineConfig::debug) {
        return;
    }
    va_list apCopy;
    va_copy(apCopy, ap);
    __android_log_vprint(level, LOG_TAG, fmt, ap);
    CFileLog::getInstance().vlog(level, LOG_TAG, fmt, apCopy);
    va_end(apCopy);
}

static inline void LogV(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    LogLevelV(ANDROID_LOG_VERBOSE, true, fmt, ap);
    va_end(ap);
}

static inline void LogD(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    LogLevelV(ANDROID_LOG_DEBUG, true, fmt, ap);
    va_end(ap);
}

static inline void LogI(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    LogLevelV(ANDROID_LOG_INFO, true, fmt, ap);
    va_end(ap);
}

static inline void LogW(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    LogLevelV(ANDROID_LOG_WARN, false, fmt, ap);
    va_end(ap);
}

static inline void LogE(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    LogLevelV(ANDROID_LOG_ERROR, false, fmt, ap);
    va_end(ap);
}

static inline void LogF(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    LogLevelV(ANDROID_LOG_FATAL, false, fmt, ap);
    va_end(ap);
}

static inline void AlwaysLogI(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    LogLevelV(ANDROID_LOG_INFO, false, fmt, ap);
    va_end(ap);
}

static inline void FatalV(const char *fmt, va_list ap) {
    LogLevelV(ANDROID_LOG_FATAL, false, fmt, ap);
    LogF("Aborting...");
    abort();
}

static inline void Fatal(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    FatalV(fmt, ap);
    va_end(ap);
}

static inline void Check(bool cond,
                         const char *file,
                         int line,
                         const char *condStr,
                         const char *fmt,
                         ...) {
    if (LIKELY(cond)) {
        return;
    }
    LogF("%s#%d: Check failed: %s", file, line, condStr);
    va_list ap;
    va_start(ap, fmt);
    FatalV(fmt, ap);
    va_end(ap);
}

#define LOGV(...) LogV(__VA_ARGS__)
#define LOGD(...) LogD(__VA_ARGS__)
#define LOGI(...) LogI(__VA_ARGS__)
#define LOGW(...) LogW(__VA_ARGS__)
#define LOGE(...) LogE(__VA_ARGS__)
#define LOGF(...) LogF(__VA_ARGS__)
#define ALWAYSLOGI(...) AlwaysLogI(__VA_ARGS__)

#define FATAL(...) Fatal(__VA_ARGS__)

#define CHECK(cond, ...) Check((cond), __FILE__, __LINE__, #cond, __VA_ARGS__)

#define CHECK_EQ(a, b, ...) CHECK((a) == (b), __VA_ARGS__)


#endif //PINE_LOG_H
