#ifndef M4399_PIERCE_FILELOG_H
#define M4399_PIERCE_FILELOG_H

#include <string>
#include <mutex>
#include <cstdarg>

using namespace std;

class CFileLog {
public:
    void vlog(int loglevel,
              const char *logTag,
              const char *format,
              va_list args);

    void log(int loglevel,
             const char *logTag,
             const char *format,
             ...);

    bool javaLog(const std::string &logLevel,
                 const std::string &logTag,
                 const std::string &logMsg);

    void setFilePath(const std::string &filePath);

    bool isValid();

    static CFileLog &getInstance();

private:
    CFileLog();

    ~CFileLog();

    CFileLog(const CFileLog &) = delete;

    CFileLog &operator=(const CFileLog &) = delete;

    void logv(const std::string &logLevelStr,
              const char *logTag,
              const char *format,
              va_list args);

    static std::string formatMsg(const std::string &logLevelStr,
                                 const std::string &logTag,
                                 const std::string &logMsg);

    static std::string timestamp();

    static std::string levelToStr(int loglevel);

    bool writeToFile(const std::string &writeContent);

private:
    std::string logPath;
    static std::string fileLogTag;
    int fd;
    std::mutex mtx;
};


#endif
