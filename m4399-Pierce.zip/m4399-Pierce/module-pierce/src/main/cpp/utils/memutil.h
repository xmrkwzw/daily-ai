//
// Created by zhanjian on 2021/10/18.
//
#pragma once
#ifndef __MEMORY_UTIL_H__
#define __MEMORY_UTIL_H__

#ifdef __ANDROID__

#include <bits/sysconf.h>

#else

#endif

#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>

#include <memory.h>
#include <cstdint>
#include <fstream>
#include <memory>
#include <vector>
#include <string>

class memutil {
public:
    template<typename TTo, typename TFrom>
    static inline TTo force_cast(TFrom from) {
        return reinterpret_cast<TTo>(from);
    }

    template<typename T>
    static inline ssize_t find(const void *start, size_t size, T value, size_t step = 1) {
        for (ssize_t off = 0; off < size - sizeof(T); off += step) {
            if (value == *force_cast<const T *>(force_cast<const char *>(start) + off)) {
                return off;
            }
        }
        return -1;
    }

    static inline ssize_t
    find(const void *start, size_t size, void *src, size_t len, size_t step = 1) {
        for (ssize_t off = 0; off < size - len; off += step) {
            if (0 == ::memcmp(force_cast<const char *>(start) + off, src, len)) {
                return off;
            }
        }
        return -1;
    }

    /**
     *  memory maps 4k alignment view
     *  4098 => 4096 (Align down)
     *  4094 => 4096 (Align up)
     * 
     *  +----------+ high
     *  +----------+ 4098d ↓ Align down to 4096
     *  +----------+ 4097d
     *  +----------+ 4096d
     *  +----------+ 4095d
     *  +----------+ 4094d ↑ Align up to 4096
     *  +----------+ low
     */
    static inline void *alignUp(uintptr_t x, size_t align = pageSize()) {
        return force_cast<void *>(x + align - 1 - ((x + align - 1) & (align - 1)));
    }

    template<typename Ty>
    static inline Ty alignUp(uintptr_t x, size_t align = pageSize()) {
        return force_cast<Ty>(alignUp(x, align));
    }

    static inline void *alignDown(uintptr_t x, size_t align = pageSize()) {
        return force_cast<void *>((x) & -(align));
    }

    template<typename Ty>
    static inline Ty alignDown(uintptr_t x, size_t align = pageSize()) {
        return force_cast<Ty>(alignDown(x, align));
    }

    static inline bool protect(const void *dst, size_t size, int prot) {
        void *ptr = alignDown((uintptr_t) dst, pageSize());
        const size_t len = alignUp<size_t>(size, pageSize());
        return 0 == mprotect(ptr, len, prot);
    }

    static inline bool rx(const void *dst, size_t size) {
        return protect(dst, size, PROT_READ | PROT_EXEC);
    }

    static inline bool rwx(const void *dst, size_t size) {
        return protect(dst, size, PROT_READ | PROT_WRITE | PROT_EXEC);
    }

    static inline ssize_t pageSize() {
        static const ssize_t SC_PAGESIZE = static_cast<ssize_t>(::sysconf(_SC_PAGESIZE));
        return SC_PAGESIZE;
    }

    static inline void cacheflush(void *addr, size_t nbytes) {
        __builtin___clear_cache((char *) addr, (char *) ((uintptr_t) addr + nbytes));
    }

    /**
     * @brief 从 /proc/self/maps 文件中检索目标
     *
     * /proc/self/maps 结构示意
     * address                   perms offset   dev     inode       pathname
     * 55c7b0018000-55c7b001a000 r--p  00000000 08:05   10223767    /usr/bin/cat
     */
    static inline intptr_t findBaseAddress(std::string_view pathname) {
        FILE *fp = ::fopen("/proc/self/maps", "r");
        if (!fp) {
            return reinterpret_cast<intptr_t>(nullptr);
        }

        char line_buff[4096];
        char *line_ptr = line_buff;
        size_t line_length_ptr = sizeof line_buff;

        while (true) {
            ssize_t bytes_read = ::getline(&line_ptr, &line_length_ptr, fp);
            if (0 >= bytes_read) {
                break;
            }

            // excluding the delimiter character '\n'
            if (line_buff[bytes_read - 1] == '\n') {
                --bytes_read;
            }

            std::string_view line_view = std::string_view(line_buff, bytes_read);
            const auto pos_start = line_view.find(pathname);

            if (pos_start != std::string_view::npos &&
                ' ' == line_buff[pos_start - 1] &&
                0 == line_view.substr(pos_start).compare(pathname)) {

                ::fclose(fp);
                intptr_t start_addr = 0, end_addr = 0;
                const auto rc = ::sscanf(line_buff, "%lx-%lx", &start_addr, &end_addr);
                return start_addr;
            }
        }
        ::fclose(fp);
        // address not found!
        return reinterpret_cast<intptr_t>(nullptr);
    }

    static inline std::string findAddressMapInfo(intptr_t address) {
        FILE *fp = ::fopen("/proc/self/maps", "r");
        if (!fp) {
            return "failed to open /proc/self/maps";
        }

        char line_buff[4096] = {0};
        char *line_ptr = line_buff;
        size_t line_length_ptr = sizeof(line_buff);

        while (true) {
            ssize_t bytes_read = ::getline(&line_ptr, &line_length_ptr, fp);
            if (0 >= bytes_read) {
                break;
            }

            // 去掉末尾换行符
            if (line_buff[bytes_read - 1] == '\n') {
                line_buff[bytes_read - 1] = '\0';
            }

            // 解析起止地址
            intptr_t start_addr = 0, end_addr = 0;
            if (::sscanf(line_buff, "%lx-%lx", &start_addr, &end_addr) != 2) {
                continue;
            }

            if (address >= start_addr && address < end_addr) {
                ::fclose(fp);
                return std::string(line_buff);
            }
        }

        ::fclose(fp);
        return "address not found in /proc/self/maps";
    }

    static inline std::vector<uint8_t> dump(uintptr_t start, size_t len) {
        //! WARN: make sure the dest of address has read permission
        //memutil::rwx((void *) start, len);
        std::vector<uint8_t> mem(reinterpret_cast<uint8_t*>(start), reinterpret_cast<uint8_t*>(start + len));
        return mem;
    }

    static inline std::string hexdump(uintptr_t start, size_t len, const char *split = " ", const char *prefix = "", int nextline = 16) {
        const char *hex_code = "0123456789ABCDEF";
        int cnt = 0;
        std::string hex_str;
        auto &&mem = dump(start, len);
        for (auto &byte : mem) {
            hex_str += prefix;
            hex_str += hex_code[(byte & 0xf0) >> 4];
            hex_str += hex_code[(byte & 0x0f)];
            hex_str += (!nextline || ++cnt % nextline) ? split : "\n";
        }
        return hex_str;
    }
};

#endif //!__MEMORY_UTIL_H__