#include "FileLog.h"
#include <vector>
#include <cstring>
#include <chrono>
#include <ctime>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <android/log.h>

std::string CFileLog::fileLogTag = "CFileLog";

string CFileLog::timestamp() {
    using namespace std::chrono;
    auto now = system_clock::now();
    auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;

    time_t tt = system_clock::to_time_t(now);
    struct tm local_tm;
    localtime_r(&tt, &local_tm);

    char buf[64] = {0};
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S.", &local_tm);

    char msbuf[8] = {0};
    snprintf(msbuf, sizeof(msbuf), "%03d", (int) ms.count());

    return string(buf) + msbuf;
}

string CFileLog::levelToStr(int level) {
    switch (level) {
        case ANDROID_LOG_VERBOSE:
            return "V";
        case ANDROID_LOG_DEBUG:
            return "D";
        case ANDROID_LOG_INFO:
            return "I";
        case ANDROID_LOG_WARN:
            return "W";
        case ANDROID_LOG_ERROR:
            return "E";
        case ANDROID_LOG_FATAL:
            return "F";
        default:
            return "?";
    }
}

CFileLog::CFileLog() {
    fd = -1;
    logPath = "";
}

void CFileLog::setFilePath(const std::string &filePath) {
    lock_guard<std::mutex> lock(mtx);

    if (fd >= 0) {
        ::close(fd);
        fd = -1;
    }

    logPath = filePath;
    if (!logPath.empty()) {
        fd = ::open(logPath.c_str(),
                    O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC,
                    0644);
        if (fd < 0) {
            __android_log_print(ANDROID_LOG_ERROR, fileLogTag.c_str(),
                                "setFilePath open failed path=%s errno=%d",
                                logPath.c_str(), errno);
        }
    }
}

CFileLog::~CFileLog() {
    lock_guard<std::mutex> lock(mtx);
    if (fd >= 0) {
        ::close(fd);
        fd = -1;
    }
}

CFileLog &CFileLog::getInstance() {
    static CFileLog instance;
    return instance;
}

bool CFileLog::isValid() {
    lock_guard<std::mutex> lock(mtx);
    bool ret = true;
    if (fd < 0) {
        ret = false;
    }
    return ret;
}

void CFileLog::vlog(int loglevel,
                    const char *logTag,
                    const char *format,
                    va_list args) {
    if (!isValid()) {
        return;
    }
    logv(levelToStr(loglevel), logTag, format, args);
}

void CFileLog::log(int loglevel,
                   const char *logTag,
                   const char *format,
                   ...) {
    if (!isValid()) {
        return;
    }

    string logLevelStr = levelToStr(loglevel);
    va_list args;
    va_start(args, format);
    logv(logLevelStr, logTag, format, args);
    va_end(args);
}

void CFileLog::logv(const std::string &logLevelStr,
                    const char *logTag,
                    const char *format,
                    va_list args) {
    // 计算格式化长度
    va_list args_copy;
    va_copy(args_copy, args);
    int len = vsnprintf(nullptr, 0, format, args_copy);
    va_end(args_copy);

    if (len < 0) {
        return;
    }

    vector<char> buffer(len + 1);
    vsnprintf(buffer.data(), buffer.size(), format, args);

    string writeContent = formatMsg(logLevelStr,
                                    (logTag ? string(logTag) : string("null")),
                                    buffer.data());

    writeToFile(writeContent);
}

bool CFileLog::javaLog(const std::string &logLevel,
                       const std::string &logTag,
                       const std::string &logMsg) {
    if (!isValid()) {
        return false;
    }

    string writeContent = formatMsg(logLevel,
                                    logTag,
                                    logMsg);

    bool ret = writeToFile(writeContent);
    return ret;
}


std::string CFileLog::formatMsg(const std::string &logLevelStr,
                                const std::string &logTag,
                                const std::string &logMsg) {
    // 拼接最终日志，格式与 Java 端 PierceDemoFileLogUtil 对齐：
    // 2026-06-08 11:37:51.404  1668-1690 TAG LEVEL msg
    string line =
            timestamp() +
            "  " +                                          // 两个空格
            std::to_string((long long) ::getpid()) + "-" +
            std::to_string((long long) ::gettid()) + " " +
            logTag + " " +
            logLevelStr + " " +
            logMsg;
    line.append(1, '\n');
    return line;
}


bool CFileLog::writeToFile(const std::string &writeContent) {
    bool ret = true;
    lock_guard<std::mutex> lock(mtx);
    const char *p = writeContent.data();
    size_t left = writeContent.size();
    while (left > 0) {
        ssize_t n = ::write(fd, p, left);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }

            __android_log_print(ANDROID_LOG_ERROR, fileLogTag.c_str(),
                                "write fd=%d failed errno=%d", fd, errno);
            break;
        }

        if (n == 0) {
            break;
        }
        p += n;
        left -= (size_t) n;
    }

    if (left > 0) {
        ret = false;
    }
    return ret;
}