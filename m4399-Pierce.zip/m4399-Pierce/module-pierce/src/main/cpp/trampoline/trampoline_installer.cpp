//
// Created by canyie on 2020/3/19.
//

#include "trampoline_installer.h"
#include "../pine_config.h"
#include "../utils/memory.h"
#include "../utils/scoped_memory_access_protection.h"
#include "../utils/ThreadLocalVar.h"

#ifdef __aarch64__
#include "arch/arm64.h"
#elif defined(__arm__)

#include "arch/thumb2.h"

#elif defined(__i386__)
#include "arch/x86.h"
#else
#error unsupported architecture
#endif

using namespace pierce;

TrampolineInstaller* TrampolineInstaller::default_ = nullptr;

TrampolineInstaller* TrampolineInstaller::GetOrInitDefault() {
    if (default_ == nullptr) {
#ifdef __aarch64__
        default_ = new Arm64TrampolineInstaller;
#elif defined(__arm__)
        default_ = new Thumb2TrampolineInstaller;
#elif defined(__i386__)
        default_ = new X86TrampolineInstaller;
#endif
        default_->Init();
    }
    return default_;
}

void* TrampolineInstaller::CreateDirectJumpTrampoline(void* to) {
    void* mem = Memory::AllocUnprotected(kDirectJumpTrampolineSize);
    if (UNLIKELY(!mem)) {
        LOGE("Failed to allocate direct jump trampoline!");
        return nullptr;
    }
    WriteDirectJumpTrampolineTo(mem, to);
    return mem;
}

void TrampolineInstaller::WriteDirectJumpTrampolineTo(void* mem, void* jump_to) {
    memcpy(mem, kDirectJumpTrampoline, kDirectJumpTrampolineSize);
    void* to_out = AS_VOID_PTR(reinterpret_cast<uintptr_t>(mem) + kDirectJumpTrampolineEntryOffset);
    memcpy(to_out, &jump_to, PTR_SIZE);
    Memory::FlushCache(mem, kDirectJumpTrampolineSize);
}

void *TrampolineInstaller::CreateBridgeJumpTrampoline(art::ArtMethod *target,
                                                      art::ArtMethod *bridge,
                                                      void *origin_code_entry) {
    //在可执行内存上分配 kBridgeJumpTrampolineSize（模板 + 一些 data slots），把 kBridgeJumpTrampoline 模板拷贝进去，
    // 然后在内存中写入以下数据指针：
    //指向 target 的指针（so assembly can compare x0 with this target）
    //bridge 方法指针
    //bridge->GetEntryPointFromCompiledCode()
    //origin_code_entry（被替换前的原入口）
    void* mem = Memory::AllocUnprotected(kBridgeJumpTrampolineSize);
    if (UNLIKELY(!mem)) {
        LOGE("Failed to allocate bridge jump trampoline!");
        return nullptr;
    }
    memcpy(mem, kBridgeJumpTrampoline, kBridgeJumpTrampolineSize);
    uintptr_t addr = reinterpret_cast<uintptr_t>(mem);

    auto target_out = reinterpret_cast<art::ArtMethod**>(addr +
                                                         kBridgeJumpTrampolineTargetMethodOffset);
    *target_out = target;

    auto bridge_out = reinterpret_cast<art::ArtMethod **>(addr +
                                                          kBridgeJumpTrampolineBridgeMethodOffset);
    *bridge_out = bridge;

    auto bridge_entry_out = reinterpret_cast<void**>(addr + kBridgeJumpTrampolineBridgeEntryOffset);
    *bridge_entry_out = bridge->GetEntryPointFromCompiledCode();

    auto origin_entry_out = reinterpret_cast<void**>(addr +
                                                     kBridgeJumpTrampolineOriginCodeEntryOffset);
    *origin_entry_out = origin_code_entry;

    Memory::FlushCache(mem, kBridgeJumpTrampolineSize);

    return mem;
}

void* TrampolineInstaller::CreateMethodJumpTrampoline(art::ArtMethod* dest) {
    void* mem = Memory::AllocUnprotected(kMethodJumpTrampolineSize);
    if (UNLIKELY(!mem)) {
        LOGE("Failed to allocate method jump trampoline!");
        return nullptr;
    }
    memcpy(mem, kMethodJumpTrampoline, kMethodJumpTrampolineSize);
    uintptr_t addr = reinterpret_cast<uintptr_t>(mem);

    auto dest_method_out = reinterpret_cast<art::ArtMethod**>(addr +
            kMethodJumpTrampolineDestMethodOffset);
    *dest_method_out = dest;

    auto origin_entry_out = reinterpret_cast<void**>(addr +
            kMethodJumpTrampolineDestEntryOffset);
    *origin_entry_out = dest->GetEntryPointFromCompiledCode();

    Memory::FlushCache(mem, kMethodJumpTrampolineSize);

    return mem;
}

void *TrampolineInstaller::CreateCallOriginTrampoline(art::ArtMethod* origin, void* original_code_entry) {
    void* mem = Memory::AllocUnprotected(kCallOriginTrampolineSize);
    if (UNLIKELY(!mem)) {
        LOGE("Failed to allocate call origin trampoline!");
        return nullptr;
    }
    memcpy(mem, kCallOriginTrampoline, kCallOriginTrampolineSize);
    uintptr_t addr = reinterpret_cast<uintptr_t>(mem);

    auto origin_method_out = reinterpret_cast<art::ArtMethod**>(addr +
                                                                kCallOriginTrampolineOriginMethodOffset);
    *origin_method_out = origin;

    void** original_code_entry_out = reinterpret_cast<void**>(addr +
                                                              kCallOriginTrampolineOriginalEntryOffset);
    *original_code_entry_out = original_code_entry;

    Memory::FlushCache(mem, kCallOriginTrampolineSize);
    return mem;
}

void* TrampolineInstaller::Backup(art::ArtMethod* target, size_t size) {
    void* mem = Memory::AllocUnprotected(kBackupTrampolineSize);
    if (UNLIKELY(!mem)) {
        LOGE("Failed to allocate executable memory for backup!");
        return nullptr;
    }
    memcpy(mem, kBackupTrampoline, kBackupTrampolineSize);
    uintptr_t addr = reinterpret_cast<uintptr_t>(mem);

    auto origin_out = reinterpret_cast<art::ArtMethod**>(addr +
                                                         kBackupTrampolineOriginMethodOffset);
    *origin_out = target;

    void* target_addr = target->GetEntryPointFromCompiledCode();
    memcpy(AS_VOID_PTR(addr + kBackupTrampolineOverrideSpaceOffset), target_addr, size);

    if (LIKELY(target->GetCompiledCodeSize() != size)) {
        // has remaining code
        void** remaining_out = reinterpret_cast<void**>(addr +
                                                        kBackupTrampolineRemainingCodeEntryOffset);
        *remaining_out = AS_VOID_PTR(reinterpret_cast<uintptr_t>(target_addr) + size);
    }

    Memory::FlushCache(mem, kBackupTrampolineSize);
    return mem;
}

void *TrampolineInstaller::InstallReplacementTrampoline(art::ArtMethod *target,
                                                        art::ArtMethod *bridge) {
    std::string targetMethodDesc = ThreadLocalVar::getTargetMethodDesc();
    void *target_origin_code_entry = target->GetEntryPointFromCompiledCode();
    void *method_jump_trampoline = CreateMethodJumpTrampoline(bridge);
    if (UNLIKELY(!method_jump_trampoline)) return nullptr;

    // Unknown bug:
    // After setting the r0 register to the original method, if the original method needs to be
    // traced back to the call stack (such as an exception), the thread will become a zombie thread
    // and there will be no response. Just set origin code entry and don't create call_origin_trampoline
    // to set r0 register to avoid it.

    // void *call_origin_trampoline = CreateCallOriginTrampoline(target, target_origin_code_entry);
    // if (UNLIKELY(!call_origin_trampoline)) return nullptr;

    target->SetEntryPointFromCompiledCode(method_jump_trampoline);
    // return call_origin_trampoline;

    ALWAYSLOGI("InstallReplacementTrampoline %s target=%p target_origin_code_entry=%p method_jump_trampoline=%p",
               targetMethodDesc.c_str(), target, target_origin_code_entry, method_jump_trampoline);

    return target_origin_code_entry;
}

void *TrampolineInstaller::InstallDirectJumpReplacementTrampoline(art::ArtMethod* target, art::ArtMethod* replacement) {
    void* origin_code_entry = target->GetEntryPointFromCompiledCode();
    void* trampoline = CreateMethodJumpTrampoline(replacement);
    if (UNLIKELY(!trampoline)) return nullptr;
    target->SetEntryPointFromCompiledCode(trampoline);

    LOGI("InstallDirectJumpReplacementTrampoline: target=%p origin_code_entry=%p trampoline=%p",
         target, origin_code_entry, trampoline);

    return origin_code_entry;
}

void *TrampolineInstaller::InstallInlineTrampoline(art::ArtMethod *target,
                                                   art::ArtMethod *bridge,
                                                   bool skip_first_few_bytes) {
    std::string targetMethodDesc = ThreadLocalVar::getTargetMethodDesc();
    void *target_code_addr = target->GetCompiledCodeAddr();
    bool target_code_writable = Memory::Unprotect(target_code_addr);
    if (UNLIKELY(!target_code_writable)) {
        LOGE("InstallInlineTrampoline %s Failed to make target code writable!", targetMethodDesc.c_str());
        return nullptr;
    }

    size_t backup_size = kDirectJumpTrampolineSize;
    if (skip_first_few_bytes) {
        backup_size += kSkipBytes;
    }

    void *back_up_trampoline = Backup(target, backup_size);
    if (UNLIKELY(!back_up_trampoline)) return nullptr;

    void *bridge_jump_trampoline = CreateBridgeJumpTrampoline(target, bridge, back_up_trampoline);
    if (UNLIKELY(!bridge_jump_trampoline)) return nullptr;

    {
        ScopedMemoryAccessProtection protection(target_code_addr, backup_size);
        if (skip_first_few_bytes) {
            FillWithNopImpl(target_code_addr, kSkipBytes);
            WriteDirectJumpTrampolineTo(AS_VOID_PTR(AS_PTR_NUM(target_code_addr) + kSkipBytes),
                                        bridge_jump_trampoline);
        } else {
            WriteDirectJumpTrampolineTo(target_code_addr, bridge_jump_trampoline);
        }
    }

    ALWAYSLOGI("InstallInlineTrampoline %s target_code_addr=%p bridge_jump_trampoline=%p back_up_trampoline=%p ",
               targetMethodDesc.c_str(),
               target_code_addr,
               bridge_jump_trampoline,
               back_up_trampoline);

    return back_up_trampoline;
}

void* TrampolineInstaller::InstallDirectJumpInlineTrampoline(art::ArtMethod* target,
                                                             art::ArtMethod* replacement,
                                                             bool skip_first_few_bytes) {
    void* target_code_addr = target->GetCompiledCodeAddr();
    bool target_code_writable = Memory::Unprotect(target_code_addr);
    if (UNLIKELY(!target_code_writable)) {
        LOGE("InstallDirectJumpInlineTrampoline Failed to make target code writable!");
        return nullptr;
    }

    size_t backup_size = kDirectJumpTrampolineSize;
    if (skip_first_few_bytes) {
        backup_size += kSkipBytes;
    }

    void *backupTrampoline = Backup(target, backup_size);
    if (UNLIKELY(!backupTrampoline)) return nullptr;

    void* method_jump_trampoline = CreateMethodJumpTrampoline(replacement);
    if (UNLIKELY(!method_jump_trampoline)) return nullptr;

    {
        ScopedMemoryAccessProtection protection(target_code_addr, backup_size);
        if (skip_first_few_bytes) {
            FillWithNopImpl(target_code_addr, kSkipBytes);
            WriteDirectJumpTrampolineTo(AS_VOID_PTR(AS_PTR_NUM(target_code_addr) + kSkipBytes),
                                        method_jump_trampoline);
        } else {
            WriteDirectJumpTrampolineTo(target_code_addr, method_jump_trampoline);
        }
    }

    LOGI("InstallDirectJumpInlineTrampoline target_code_addr=%p backupTrampoline=%p method_jump_trampoline=%p",
         target_code_addr, backupTrampoline, method_jump_trampoline);

    return backupTrampoline;
}

bool TrampolineInstaller::NativeHookNoBackup(void* target, void* to) {
    bool target_code_writable = Memory::Unprotect(target);
    if (UNLIKELY(!target_code_writable)) {
        LOGE("NativeHookNoBackup Failed to make target code %p writable!", target);
        return false;
    }

    {
        ScopedMemoryAccessProtection protection(target, kDirectJumpTrampolineSize);
        WriteDirectJumpTrampolineTo(target, to);
    }
    return true;
}

bool TrampolineInstaller::FillWithNop(void* target, size_t size) {
    bool target_code_writable = Memory::Unprotect(target);
    if (UNLIKELY(!target_code_writable)) {
        LOGE("Failed to make target code %p writable!", target);
        return false;
    }

    {
        ScopedMemoryAccessProtection protection(target, size);
        FillWithNopImpl(target, size);
    }
    return true;
}
