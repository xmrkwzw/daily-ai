//
// Created by canyie on 2020/3/19.
//

#ifndef PINE_TRAMPOLINE_INSTALLER_H
#define PINE_TRAMPOLINE_INSTALLER_H

#include "../utils/macros.h"
#include "../art/art_method.h"
#include "arch/trampolines.h"

#define INST_CASE(mask, op) \
if (UNLIKELY(((inst) & (mask)) == op)) return true

#define AS_SIZE_T(value) (reinterpret_cast<size_t>(value))
#define AS_VOID_PTR(value) (reinterpret_cast<void*>(value))
#define AS_PTR_NUM(value) (reinterpret_cast<uintptr_t>(value))
#define PTR_SIZE (sizeof(void*))

namespace pierce {
    class TrampolineInstaller {
    public:
        static TrampolineInstaller* GetOrInitDefault();

        static TrampolineInstaller* GetDefault() {
            return default_;
        }

        TrampolineInstaller(size_t skip_bytes) : kSkipBytes(skip_bytes), kReplacementModeOnly(false) {
        };

        TrampolineInstaller(size_t skip_bytes, bool replacement_only) : kSkipBytes(skip_bytes), kReplacementModeOnly(replacement_only) {
        }

        void Init() {
            InitTrampolines();
            kBridgeJumpTrampolineSize = SubAsSize(kMethodJumpTrampoline, kBridgeJumpTrampoline);
            kMethodJumpTrampolineSize = SubAsSize(kCallOriginTrampoline, kMethodJumpTrampoline);
            kCallOriginTrampolineSize = SubAsSize(kBackupTrampoline, kCallOriginTrampoline);
            kBackupTrampolineSize = SubAsSize(kTrampolinesEnd, kBackupTrampoline);
        }

        bool IsReplacementOnly() {
            return kReplacementModeOnly;
        }

        bool CannotSafeInlineHook(size_t size) {
            return size < kDirectJumpTrampolineSize;
        }

        bool CannotSafeInlineHook(uintptr_t entry, size_t size) {
            if (UNLIKELY(CannotSafeInlineHook(size))) {
                LOGW("Cannot safe inline hook : code size of entry is too small,entry=%p size=%u",
                     entry, size);
                return true;
            }

            if (UNLIKELY(CannotBackup(entry, kDirectJumpTrampolineSize))) {
                LOGW("Cannot safe inline hook method: code of entry has pc register related instruction,entry=%p kDirectJumpTrampolineSize=%u",
                     entry, kDirectJumpTrampolineSize);
                return true;
            }
            return false;
        }

        bool CannotSafeInlineHook(art::ArtMethod *target) {
            size_t target_code_size = target->GetCompiledCodeSize();
            if (UNLIKELY(CannotSafeInlineHook(target_code_size))) {
                LOGW("Cannot safe inline hook method: code size of target method too small (size %u)!",
                     target_code_size);

                //#pierce特有
                //android 8.0 以下 hook mode 默认 采用inline hook 方式，同时编译的函数大小小于16个字节。
                // 实测 Android 5.1 下testChar()会因为函数过短，然后切换到replace hook,系统机制会不走替换的入口，导致hook失败
                // 实测 Android 6.0,7.1下testChar()不会函数过短提示
                if (Android::version < Android::kO) {
                    LOGW("notice: code size of target method is too small size=%u,it should be size=%u,it may lead to hook failure.",
                         target_code_size, kDirectJumpTrampolineSize);
                }
                return true;
            }
            if (UNLIKELY(CannotBackup(target, kDirectJumpTrampolineSize))) {
                LOGW("Cannot safe inline hook method: code of target method has pc register related instruction,target=%p kDirectJumpTrampolineSize=%u",
                     target, kDirectJumpTrampolineSize);

                //#pierce特有
                if (Android::version < Android::kO) {
                    LOGW("notice: code of target method has pc register related instruction, it may lead to hook failure,target=%p kDirectJumpTrampolineSize=%u",
                         target, kDirectJumpTrampolineSize);
                }
                return true;
            }
            return false;
        }

        bool CannotBackup(art::ArtMethod* target, size_t size){
            uintptr_t entry = reinterpret_cast<uintptr_t>(target->GetEntryPointFromCompiledCode());
            bool ret = CannotBackup(entry,size);
            return ret;
        }

        bool CanSkipFirstFewBytes(art::ArtMethod* target) {
            size_t target_code_size = target->GetCompiledCodeSize();
            size_t size = kDirectJumpTrampolineSize + kSkipBytes;
            if (UNLIKELY(target_code_size < size)) {
                LOGW("targetEntryPointFromCompiledCode=%p Cannot safe inline hook method and skip first few bytes: "
                     "code size of target method too small (size %u)!",
                     target->GetEntryPointFromCompiledCode(),target_code_size);
                return false;
            }
            if (UNLIKELY(CannotBackup(target, size))) {
                LOGW("targetEntryPointFromCompiledCode=%p Cannot safe inline hook method and skip first few bytes: "
                     "code of target method has pc register related instruction!",
                     target->GetEntryPointFromCompiledCode());
                return false;
            }
            return true;
        }

        void *InstallReplacementTrampoline(art::ArtMethod *target,
                                           art::ArtMethod *bridge);

        void *InstallInlineTrampoline(art::ArtMethod *target,
                                      art::ArtMethod *bridge,
                                      bool skip_first_few_bytes);

        void* InstallDirectJumpReplacementTrampoline(art::ArtMethod* target, art::ArtMethod* replacement);

        void* InstallDirectJumpInlineTrampoline(art::ArtMethod* target, art::ArtMethod* replacement, bool skip_first_few_bytes);

        virtual bool NativeHookNoBackup(void* target, void* to);

        bool FillWithNop(void* target, size_t size);

    protected:
        static inline size_t SubAsSize(void const* a, void const* b) {
            return AS_SIZE_T(reinterpret_cast<uintptr_t>(a) - reinterpret_cast<uintptr_t>(b));
        }

        inline size_t DirectJumpTrampolineOffset(void* ptr) {
            return SubAsSize(ptr, kDirectJumpTrampoline);
        }

        inline size_t BridgeJumpTrampolineOffset(void* ptr) {
            return SubAsSize(ptr, kBridgeJumpTrampoline);
        }

        inline size_t MethodJumpTrampolineOffset(void* ptr) {
            return SubAsSize(ptr, kMethodJumpTrampoline);
        }

        inline size_t CallOriginTrampolineOffset(void* ptr) {
            return SubAsSize(ptr, kCallOriginTrampoline);
        }

        inline size_t BackupTrampolineOffset(void* ptr) {
            return SubAsSize(ptr, kBackupTrampoline);
        }

        virtual void InitTrampolines() = 0;

        virtual void* CreateDirectJumpTrampoline(void* to);

        void WriteDirectJumpTrampolineTo(void* mem, void* jump_to);

        virtual void* CreateBridgeJumpTrampoline(art::ArtMethod* target, art::ArtMethod* bridge,
                                                 void* origin_code_entry);

        virtual void* CreateMethodJumpTrampoline(art::ArtMethod* dest);

        virtual void* CreateCallOriginTrampoline(art::ArtMethod* origin, void* original_code_entry);

        virtual bool CannotBackup(uintptr_t entry, size_t size) = 0;

        virtual void* Backup(art::ArtMethod* target, size_t size);

        virtual void FillWithNopImpl(void* target, size_t size) = 0;

        static TrampolineInstaller* default_;

        const bool kReplacementModeOnly;

        void const* kDirectJumpTrampoline;
        size_t kDirectJumpTrampolineEntryOffset;
        size_t kDirectJumpTrampolineSize;

        void const* kBridgeJumpTrampoline;
        size_t kBridgeJumpTrampolineTargetMethodOffset;
        size_t kBridgeJumpTrampolineExtrasOffset;
        size_t kBridgeJumpTrampolineBridgeMethodOffset;
        size_t kBridgeJumpTrampolineBridgeEntryOffset;
        size_t kBridgeJumpTrampolineOriginCodeEntryOffset;
        size_t kBridgeJumpTrampolineSize;

        void const* kMethodJumpTrampoline;
        size_t kMethodJumpTrampolineDestMethodOffset;
        size_t kMethodJumpTrampolineDestEntryOffset;
        size_t kMethodJumpTrampolineSize;

        void const* kCallOriginTrampoline;
        size_t kCallOriginTrampolineOriginMethodOffset;
        size_t kCallOriginTrampolineOriginalEntryOffset;
        size_t kCallOriginTrampolineSize;

        void const* kBackupTrampoline;
        size_t kBackupTrampolineOverrideSpaceOffset;
        size_t kBackupTrampolineOriginMethodOffset;
        size_t kBackupTrampolineRemainingCodeEntryOffset;
        size_t kBackupTrampolineSize;

        void const* kTrampolinesEnd;

        size_t kSkipBytes;
    private:
        DISALLOW_COPY_AND_ASSIGN(TrampolineInstaller);
    };
}


#endif //PINE_TRAMPOLINE_INSTALLER_H
