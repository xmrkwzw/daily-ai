//
// Created by canyie on 2020/2/9.
//
#include "NamedGen.h"
#include <cassert>
#include "pine_config.h"
#include "jni_bridge.h"
#include "android.h"
#include "art/art_method.h"
#include "utils/macros.h"
#include "utils/scoped_local_ref.h"
#include "utils/log.h"
#include "utils/jni_helper.h"
#include "utils/memory.h"
#include "utils/well_known_classes.h"
#include "trampoline/trampoline_installer.h"
#include "utils/memutil.h"
#include "utils/FileLog.h"
#include "utils/ThreadLocalVar.h"
#include "external/DexBuilder/DexBuilderUtil.h"
using namespace pierce;

static constexpr jint kArchArm = 1;
static constexpr jint kArchArm64 = 2;
static constexpr jint kArchX86 = 3;
static constexpr jint kCurrentArch =
#ifdef __aarch64__
        kArchArm64
#elif defined(__arm__)
        kArchArm
#elif defined(__i386__)
        kArchX86
#endif
        ;

bool PineConfig::debug = false;
bool PineConfig::debuggable = false;
bool PineConfig::anti_checks = false;
bool PineConfig::jit_compilation_allowed = true;
bool PineConfig::auto_compile_bridge = false;

EXPORT_C void PineSetAndroidVersion(int version) {
    Android::version = version;
}

EXPORT_C void* PineOpenElf(const char* elf) {
    return new ElfImage(elf);
}

EXPORT_C void PineCloseElf(void* handle) {
    delete static_cast<ElfImage*>(handle);
}

EXPORT_C void* PineGetElfSymbolAddress(void* handle, const char* symbol, bool warn_if_missing) {
    return static_cast<ElfImage*>(handle)->GetSymbolAddress(symbol, warn_if_missing);
}

void* GetMethodDeclaringClass(void* method) {
    return reinterpret_cast<void*>(static_cast<art::ArtMethod*>(method)->GetDeclaringClass());
}

void* PineSuspendVM(JNIEnv* env) {
    return new ScopedSuspendVM(art::Thread::Current(env));
}

void PineResumeVM(void* handle) {
    delete reinterpret_cast<ScopedSuspendVM*>(handle);
}

void SyncMethodEntry(void* target, void* backup, void* entry) {
    auto t = reinterpret_cast<art::ArtMethod*>(target);
    void* updated_entry = t->GetEntryPointFromCompiledCode();
    // We hooked a lot of functions to avoid missing any calls. There may be multiple hooks
    // take effect at the same time, the second hook can attempt change backup entry to updated one,
    // while the first one already changed target entry to hook bridge, resulting an infinite loop.
    if (entry != updated_entry) {
        reinterpret_cast<art::ArtMethod*>(backup)->SetEntryPointFromCompiledCode(updated_entry);
    }
    t->SetEntryPointFromCompiledCode(entry);
}

EXPORT_C bool PineNativeInlineHookSymbolNoBackup(const char* elf, const char* symbol, void* replace) {
    ElfImage handle(elf);
    void* addr = handle.GetSymbolAddress(symbol);
    if (UNLIKELY(!addr)) return false;
    return TrampolineInstaller::GetOrInitDefault()->NativeHookNoBackup(addr, replace);
}

EXPORT_C void PineNativeInlineHookFuncNoBackup(void* target, void* replace) {
    TrampolineInstaller::GetOrInitDefault()->NativeHookNoBackup(target, replace);
}

EXPORT_C void PineFillWithNop(void* target, size_t size) {
    TrampolineInstaller::GetOrInitDefault()->FillWithNop(target, size);
}

void Pine_init0(JNIEnv *env,
                jclass Pine,
                jint androidVersion,
                jboolean debug,
                jboolean debuggable,
                jboolean antiChecks,
                jboolean disableHiddenApiPolicy,
                jboolean disableHiddenApiPolicyForPlatformDomain) {
    PineConfig::debug = static_cast<bool>(debug);
    PineConfig::debuggable = static_cast<bool>(debuggable);
    PineConfig::anti_checks = static_cast<bool>(antiChecks);
    TrampolineInstaller::GetOrInitDefault(); // trigger TrampolineInstaller::default_ initialization
    Android::Init(env, androidVersion, disableHiddenApiPolicy, disableHiddenApiPolicyForPlatformDomain);
    {
        ScopedLocalClassRef Ruler(env, com___m4399___pierce___core___NativeMark);
        auto m1 = art::ArtMethod::Require(env, Ruler.Get(), m1(), "(F)V", true);
        auto m2 = art::ArtMethod::Require(env, Ruler.Get(), m2(), "()V", true);

        uint32_t expected_access_flags;
        do {
            ScopedLocalClassRef Method(env, "java/lang/reflect/Method");
            jmethodID getAccessFlags = Method.FindMethodID("getAccessFlags", "()I");
            if (LIKELY(getAccessFlags != nullptr)) {
                ScopedLocalRef javaM1(env, env->ToReflectedMethod(
                        Ruler.Get(), m1->ToMethodID(), JNI_TRUE));
                expected_access_flags = static_cast<uint32_t>(env->CallIntMethod(
                        javaM1.Get(), getAccessFlags));

                if (LIKELY(!env->ExceptionCheck())) break;

                LOGW("Method.getAccessFlags threw exception unexpectedly, use default access flags.");
                env->ExceptionDescribe();
                env->ExceptionClear();
            } else {
                LOGW("Method.getAccessFlags not found, use default access flags.");
            }
            expected_access_flags = AccessFlags::kPrivate | AccessFlags::kStatic | AccessFlags::kNative;
        } while (false);

        if (androidVersion >= Android::kQ) {
            expected_access_flags |= AccessFlags::kPublicApi;
        }

        ScopedLocalClassRef I(env, com___m4399___pierce___core___NativeMark$I);
        auto abstract_method = art::ArtMethod::Require(env, I.Get(), m(), "()V", false);
        art::ArtMethod::InitMembers(env, m1, m2, abstract_method, expected_access_flags);

        if (UNLIKELY(!art::ArtMethod::GetQuickToInterpreterBridge())) {
            // This is a workaround for art_quick_to_interpreter_bridge not found.
            // This case is almost impossible to enter
            // because its symbols are found almost always on all devices.
            // But if it happened... Try to get it with an abstract method (it is not compilable
            // and its entry is art_quick_to_interpreter_bridge)
            // Note: We DO NOT use platform's abstract methods
            // because their entry may not be interpreter entry.

            LOGE("art_quick_to_interpreter_bridge not found, try workaround");

            void* entry = abstract_method->GetEntryPointFromCompiledCode();
            LOGE("New art_quick_to_interpreter_bridge %p", entry);
            art::ArtMethod::SetQuickToInterpreterBridge(entry);
        }
    }

#define SET_JAVA_VALUE(name, sig, value) \
if (auto field = env->GetStaticFieldID(Pine, (name), (sig)); (sig)[0] == 'I') env->SetStaticIntField(Pine, field, (value)); \
else env->SetStaticLongField(Pine, field, (value));

    SET_JAVA_VALUE(int_arch, "I", kCurrentArch);
    SET_JAVA_VALUE(long_openElf, "J", reinterpret_cast<jlong>(PineOpenElf));
    SET_JAVA_VALUE(long_findElfSymbol, "J", reinterpret_cast<jlong>(PineGetElfSymbolAddress));
    SET_JAVA_VALUE(long_closeElf, "J", reinterpret_cast<jlong>(PineCloseElf));
    SET_JAVA_VALUE(long_getMethodDeclaringClass, "J", reinterpret_cast<jlong>(GetMethodDeclaringClass));
    SET_JAVA_VALUE(long_syncMethodEntry, "J", reinterpret_cast<jlong>(SyncMethodEntry));
    SET_JAVA_VALUE(long_suspendVM, "J", reinterpret_cast<jlong>(PineSuspendVM));
    SET_JAVA_VALUE(long_resumeVM, "J", reinterpret_cast<jlong>(PineResumeVM));
#undef SET_JAVA_VALUE
}

static jfieldID GetHookRecordTrampolineField(JNIEnv* env, jobject hookRecord) {
    static jfieldID field = [&]() {
        jclass HookRecord = env->GetObjectClass(hookRecord);
        jfieldID field = env->GetFieldID(HookRecord, long_trampoline, "J");
        env->DeleteLocalRef(HookRecord);
        return field;
    }();
    return field;
}

jobject Pine_hook0(JNIEnv *env,
                   jclass,
                   jlong threadAddress,
                   jclass declaring,
                   jobject hookRecord,
                   jobject javaTarget,
                   jobject javaBridge,
                   jobject javaBackup,
                   jboolean isInlineHook,
                   jboolean isJni,
                   jboolean isProxy) {
    std::string targetMethodDesc = JNIHelper::methodToString(env,javaTarget);
    ThreadLocalVar::setTargetMethodDesc(targetMethodDesc);

    jfieldID HookRecord_trampoline = GetHookRecordTrampolineField(env, hookRecord);
    auto thread = reinterpret_cast<art::Thread*>(threadAddress);
    auto target = art::ArtMethod::FromReflectedMethod(env, javaTarget);
    auto bridge = art::ArtMethod::FromReflectedMethod(env, javaBridge);
    auto backup = art::ArtMethod::FromReflectedMethod(env, javaBackup);

    ALWAYSLOGI("pierce_hook0, %s targetEntryPointFromCompiledCode=%p bridgeEntryPointFromCompiledCode=%p backupEntryPointFromCompiledCode=%p",
               targetMethodDesc.c_str(),
               target->GetEntryPointFromCompiledCode(),
               bridge->GetEntryPointFromCompiledCode(),
               backup->GetEntryPointFromCompiledCode());


    if (PineConfig::jit_compilation_allowed && PineConfig::auto_compile_bridge) {
        // The bridge method entry will be hardcoded in the trampoline, subsequent optimization
        // operations that require modification of the bridge method entry will not take effect.
        // Try to do JIT compilation first to get the best performance.
        bridge->Compile(thread);

        ALWAYSLOGI("pierce_hook0, %s after bridge->compile(thread), targetEntryPointFromCompiledCode=%p bridgeEntryPointFromCompiledCode=%p backupEntryPointFromCompiledCode=%p",
                   targetMethodDesc.c_str(),
                   target->GetEntryPointFromCompiledCode(),
                   bridge->GetEntryPointFromCompiledCode(),
                   backup->GetEntryPointFromCompiledCode());
    }

    bool is_inline_hook = JBOOL_TRUE(isInlineHook);
    const bool is_native = JBOOL_TRUE(isJni);
    const bool is_proxy = JBOOL_TRUE(isProxy);
    const bool is_native_or_proxy = is_native || is_proxy;

    TrampolineInstaller *trampoline_installer = TrampolineInstaller::GetDefault();

    if (is_inline_hook && (trampoline_installer->IsReplacementOnly() || !target->IsCompiled())) {
        LOGW("pierce_hook0, %s targetEntryPointFromCompiledCode=%p IsReplacementOnly=%d targetIsCompiled=%d force replacement mode.",
             targetMethodDesc.c_str(),
             target->GetEntryPointFromCompiledCode(),
             trampoline_installer->IsReplacementOnly(),
             target->IsCompiled());
        is_inline_hook = false;
    }

    if (UNLIKELY(is_inline_hook && trampoline_installer->CannotSafeInlineHook(target))) {
        LOGW("pierce_hook0, %s targetGetEntryPointFromCompiledCode=%p Cannot safe inline hook the target method, force replacement mode.",
             targetMethodDesc.c_str(),
             target->GetEntryPointFromCompiledCode());
        is_inline_hook = false;
    }

    bool skip_first_few_bytes = PineConfig::anti_checks
                                && is_inline_hook && trampoline_installer->CanSkipFirstFewBytes(target);

    void *new_entrypoint;
    char error_msg[512] = {0};
    {
        // ArtMethod objects are very important. Many threads depend on their values,
        // so we need to suspend other threads to avoid errors.
        ScopedSuspendVM suspend_vm(thread);

        void *call_origin = is_inline_hook
                            ? trampoline_installer->InstallInlineTrampoline(target, bridge, skip_first_few_bytes)
                            : trampoline_installer->InstallReplacementTrampoline(target, bridge);

        ALWAYSLOGI("pierce_hook0, %s after InstallTrampoline is_inline_hook=%d skip_first_few_bytes=%d call_origin=%p",
                   targetMethodDesc.c_str(),
                   is_inline_hook,
                   skip_first_few_bytes,
                   call_origin);

        if (LIKELY(call_origin)) {
            backup->BackupFrom(target, call_origin, is_inline_hook, is_native, is_proxy);
            target->AfterHook(is_inline_hook, is_native_or_proxy);
            new_entrypoint = target->GetEntryPointFromCompiledCode();
        } else {
            snprintf(error_msg, sizeof(error_msg), "%s Failed to install %s trampoline on method %p: %s (%d).",
                     targetMethodDesc.c_str(),
                     is_inline_hook ? "inline" : "replacement",
                     target,
                     strerror(errno),
                     errno);
            if (errno == EACCES || errno == EPERM)
                strlcat(error_msg, " This is a security failure, check selinux policy, seccomp or capabilities. Earlier log may point out root cause.", sizeof(error_msg));
            LOGE("%s", error_msg);
            new_entrypoint = nullptr;
        }
    }

    if (LIKELY(new_entrypoint)) {
        env->SetLongField(hookRecord, HookRecord_trampoline, reinterpret_cast<jlong>(new_entrypoint));

        ALWAYSLOGI("pierce_hook0, %s after hook is_inline_hook=%d targetEntryPointFromCompiledCode=%p bridgeEntryPointFromCompiledCode=%p backupEntryPointFromCompiledCode=%p",
                   targetMethodDesc.c_str(),
                   is_inline_hook,
                   target->GetEntryPointFromCompiledCode(),
                   bridge->GetEntryPointFromCompiledCode(),
                   backup->GetEntryPointFromCompiledCode());

        return javaBackup;
    } else {
        JNIHelper::Throw(env, errno == EACCES || errno == EPERM ? "java/lang/SecurityException" : "java/lang/RuntimeException", error_msg);
        return nullptr;
    }
}

jobject Pine_hookReplace(JNIEnv* env, jclass, jlong threadAddress, jclass declaring, jobject hookRecord,
                         jobject javaTarget, jobject javaReplacement, jobject javaBackup,
                         jboolean isInlineHook, jboolean isJni, jboolean isProxy) {
    jfieldID HookRecord_trampoline = GetHookRecordTrampolineField(env, hookRecord);
    auto thread = reinterpret_cast<art::Thread*>(threadAddress);
    auto target = art::ArtMethod::FromReflectedMethod(env, javaTarget);
    auto replacement = art::ArtMethod::FromReflectedMethod(env, javaReplacement);
    auto backup = art::ArtMethod::FromReflectedMethod(env, javaBackup);

    bool is_inline_hook = JBOOL_TRUE(isInlineHook);
    const bool is_native = JBOOL_TRUE(isJni);
    const bool is_proxy = JBOOL_TRUE(isProxy);
    const bool is_native_or_proxy = is_native || is_proxy;

    TrampolineInstaller* trampoline_installer = TrampolineInstaller::GetDefault();

    if (is_inline_hook && (trampoline_installer->IsReplacementOnly() || !target->IsCompiled())) {
        LOGW("Pierce_hookReplace isReplacementOnly=%d targetIsCompiled=%d force replacement mode.",
             trampoline_installer->IsReplacementOnly(),target->IsCompiled());
        is_inline_hook = false;
    }

    if (UNLIKELY(is_inline_hook && trampoline_installer->CannotSafeInlineHook(target))) {
        LOGW("Pierce_hookReplace Cannot safe inline hook the target method, force replacement mode.");
        is_inline_hook = false;
    }

    bool skip_first_few_bytes = PineConfig::anti_checks && is_inline_hook
            && trampoline_installer->CanSkipFirstFewBytes(target);
    void* new_entrypoint;
    char error_msg[288];
    {
        // ArtMethod objects are very important. Many threads depend on their values,
        // so we need to suspend other threads to avoid errors.
        ScopedSuspendVM suspend_vm(thread);

        void* call_origin = is_inline_hook
                            ? trampoline_installer->InstallDirectJumpInlineTrampoline(target, replacement, skip_first_few_bytes)
                            : trampoline_installer->InstallDirectJumpReplacementTrampoline(target, replacement);
        LOGI("Pierce_hookReplace is_inline_hook=%d call_origin=%p",is_inline_hook,call_origin);

        if (LIKELY(call_origin)) {
            backup->BackupFrom(target, call_origin, is_inline_hook, is_native, is_proxy);
            target->AfterHook(is_inline_hook, is_native_or_proxy);
            new_entrypoint = target->GetEntryPointFromCompiledCode();
            LOGI("Pierce_hookReplace AfterHook after targetEntryPointFromCompiledCode=%p ",
                     target->GetEntryPointFromCompiledCode());
        } else {
            snprintf(error_msg, sizeof(error_msg), "Failed to install %s trampoline on method %p: %s (%d).",
                     is_inline_hook ? "inline" : "replacement", target, strerror(errno), errno);
            if (errno == EACCES || errno == EPERM)
                strlcat(error_msg, " This is a security failure, check selinux policy, seccomp or capabilities. Earlier log may point out root cause.", sizeof(error_msg));
            LOGE("%s", error_msg);
            new_entrypoint = nullptr;
        }
    }

    if (LIKELY(new_entrypoint)) {
        env->SetLongField(hookRecord, HookRecord_trampoline, reinterpret_cast<jlong>(new_entrypoint));
        return env->ToReflectedMethod(declaring, backup->ToMethodID(),
                                      static_cast<jboolean>(backup->IsStatic()));
    } else {
        JNIHelper::Throw(env, errno == EACCES || errno == EPERM ? "java/lang/SecurityException" : "java/lang/RuntimeException", error_msg);
        return nullptr;
    }
}

jlong Pine_getArtMethod(JNIEnv* env, jclass, jobject javaMethod) {
    return static_cast<jlong>(reinterpret_cast<uintptr_t>(
            art::ArtMethod::FromReflectedMethod(env, javaMethod)));
}

jboolean Pine_compile0(JNIEnv* env, jclass, jlong thread, jobject javaMethod) {
    return static_cast<jboolean>(art::ArtMethod::FromReflectedMethod(env, javaMethod)->Compile(
            reinterpret_cast<art::Thread*>(thread)));
}

jboolean Pine_decompile0(JNIEnv* env, jclass, jobject javaMethod, jboolean disableJit) {
    return static_cast<jboolean>(art::ArtMethod::FromReflectedMethod(env, javaMethod)->Decompile(
            disableJit));
}

jboolean Pine_disableJitInline0(JNIEnv*, jclass) {
    return static_cast<jboolean>(art::Jit::DisableInline());
}

void Pine_setJitCompilationAllowed(JNIEnv*, jclass, jboolean allowed, jboolean autoCompileBridge) {
    PineConfig::jit_compilation_allowed = JBOOL_TRUE(allowed);
    PineConfig::auto_compile_bridge = JBOOL_TRUE(autoCompileBridge);
}

jboolean Pine_disableProfileSaver0(JNIEnv*, jclass) {
    return static_cast<jboolean>(Android::DisableProfileSaver());
}

jobject Pine_getObject0(JNIEnv* env, jclass, jlong thread, jlong address) {
    return reinterpret_cast<art::Thread*>(thread)->AddLocalRef(env, reinterpret_cast<Object*>(address));
}

jlong Pine_getAddress0(JNIEnv*, jclass, jlong thread, jobject o) {
    return reinterpret_cast<jlong>(reinterpret_cast<art::Thread*>(thread)->DecodeJObject(o));
}

void Pine_syncMethodInfo(JNIEnv *env, jclass, jobject javaOrigin, jobject javaBackup, jboolean skipDeclaringClass) {
    auto origin = art::ArtMethod::FromReflectedMethod(env, javaOrigin);
    auto backup = art::ArtMethod::FromReflectedMethod(env, javaBackup);

    // An ArtMethod is actually an instance of java class "java.lang.reflect.ArtMethod" on pre M
    // declaring_class is a reference field so the runtime itself will update it if moved by GC
    if (skipDeclaringClass == JNI_FALSE && Android::version >= Android::kM) {
        uint32_t declaring_class = origin->GetDeclaringClass();
        if (declaring_class != backup->GetDeclaringClass()) {
            LOGD("GC moved declaring class of method %p, also update in backup %p", origin, backup);
            backup->SetDeclaringClass(declaring_class);
        }
    }

    // JNI method entry might be changed by RegisterNatives or UnregisterNatives
    // Use backup to check native as we may add kNative to access flags of origin (Android 8.0+ with debuggable mode)
    if (backup->IsNative()) {
        void *previous = backup->GetEntryPointFromJni();
        void *current = origin->GetEntryPointFromJni();
        if (current != previous) {
            LOGD("Native entry of method %p was changed, also update in backup %p", origin, backup);
            backup->SetEntryPointFromJni(current);
        }
    }
}

void Pine_setDebuggable(JNIEnv*, jclass, jboolean debuggable) {
    PineConfig::debuggable = static_cast<bool>(debuggable);
}

void Pine_disableHiddenApiPolicy0(JNIEnv*, jclass, jboolean application, jboolean platform) {
    Android::DisableHiddenApiPolicy(application, platform);
}

jlong Pine_currentArtThread0(JNIEnv* env, jclass) {
    return reinterpret_cast<jlong>(art::Thread::Current(env));
}

void Pine_makeClassesVisiblyInitialized(JNIEnv*, jclass, jlong thread) {
    Android::MakeInitializedClassesVisiblyInitialized(reinterpret_cast<void*>(thread), true);
}

//pierce特有
jlong Pine_getArtMethodEntryPointFromCompiledCode(JNIEnv *env, jclass, jobject javaMethod) {
    return static_cast<jlong>(reinterpret_cast<uintptr_t>(
            art::ArtMethod::FromReflectedMethod(env, javaMethod)->GetEntryPointFromCompiledCode()
    ));
}

//pierce特有
jstring Pine_getArtMethodEntryPointHexString(JNIEnv* env, jclass, jobject javaMethod,jint maxDumpHexSize) {
    auto artMethod = art::ArtMethod::FromReflectedMethod(env, javaMethod);
    void* entryPointFromCompiledCode = artMethod->GetEntryPointFromCompiledCode();
    void* codeAddr = artMethod->GetCompiledCodeAddr();
    int codeSize = -1;
    int realDumpCodeSize = -1;
    std::string targetCodeAddrDumpHex = "";
    if(artMethod->IsCompiled()){
        codeSize = artMethod->GetCompiledCodeSize();
        realDumpCodeSize = codeSize;
        if((realDumpCodeSize <= 0) || (realDumpCodeSize > maxDumpHexSize)){
            realDumpCodeSize = maxDumpHexSize;
        }
    } else {
        //如果没有编译，只读取0x30个字节，防止越界
        realDumpCodeSize = 0x30;
    }

    string codeAddrMapInfo = memutil::findAddressMapInfo((intptr_t) codeAddr);
    ALWAYSLOGI("Pine_getArtMethodEntryPointHexString hexdump before: artMethod->IsCompiled()=%d artMethod=%p"
               " entryPointFromCompiledCode=%p codeAddr=%p codeSize=0x%x codeAddrMapInfo=%s realDumpCodeSize=0x%x ",
               artMethod->IsCompiled(),
               artMethod,
               entryPointFromCompiledCode,
               codeAddr,
               codeSize,
               codeAddrMapInfo.c_str(),
               realDumpCodeSize);

    if (realDumpCodeSize > 0) {
        //要dump的内存没有权限
        //"Pine_getArtMethodEntryPointHexString: artMethod->IsCompiled()=0 artMethod=0x7a82799110 entryPointFromCompiledCode=0x7a8b36c410 codeAddr=0x7a8b36c410 codeSize=0xffffffff codeAddrMapInfo=7a8b35a000-7a8b4bf000 --xp 0012e000 103:1a 361                           /apex/com.android.runtime/lib64/libart.so realDumpCodeSize=0x0 targetCodeAddrDumpHex="
        memutil::rx(codeAddr, realDumpCodeSize);
        codeAddrMapInfo = memutil::findAddressMapInfo((intptr_t) codeAddr);
        targetCodeAddrDumpHex = memutil::hexdump(reinterpret_cast<uintptr_t>(codeAddr), realDumpCodeSize);
    }

    char tmp[2048] = {0};
    snprintf(tmp, sizeof(tmp),
             "Pine_getArtMethodEntryPointHexString: artMethod->IsCompiled()=%d artMethod=%p \nentryPointFromCompiledCode=%p codeAddr=%p codeSize=0x%x codeAddrMapInfo=",
             artMethod->IsCompiled(),
             artMethod,
             entryPointFromCompiledCode,
             codeAddr,
             codeSize);
    std::string result(tmp);

    result += memutil::findAddressMapInfo((intptr_t) codeAddr);

    snprintf(tmp, sizeof(tmp),
             " \nrealDumpCodeSize=0x%x targetCodeAddrDumpHex=\n",
             realDumpCodeSize);
    result += tmp;
    result += targetCodeAddrDumpHex;

    ALWAYSLOGI("%s", result.c_str());
    return env->NewStringUTF(result.c_str());
}

static jboolean Pine_generateDex(JNIEnv *env,
                                 jclass clazz,
                                 jstring dexPath,
                                 jobject targetMethod,
                                 jboolean isStatic,
                                 jobject handleCallMethod,
                                 jstring generateClassName,
                                 jstring generateMethodName,
                                 jstring generateBackupMethodName,
                                 jstring generateShorty,
                                 jstring generateFieldName) {
    return DexBuilderUtil::generateDexFile(env,
                                           clazz,
                                           dexPath,
                                           targetMethod,
                                           isStatic,
                                           handleCallMethod,
                                           generateClassName,
                                           generateMethodName,
                                           generateBackupMethodName,
                                           generateShorty,
                                           generateFieldName);
}

static void Pine_setLogFilePath(JNIEnv *env,
                                jclass clazz,
                                jstring jstrLogFilePath) {
    std::string logFilePath = JNIHelper::jstringToString(env,jstrLogFilePath);
    CFileLog::getInstance().setFilePath(logFilePath);
}

static jboolean Pine_writeLogToFile(JNIEnv *env,
                                    jclass clazz,
                                    jstring jstrLevel,
                                    jstring jstrTag,
                                    jstring jstrMsg) {
    bool isValidRet = CFileLog::getInstance().isValid();
    if (!isValidRet) {
        return JNI_FALSE;
    }

    std::string level = JNIHelper::jstringToString(env, jstrLevel);

    std::string tag = JNIHelper::jstringToString(env, jstrTag);

    std::string msg = JNIHelper::jstringToString(env, jstrMsg);

    bool ret = CFileLog::getInstance().javaLog(level, tag, msg);
    return ret ? JNI_TRUE : JNI_FALSE;
}

static const struct {
    const char *name;
    const char *signature;
} gFastNativeMethods[] = {
        {getArtMethod(),              "(Ljava/lang/reflect/Member;)J"},
        {syncMethodInfo(),            "(Ljava/lang/reflect/Member;Ljava/lang/reflect/Method;Z)V"},
        {decompile0(),                "(Ljava/lang/reflect/Member;Z)Z"},
        {disableJitInline0(),         "()Z"},
        {setJitCompilationAllowed0(), "(ZZ)V"},
        {disableProfileSaver0(),      "()Z"},
        {getObject0(),                "(JJ)Ljava/lang/Object;"},
        {getAddress0(),               "(JLjava/lang/Object;)J"},
        {setDebuggable0(),            "(Z)V"},
        {disableHiddenApiPolicy0(),   "(ZZ)V"},
        {currentArtThread0(),         "()J"},
};

void Pine_enableFastNative(JNIEnv* env, jclass Pine) {
    LOGI("Experimental feature FastNative is enabled.");
    for (auto& method_info : gFastNativeMethods) {
        auto method = art::ArtMethod::Require(env, Pine, method_info.name, method_info.signature, true);
        assert(method != nullptr);
        method->SetFastNative();
    }
}

static const JNINativeMethod gMethods[] = {
        {init0(),                                  "(IZZZZZ)V",                                                                                                                                                                                 (void *) Pine_init0},
        {enableFastNative(),                       "()V",                                                                                                                                                                                       (void *) Pine_enableFastNative},
        {getArtMethod(),                           "(Ljava/lang/reflect/Member;)J",                                                                                                                                                             (void *) Pine_getArtMethod},
        {hook0(),                                  "(JLjava/lang/Class;" com___m4399___pierce___core___Pierce$HookRecord___name "Ljava/lang/reflect/Member;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;ZZZ)Ljava/lang/reflect/Method;", (void *) Pine_hook0},
        {hookReplace0(),                           "(JLjava/lang/Class;" com___m4399___pierce___core___Pierce$HookRecord___name "Ljava/lang/reflect/Member;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;ZZZ)Ljava/lang/reflect/Method;", (void *) Pine_hookReplace},
        {compile0(),                               "(JLjava/lang/reflect/Member;)Z",                                                                                                                                                            (void *) Pine_compile0},
        {decompile0(),                             "(Ljava/lang/reflect/Member;Z)Z",                                                                                                                                                            (void *) Pine_decompile0},
        {disableJitInline0(),                      "()Z",                                                                                                                                                                                       (void *) Pine_disableJitInline0},
        {setJitCompilationAllowed0(),              "(ZZ)V",                                                                                                                                                                                     (void *) Pine_setJitCompilationAllowed},
        {disableProfileSaver0(),                   "()Z",                                                                                                                                                                                       (void *) Pine_disableProfileSaver0},
        {syncMethodInfo(),                         "(Ljava/lang/reflect/Member;Ljava/lang/reflect/Method;Z)V",                                                                                                                                  (void *) Pine_syncMethodInfo},
        {getObject0(),                             "(JJ)Ljava/lang/Object;",                                                                                                                                                                    (void *) Pine_getObject0},
        {getAddress0(),                            "(JLjava/lang/Object;)J",                                                                                                                                                                    (void *) Pine_getAddress0},
        {setDebuggable0(),                         "(Z)V",                                                                                                                                                                                      (void *) Pine_setDebuggable},
        {disableHiddenApiPolicy0(),                "(ZZ)V",                                                                                                                                                                                     (void *) Pine_disableHiddenApiPolicy0},
        {currentArtThread0(),                      "()J",                                                                                                                                                                                       (void *) Pine_currentArtThread0},
        {makeClassesVisiblyInitialized(),          "(J)V",                                                                                                                                                                                      (void *) Pine_makeClassesVisiblyInitialized},
        {getArtMethodEntryPointFromCompiledCode(), "(Ljava/lang/reflect/Member;)J",                                                                                                                                                             (void *) Pine_getArtMethodEntryPointFromCompiledCode},
        {getArtMethodEntryPointHexString(),        "(Ljava/lang/reflect/Member;I)Ljava/lang/String;",                                                                                                                                           (void *) Pine_getArtMethodEntryPointHexString},
        {generateDex(),                            "(Ljava/lang/String;Ljava/lang/reflect/Member;ZLjava/lang/reflect/Method;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z",                      (void *) Pine_generateDex},
        {setLogFilePath(),                         "(Ljava/lang/String;)V",                                                                                                                                                                     (void *) Pine_setLogFilePath},
        {writeLogToFile(),                         "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z",                                                                                                                                 (void *) Pine_writeLogToFile}
};

bool register_Pine(JNIEnv* env, jclass Pine) {
    return LIKELY(env->RegisterNatives(Pine, gMethods, NELEM(gMethods)) == JNI_OK);
}
