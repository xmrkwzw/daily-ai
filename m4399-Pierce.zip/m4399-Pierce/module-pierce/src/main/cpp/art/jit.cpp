//
// Created by canyie on 2020/3/15.
//

#include "jit.h"
#include "../android.h"
#include "../utils/memutil.h"

using namespace pierce::art;

JitCompiler* Jit::self_compiler = nullptr;

bool (*Jit::jit_compile_method)(void*, void*, void*, bool) = nullptr;

bool (*Jit::jit_compile_method_q)(void*, void*, void*, bool, bool) = nullptr;

void** Jit::jit_update_options_ptr = nullptr;

JitCompiler** Jit::global_compiler_ptr = nullptr;

Member<void, size_t>* Jit::CompilerOptions_inline_max_code_units = nullptr;

void Jit::Init(const ElfImage* art_lib_handle, const ElfImage* jit_lib_handle) {

    //android 7.0 7.1 8.0 9.0
    //// JIT compiler
    //void* Jit::jit_library_handle_= nullptr;
    //void* Jit::jit_compiler_handle_ = nullptr;
    //void* (*Jit::jit_load_)(bool*) = nullptr;
    //void (*Jit::jit_unload_)(void*) = nullptr;
    //bool (*Jit::jit_compile_method_)(void*, ArtMethod*, Thread*, bool) = nullptr;
    //void (*Jit::jit_types_loaded_)(void*, mirror::Class**, size_t count) = nullptr;
    //bool Jit::generate_debug_info_ = false;

    //android 10
    //// JIT compiler
    //void* Jit::jit_library_handle_ = nullptr;
    //void* Jit::jit_compiler_handle_ = nullptr;
    //void* (*Jit::jit_load_)(void) = nullptr;
    //void (*Jit::jit_unload_)(void*) = nullptr;
    //bool (*Jit::jit_compile_method_)(void*, ArtMethod*, Thread*, bool, bool) = nullptr;
    //void (*Jit::jit_types_loaded_)(void*, mirror::Class**, size_t count) = nullptr;
    //bool (*Jit::jit_generate_debug_info_)(void*) = nullptr;
    //void (*Jit::jit_update_options_)(void*) = nullptr;

    //android 11 12.0 12.1 13 14
    //// JIT compiler
    //void* Jit::jit_library_handle_ = nullptr;
    //JitCompilerInterface* Jit::jit_compiler_ = nullptr;
    //JitCompilerInterface* (*Jit::jit_load_)(void) = nullptr;

    //android 15 16
    //// JIT compiler
    //JitCompilerInterface* Jit::jit_compiler_ = nullptr;

    global_compiler_ptr = static_cast<JitCompiler**>(art_lib_handle->GetSymbolAddress(
            "_ZN3art3jit3Jit20jit_compiler_handle_E"));

    ALWAYSLOGI("Jit::Init global_compiler_ptr=%p",global_compiler_ptr);
    if(nullptr != global_compiler_ptr){
        ALWAYSLOGI("Jit::Init *global_compiler_ptr=%p",*global_compiler_ptr);
    }

    auto jit_load = reinterpret_cast<JitCompiler* (*)(bool*)>(jit_lib_handle->GetSymbolAddress(
            "jit_load"));

    ALWAYSLOGI("Jit::Init jit_load=%p",jit_load);

    if (LIKELY(jit_load)) {
        bool generate_debug_info = false;
        self_compiler = jit_load(&generate_debug_info);
    } else {
        LOGW("Jit::Init Failed to create new JitCompiler: jit_load not found");
    }
    ALWAYSLOGI("Jit::Init self_compiler=%p",self_compiler);

    // FIXME: jit_compile_method doesn't exist in Android R
    void* jit_compile_method = jit_lib_handle->GetSymbolAddress("jit_compile_method");

    if (Android::version >= Android::kQ) {
        Jit::jit_compile_method_q = reinterpret_cast<bool (*)(void*, void*, void*, bool, bool)>(jit_compile_method);
        // Android Q, ART may update CompilerOptions and the value we set will be overwritten.
        // the function pointer saved in art::jit::Jit::jit_update_options_ .
        Jit::jit_update_options_ptr = static_cast<void**>(art_lib_handle->GetSymbolAddress(
                "_ZN3art3jit3Jit19jit_update_options_E"));

        ALWAYSLOGI("Jit::Init Jit::jit_compile_method_q=%p Jit::jit_update_options_ptr=%p",Jit::jit_compile_method_q,Jit::jit_update_options_ptr);
    } else {
        Jit::jit_compile_method = reinterpret_cast<bool (*)(void*, void*, void*, bool)>(jit_compile_method);
        ALWAYSLOGI("Jit::Init Jit::jit_compile_method=%p",Jit::jit_compile_method);
    }

    //android 7.0 7.1
    //  CompilerFilter::Filter compiler_filter_;
    //  size_t huge_method_threshold_;
    //  size_t large_method_threshold_;
    //  size_t small_method_threshold_;
    //  size_t tiny_method_threshold_;
    //  size_t num_dex_methods_threshold_;
    //  size_t inline_depth_limit_;
    //  size_t inline_max_code_units_;

    // android 8.0 8.1 9.0 10.0
    //  CompilerFilter::Filter compiler_filter_;
    //  size_t huge_method_threshold_;
    //  size_t large_method_threshold_;
    //  size_t small_method_threshold_;
    //  size_t tiny_method_threshold_;
    //  size_t num_dex_methods_threshold_;
    //  size_t inline_max_code_units_;

    //  android 11.0 12.0 12.1 13
    //  CompilerFilter::Filter compiler_filter_;
    //  size_t huge_method_threshold_;
    //  size_t large_method_threshold_;
    //  size_t num_dex_methods_threshold_;
    //  size_t inline_max_code_units_;

    // android 14 15  16
    //  CompilerFilter::Filter compiler_filter_;
    //  size_t huge_method_threshold_;
    //  size_t inline_max_code_units_;

    // fields count from compiler_filter_ (not included) to inline_max_code_units_ (not included)
    // FIXME Offset for inline_max_code_units_ seems to be incorrect on my Pixel 3 (Android 10)...
    // FIXME Structure of CompilerOptions has changed in Android R.
    unsigned thresholds_count = Android::version >= Android::kO ? 5 : 6;

    CompilerOptions_inline_max_code_units = new Member<void, size_t>(
            sizeof(void*) + thresholds_count * sizeof(size_t));
}

bool Jit::useJit() {
    bool ret = false;
    if (nullptr != global_compiler_ptr) {
        if (nullptr != *global_compiler_ptr) {
            ret = true;
        }
    }
    return ret;
}

bool Jit::CompileMethod(Thread* thread, void* method) {
    if (LIKELY(Android::version >= Android::kR)) {
        LOGW("JIT compilation is not supported in Android R yet");
        return false;
    }
    void* compiler = GetCompiler();
    if (UNLIKELY(!compiler)) {
        LOGE("No JitCompiler available for JIT compilation!");
        return false;
    }

    bool result;

    // JIT compilation will modify the state of the thread, so we backup and restore it after compilation.
    int32_t origin_state_and_flags = thread->GetStateAndFlags();

    if (jit_compile_method) {
        result = jit_compile_method(compiler, method, thread, false/*osr*/);
    } else if (jit_compile_method_q) {
        result = jit_compile_method_q(compiler, method, thread, false/*baseline*/, false/*osr*/);
    } else {
        LOGE("Compile method failed: jit_compile_method not found");
        return false;
    }

    thread->SetStateAndFlags(origin_state_and_flags);
    return result;
}

static void fake_jit_update_options(void* handle) {
    LOGI("Ignoring request to update CompilerOptions from ART.");
}

bool Jit::DisableInline() {
    if (LIKELY(Android::version >= Android::kR)) {
        //版本 >= Android 11
        LOGW("Disable JIT inline failed: JIT API is not supported in Android R yet");
        return false;
    }

    JitCompiler* compiler = GetGlobalCompiler();
    if (UNLIKELY(!compiler)) {
        LOGE("Disable JIT inline failed: JitCompiler is not available now!");
        return false;
    }

//    size_t dumpHexSize = 0x100;
//    string jitCompilerDumpHex = memutil::hexdump(reinterpret_cast<uintptr_t>(compiler), dumpHexSize);
//    LOGI("Disable JIT inline: compiler=%p dumpHexSize=%zu jitCompilerDumpHex=\n%s",
//         compiler,
//         dumpHexSize,
//         jitCompilerDumpHex.c_str()
//    );

    void* compiler_options = compiler->compiler_options_.get();
    if (UNLIKELY(!compiler_options)) {
        LOGE("Disable JIT inline failed: JIT CompilerOptions is null");
        return false;
    }
    size_t inline_max_code_units = CompilerOptions_inline_max_code_units->Get(compiler_options);

//    dumpHexSize = CompilerOptions_inline_max_code_units->GetOffset() + 0x50;
//    string compilerOptionsDumpHex = memutil::hexdump(reinterpret_cast<uintptr_t>(compiler_options), dumpHexSize);
//    LOGI("Disable JIT inline: compiler=%p compilerOptions=%p inline_max_code_units=%zu offset=%d dumpHexSize=%zu compilerOptionsDumpHex=\n%s",
//         compiler,
//         compiler_options,
//         inline_max_code_units,
//         CompilerOptions_inline_max_code_units->GetOffset(),
//         dumpHexSize,
//         compilerOptionsDumpHex.c_str()
//    );

    if (LIKELY(inline_max_code_units >= 0 && inline_max_code_units <= 1024)) {
        ALWAYSLOGI("Disable JIT inline success: compiler=%p compilerOptions=%p old_inline_max_code_units=%zu offset=%d ",
                    compiler,
                    compiler_options,
                    inline_max_code_units,
                    CompilerOptions_inline_max_code_units->GetOffset());

        if (jit_update_options_ptr) {
            // Android Q, hook art::jit::Jit::jit_update_options_ to avoid update CompilerOptions.
            if (LIKELY(*jit_update_options_ptr))
                *jit_update_options_ptr = reinterpret_cast<void*>(fake_jit_update_options);
            else
                LOGW("Disable JIT inline failed: Not hooking jit_update_options: symbol found but the function it points to is invalid.");
        }
        CompilerOptions_inline_max_code_units->Set(compiler_options, 0);
        return true;
    } else {
        // It is not a normal inline_max_code_units. It may be that the offset is changed
        // due to the source code modified by the manufacturer of the device.
        LOGE("Disable JIT inline failed: Unexpected inline_max_code_units value %u (offset %d).", inline_max_code_units,
             CompilerOptions_inline_max_code_units->GetOffset());
        return false;
    }
}
