//
// Created by canyie on 2020/3/15.
//

#ifndef PINE_JIT_H
#define PINE_JIT_H

#include <memory>
#include "../utils/macros.h"
#include "thread.h"
#include "../utils/log.h"
#include "../utils/member.h"
#include "../utils/elf_image.h"

namespace pierce::art {
    class JitCompiler final {
    public:
        //android 7-16 compiler_options_ 的位置没有变
        std::unique_ptr<void> vtptr_;
        std::unique_ptr<void> compiler_options_;
    private:
        DISALLOW_IMPLICIT_CONSTRUCTORS(JitCompiler);
    };

    class Jit final {
    public:
        static void Init(const ElfImage* art_lib_handle, const ElfImage* jit_lib_handle);

        static bool useJit();

        static JitCompiler* GetCompiler() {
            bool useJitCompilation = useJit();
            if(!useJitCompilation){
                return nullptr;
            }

            return LIKELY(self_compiler) ? self_compiler : GetGlobalCompiler();
        }

        static JitCompiler* GetGlobalCompiler() {
            return LIKELY(global_compiler_ptr) ? *global_compiler_ptr : nullptr;
        }

        static bool CompileMethod(Thread* thread, void* method);

        static bool DisableInline();

    private:
        static JitCompiler* self_compiler;

        static bool (*jit_compile_method)(void*, void*, void*, bool);

        static bool (*jit_compile_method_q)(void*, void*, void*, bool, bool);

        static JitCompiler** global_compiler_ptr;

        static void** jit_update_options_ptr;

        static Member<void, size_t>* CompilerOptions_inline_max_code_units;

        DISALLOW_IMPLICIT_CONSTRUCTORS(Jit);
    };

}

#endif //PINE_JIT_H
