#include "DexBuilderUtil.h"
#include "dex_builder.h"
#include <chrono>
#include <sys/stat.h>
#include <fstream>
#include "../../utils/log.h"
#include "../../utils/jni_helper.h"

using namespace startop::dex;
using namespace pierce;

jboolean DexBuilderUtil::generateDexFile(JNIEnv *env,
                                         jclass clazz,
                                         jstring dexPath,
                                         jobject targetMethod,
                                         jboolean isStatic,
                                         jobject handleCallMethod,
                                         jstring generateClassName,
                                         jstring generateMethodName,
                                         jstring generateBackupMethodName,
                                         jstring generateShorty,
                                         jstring generateFieldName) {
    if (!dexPath
        || !targetMethod
        || !handleCallMethod
        || !generateClassName
        || !generateMethodName
        || !generateBackupMethodName
        || !generateShorty
        || !generateFieldName) {
        LOGE("DexBuilderUtil::generateDexFile One or more parameters are null");
        return JNI_FALSE;
    }

    std::string path = JNIHelper::jstringToString(env, dexPath);

    std::string genClassName = JNIHelper::jstringToString(env, generateClassName);
    std::string genMethodName = JNIHelper::jstringToString(env, generateMethodName);
    std::string genBackupMethodName = JNIHelper::jstringToString(env, generateBackupMethodName);
    std::string genShorty = JNIHelper::jstringToString(env, generateShorty);
    std::string genFieldName = JNIHelper::jstringToString(env, generateFieldName);
    bool isTargetMethodStatic = JNIHelper::jbooleanToBool(isStatic);
    std::string handleCallClassName = JNIHelper::getDeclaringClassName(env, handleCallMethod);
    std::string handleCallMethodName = JNIHelper::getMethodName(env, handleCallMethod);
    std::string targetMethodDesc = JNIHelper::methodToString(env, targetMethod);
    ALWAYSLOGI("DexBuilderUtil::generateDexFile dexPath=%s target=%s, shorty=%s, static=%d, handleCall=%s.%s",
               path.c_str(), targetMethodDesc.c_str(), genShorty.c_str(), isTargetMethodStatic,
               handleCallClassName.c_str(), handleCallMethodName.c_str());

    bool ret = innerGenerateDexFile(path,
                                    genClassName,
                                    genMethodName,
                                    genBackupMethodName,
                                    genShorty,
                                    genFieldName,
                                    isTargetMethodStatic,
                                    handleCallClassName,
                                    handleCallMethodName);
    return JNIHelper::boolToJoolean(ret);
}

bool DexBuilderUtil::innerGenerateDexFile(const std::string &dexPath,
                                          const std::string &generatedClassName,
                                          const std::string &generateMethodName,
                                          const std::string &generateBackupMethodName,
                                          const std::string &generateShorty,
                                          const std::string &generateFieldName,
                                          bool isTargetMethodStatic,
                                          const std::string &handleCallClass,
                                          const std::string &handleCallMethodName) {
    bool ret = false;
    if (generateShorty.empty()) {
        LOGE("DexBuilderUtil::innerGenerateDexFile generateShorty is empty");
        return false;
    }

    TypeDescriptor return_type = generateShorty[0] == 'L'
                                 ? TypeDescriptor::Object
                                 : TypeDescriptor::FromDescriptor(generateShorty[0]);

    auto parameter_types = std::vector<TypeDescriptor>();
    parameter_types.reserve(generateShorty.size());
    if (!isTargetMethodStatic) parameter_types.push_back(TypeDescriptor::Object);
    for (size_t i = 1; i < generateShorty.size(); ++i) {
        parameter_types.push_back(generateShorty[i] == 'L'
                                  ? TypeDescriptor::Object
                                  : TypeDescriptor::FromDescriptor(generateShorty[i]));
    }
    Prototype method_proto{return_type, parameter_types};

    DexBuilder dex_file;

    ClassBuilder cbuilder{dex_file.MakeClass(generatedClassName)};

    auto *artTargetMethod_field = cbuilder.CreateField(generateFieldName, TypeDescriptor::Object)
            .access_flags(dex::kAccStatic | dex::kAccPublic)
            .Encode();

    auto backup_builder{cbuilder.CreateMethod(generateBackupMethodName, method_proto)};
    if (return_type == TypeDescriptor::Void) {
        backup_builder.BuildReturn();
    } else if (return_type.is_wide()) {
        LiveRegister zero = backup_builder.AllocRegister();
        LiveRegister zero_wide = backup_builder.AllocRegister();
        backup_builder.BuildConstWide(zero, 0);
        backup_builder.BuildReturn(zero, false, true);
    } else {
        LiveRegister zero = backup_builder.AllocRegister();
        backup_builder.BuildConst(zero, 0);
        backup_builder.BuildReturn(zero, !return_type.is_primitive(), false);
    }
    backup_builder.Encode();

    // ===== hook method (methodName) =====
    auto hook_builder{cbuilder.CreateMethod(generateMethodName, method_proto)};

    // 非静态方法 parameter_types[0] 是 this，不应该放进 Object[] args
    size_t first_arg_index = isTargetMethodStatic ? 0U : 1U;
    size_t real_arg_count = parameter_types.size() - first_arg_index;

    auto array_size_reg{hook_builder.AllocRegister()};
    hook_builder.BuildConst(array_size_reg, static_cast<int>(real_arg_count));

    auto args_array{hook_builder.AllocRegister()};
    hook_builder.BuildNewArray(args_array, TypeDescriptor::Object, array_size_reg);

    auto array_index_reg{hook_builder.AllocRegister()};

    //hook_builder.AllocRegister()必须在hook_builder.BuildBoxIfPrimitive之前使用。
    //因为NumRegisters() 在指令创建时和方法编码时要保持一致，否则有可能发生崩溃
    //void startop::dex::MethodBuilder::EncodeInvoke(const startop::dex::Instruction &, ::dex::Opcode): assertion "false && "long args should use invoke range"" failed
    auto target_method_reg{hook_builder.AllocRegister()};
    auto ret_reg{hook_builder.AllocRegister()};
    auto nullReceiver{hook_builder.AllocRegister()};

    for (size_t i = first_arg_index, j = first_arg_index, array_index = 0U;
         i < parameter_types.size();
         ++i, ++j, ++array_index) {
        hook_builder.BuildBoxIfPrimitive(Value::Parameter(j),
                                         parameter_types[i],
                                         Value::Parameter(j));
        hook_builder.BuildConst(array_index_reg, static_cast<int>(array_index));
        hook_builder.BuildAput(Instruction::Op::kAputObject,
                               args_array,
                               Value::Parameter(j),
                               array_index_reg);
        if (parameter_types[i].is_wide()) {
            ++j;
        }
    }

    auto handleCall_type = TypeDescriptor::FromClassname(handleCallClass);
    auto handleCall_method{dex_file.GetOrDeclareMethod(
            handleCall_type, handleCallMethodName,
            Prototype{TypeDescriptor::Object, TypeDescriptor::Object, TypeDescriptor::Object,
                      TypeDescriptor::Object.ToArray()})};

    hook_builder.AddInstruction(
            Instruction::GetStaticObjectField(artTargetMethod_field->decl->orig_index, target_method_reg));

    if (isTargetMethodStatic) {
        hook_builder.BuildConst(nullReceiver, 0);
        hook_builder.AddInstruction(Instruction::InvokeStaticObject(
                handleCall_method.id, ret_reg, target_method_reg, nullReceiver, args_array));
    } else {
        hook_builder.AddInstruction(Instruction::InvokeStaticObject(
                handleCall_method.id, ret_reg, target_method_reg, Value::Parameter(0), args_array));
    }

    if (return_type == TypeDescriptor::Void) {
        hook_builder.BuildReturn();
    } else if (return_type.is_primitive()) {
        auto box_type = return_type.ToBoxType();
        const ir::Type *type_def = dex_file.GetOrAddType(box_type);
        hook_builder.AddInstruction(
                Instruction::Cast(ret_reg, Value::Type(type_def->orig_index)));
        hook_builder.BuildUnBoxIfPrimitive(ret_reg, box_type, ret_reg);
        hook_builder.BuildReturn(ret_reg, false, return_type.is_wide());
    } else {
        const ir::Type *type_def = dex_file.GetOrAddType(return_type);
        hook_builder.AddInstruction(
                Instruction::Cast(ret_reg, Value::Type(type_def->orig_index)));
        hook_builder.BuildReturn(ret_reg, true);
    }

    hook_builder.Encode();

    slicer::MemView image{dex_file.CreateImage()};

    std::ofstream out_file(dexPath, std::ios::binary);
    if (!out_file.is_open()) {
        LOGE("DexBuilderUtil::innerGenerateDexFile Failed to open output file: %s", dexPath.c_str());
        return false;
    }
    out_file.write(image.ptr<const char>(), image.size());
    out_file.close();


    //dex文件要设为只读，否则加载dex文件会出问题
    //Honor magic 4 Android 15,会出现
    //Caused by: java.lang.SecurityException: Writable dex file 'xxxxxx_V.dex' is not allowed.
    //S_IRUSR	0400	文件所有者（User）可读
    //S_IRGRP	0040	同组用户（Group）可读
    //S_IROTH	0004	其他用户（Other）可读
    chmod(dexPath.c_str(), S_IRUSR | S_IRGRP | S_IROTH);

    ALWAYSLOGI("DexBuilderUtil::innerGenerateDexFile success: size=%zu bytes, dexPath=%s",
               image.size(), dexPath.c_str());

    ret = true;
    return ret;
}