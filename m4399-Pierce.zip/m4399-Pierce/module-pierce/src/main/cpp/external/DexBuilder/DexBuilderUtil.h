#ifndef M4399_PIERCE_DEXBUILDERUTIL_H
#define M4399_PIERCE_DEXBUILDERUTIL_H


#include <jni.h>
#include <string>

using namespace std;

class DexBuilderUtil {
public:
    static jboolean generateDexFile(JNIEnv *env,
                                    jclass clazz,
                                    jstring dexPath,
                                    jobject targetMethod,
                                    jboolean isStatic,
                                    jobject handleCallMethod,
                                    jstring generateClassName,
                                    jstring generateMethodName,
                                    jstring generateBackupMethodName,
                                    jstring generateShorty,
                                    jstring generateFieldName);

private:

    static bool innerGenerateDexFile(const std::string &dexPath,
                                     const std::string &generatedClassName,
                                     const std::string &generateMethodName,
                                     const std::string &generateBackupMethodName,
                                     const std::string &generateShorty,
                                     const std::string &generateFieldName,
                                     bool isTargetMethodStatic,
                                     const std::string &handleCallClass,
                                     const std::string &handleCallMethodName);

};


#endif //M4399_PIERCE_DEXBUILDERUTIL_H
