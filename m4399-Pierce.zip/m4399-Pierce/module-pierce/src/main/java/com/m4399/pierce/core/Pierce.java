package com.m4399.pierce.core;

import android.content.Context;
import android.os.Build;

import com.m4399.pierce.BuildConfig;
import com.m4399.pierce.core.callback.MethodHook;
import com.m4399.pierce.core.utils.PierceFileLogUtils;
import com.m4399.pierce.core.utils.PierceLogUtils;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import dalvik.system.DexClassLoader;

/**
 * The bridge class provides main APIs for you.
 *
 * @author canyie
 */
@SuppressWarnings("WeakerAccess")
public final class Pierce {
    private static final int ARCH_ARM = 1;
    private static final int ARCH_ARM64 = 2;
    private static final int ARCH_X86 = 3;
    private static volatile boolean initialized;
    private static volatile boolean profileSaverDisabled = false;
    private static boolean disableProfileSaverRet = false;
    private static final Map<Long, HookRecord> sHookRecords = new ConcurrentHashMap<>();
    private static final Object sHookLock = new Object();

    private static volatile int hookMode;
    private static String dexDirPath;
    private static String dexOptDirPath;
    private static Method handleCallMethod;
    private static HookHandler sHookHandler = new HookHandler() {
        @Override
        public MethodHook.Unhook handleHook(HookRecord hookRecord, MethodHook hook, int modifiers,
                                            boolean newMethod, boolean canInitDeclaringClass) {
            if (newMethod) {
                hookNewMethod(hookRecord, hook, modifiers, canInitDeclaringClass);
            }

            if (hook == null) {
                // This can only happen when the up handler pass null manually,
                // just return null and let the up to do remaining everything
                return null;
            }
            hookRecord.addCallback(hook);
            return hook.new Unhook(hookRecord);
        }

        @Override public void handleUnhook(HookRecord hookRecord, MethodHook hook) {
            hookRecord.removeCallback(hook);
        }
    };

    private static HookListener sHookListener;


    private Pierce() {
        throw new RuntimeException("Use static methods");
    }

    /**
     * Initialize the Pierce library if not initialized.
     * WARNING: Calling this API will disable hidden api policy when
     * {@code PierceConfig.disableHiddenApiPolicy} or {@code PierceConfig.disableHiddenApiPolicyForPlatformDomain}.
     * Due to an ART bug, if a thread changes hidden api policy while another thread is calling
     * a API that lists members of a class, a out-of-bounds write may occur and causes crashes.
     * See <a href="https://github.com/tiann/FreeReflection/issues/60">...</a> for more details.
     */
    public static void ensureInitialized() {
        if (initialized) return;
        synchronized (Pierce.class) {
            if (initialized) return;
            initialize();
            initialized = true;
        }
        disableProfileSaver();
    }

    /**
     * Check whether Pierce library is initialized.
     * @return {@code true} If Pierce is initialized, {@code false} otherwise.
     */
    public static boolean isInitialized() {
        return initialized;
    }

    private static void initGenerateDex(Context context) {
        for (Method method : HandleCallWrapClass.class.getDeclaredMethods()) {
            Class<?>[] parameterTypes = method.getParameterTypes();
            if ((parameterTypes.length == 3)
                    && (parameterTypes[0] == Object.class)
                    && (parameterTypes[1] == Object.class)
                    && (parameterTypes[2] == Object[].class)) {
                handleCallMethod = method;
                handleCallMethod.setAccessible(true);
                break;
            }
        }

        if (handleCallMethod == null) {
            throw new RuntimeException("initGenerateDex can't find handleCall method in HandleCallWrapClass");
        }

        initSaveDexDirPath(context);
    }

    private static void initSaveDexDirPath(Context context) {
        File dir = new File(context.getFilesDir(), "pierce_gen_dex");
        dir.mkdirs();
        if (!dir.exists()) {
            throw new RuntimeException("initSaveDexDirPath Failed to create dir: " + dir.getAbsolutePath());
        }

        dexDirPath = dir.getAbsolutePath();
        dexOptDirPath = dexDirPath;
        if (PierceConfig.sdkLevel < Build.VERSION_CODES.O) {
            //Android 5.0 5.1
            //以dex文件名结尾，如果优化目录和dex同目录,将会导致优化文件和dex文件同一个路径,导致抛权限拒绝异常
            //Android 6.0 7.0 ,7.1
            //以dex文件名结尾，如果优化目录和dex同目录,将会导致优化文件和dex文件同一个路径,导致dex2oat的失败
            //Android 8 以上，实际不使用优化目录
            File dirOpt = new File(context.getFilesDir(), "pierce_gen_dex_opt");
            dirOpt.mkdirs();
            if (!dirOpt.exists()) {
                throw new RuntimeException("initSaveDexDirPath Failed to create dirOpt: " + dirOpt.getAbsolutePath());
            }
            dexOptDirPath = dirOpt.getAbsolutePath();
        }
    }

    private static void initialize() {
        PierceFileLogUtils.init(PierceConfig.context);

        //pierce特有添加
        if (PierceConfig.disableHooks) {
            PierceLogUtils.alwaysLogI("initialize: no limit by disableHooks");
            return;
        }
        PierceLogUtils.alwaysLogI("Version:" + BuildConfig.VERSION_NAME + ", disableHooks:" + PierceConfig.disableHooks);

        int sdkLevel = PierceConfig.sdkLevel;
        if (sdkLevel < Build.VERSION_CODES.KITKAT) {
            throw new RuntimeException("Unsupported android sdk level " + sdkLevel);
        }

        String vmVersion = System.getProperty("java.vm.version");
        if (vmVersion == null || !vmVersion.startsWith("2")) {
            throw new RuntimeException("Only supports ART runtime");
        }

        initGenerateDex(PierceConfig.context);

        hookMode = sdkLevel < Build.VERSION_CODES.O ? HookMode.INLINE_WITHOUT_JIT : HookMode.REPLACEMENT;
        PierceLogUtils.alwaysLogI("sdkLevel=" + sdkLevel + " hookMode=" + hookMode);

        try {
            LibLoader libLoader = PierceConfig.libLoader;
            if (libLoader != null) libLoader.loadLib();

            PierceNative.init0(sdkLevel,
                    PierceConfig.debugLog,
                    PierceConfig.debuggable,
                    PierceConfig.antiChecks,
                    PierceConfig.disableHiddenApiPolicy,
                    PierceConfig.disableHiddenApiPolicyForPlatformDomain);

            if (PierceConfig.useFastNative && sdkLevel >= Build.VERSION_CODES.LOLLIPOP) {
                PierceNative.enableFastNative();
            }

            disableJitInlineAfterInit();
        } catch (Exception e) {
            throw new RuntimeException("pierce init error", e);
        }
    }

    /**
     * Set the way how Pierce hook method.
     * @param newHookMode One of {@code Pierce.HookMode.AUTO}, {@code Pierce.HookMode.INLINE},
     *                    {@code Pierce.HookMode.REPLACEMENT} or {@code Pierce.HookMode.INLINE_WITHOUT_JIT}.
     * @throws IllegalArgumentException If the {@code newHookMode} is not one of
     *                     {@code Pierce.HookMode.AUTO}, {@code Pierce.HookMode.INLINE},
     *                     {@code Pierce.HookMode.REPLACEMENT}, or {@code Pierce.HookMode.INLINE_WITHOUT_JIT}.
     * @see Pierce.HookMode
     */
    public static void setHookMode(int newHookMode) {
        if (newHookMode < HookMode.AUTO || newHookMode > HookMode.INLINE_WITHOUT_JIT)
            throw new IllegalArgumentException("Illegal hookMode " + newHookMode);
        if (newHookMode == HookMode.AUTO) {
            // On Android N or lower, entry_point_from_compiled_code_ may be hard-coded in the machine code
            // (sharpening optimization), entry replacement will most likely not take effect,
            // so we prefer to use inline hook; And on Android O+, this optimization is not performed,
            // so we prefer a more stable entry replacement mode.

            newHookMode = PierceConfig.sdkLevel < Build.VERSION_CODES.O
                    ? HookMode.INLINE_WITHOUT_JIT : HookMode.REPLACEMENT;
        }
        hookMode = newHookMode;
    }

    /**
     * Return the current hook mode.
     * @return One of {@code Pierce.HookMode.INLINE}, {@code Pierce.HookMode.REPLACEMENT} or
     * {@code Pierce.HookMode.INLINE_WITHOUT_JIT}.
     */
    public static int getHookMode() {
        return hookMode;
    }

    /**
     * Set a handler that will be used when Pierce hooking a method.
     * Internal API, use {@code HookListener} instead if you just want to be notified when hooking.
     * Note that only one handler can exist at a time, so setting a new handler will override
     * the old one. Save the old handler if yours don't know how to properly hook a method!
     * @param h The handler you want to register. Cannot be null.
     * @throws NullPointerException If the handler you given is null.
     * @see HookHandler
     */
    public static void setHookHandler(HookHandler h) {
        if (h == null) throw new NullPointerException("handler == null");
        sHookHandler = h;
    }

    /**
     * Get the handler that will be used when Pierce hooking a method.
     * Internal API, use the returned handler only when you are implementing your own handler
     * and want to continue hooking. Do NOT use the returned hook handler if you just want to hook.
     * @return The handler that will be used when hooking. Will never be null.
     * @see HookHandler
     */
    public static HookHandler getHookHandler() {
        return sHookHandler;
    }

    /**
     * Set a listener that will be called before/after hooking a method.
     * @param l The listener you want to set. Can be null.
     * @see HookListener
     */
    public static void setHookListener(HookListener l) {
        sHookListener = l;
    }

    /**
     * Get the listener that will be called before/after hooking method.
     * @return The listener that will be called before/after hooking method, or {@code null} if not set.
     * @see HookListener
     */
    public static HookListener getHookListener() {
        return sHookListener;
    }

    /**
     * Return whether the system is 64-bit.
     * Note that this method will initialize Pierce library if uninitialized.
     * @return {@code true} if the system is 64-bit, {@code false} otherwise.
     */
    public static boolean is64Bit() {
        ensureInitialized();
        return PierceNative.arch == ARCH_ARM64;
    }

    /**
     * pierce特有添加
     * Register a hook that will be invoked when the {@code method} is invoked.
     * Note that this will initialize Pierce library if uninitialized.
     *
     * @param classLoader Where the class loads from.
     * @param className   The clazz want to control.
     * @param methodName  The method want to control.
     * @param callback    The callback that will be invoked when the {@code method} is invoked.
     * @return The unhook for this hook. Call {@code unhook.unhook()} to unregister the hook.
     * @throws NullPointerException     If {@code method} or {@code callback} is null.
     * @throws IllegalArgumentException If {@code method} cannot be hooked, such as abstract method.
     */
    public static MethodHook.Unhook hook(ClassLoader classLoader, String className, String methodName, MethodHook callback) {
        try {
            return hook(classLoader.loadClass(className), methodName, callback);
        } catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("ClassNotFound", e);
        }
    }

    /**
     * pierce特有添加
     * Register a hook that will be invoked when the {@code method} is invoked.
     * Note that this will initialize Pierce library if uninitialized.
     *
     * @param clazz      The clazz want to control.
     * @param methodName The method want to control.
     * @param callback   The callback that will be invoked when the {@code method} is invoked.
     * @return The unhook for this hook. Call {@code unhook.unhook()} to unregister the hook.
     * @throws NullPointerException     If {@code method} or {@code callback} is null.
     * @throws IllegalArgumentException If {@code method} cannot be hooked, such as abstract method.
     */
    public static MethodHook.Unhook hook(Class clazz, String methodName, MethodHook callback) {
        for (Method declaredMethod : clazz.getDeclaredMethods()) {
            if (declaredMethod.getName().equals(methodName)) {
                return hook(declaredMethod, callback, true);
            }
        }
        throw new IllegalArgumentException("NoSuchMethod:" + methodName);
    }

    /**
     * Register a hook that will be invoked when the {@code method} is invoked.
     * Note that this will initialize Pierce library if uninitialized.
     * @param method The method want to control.
     * @param callback The callback that will be invoked when the {@code method} is invoked.
     * @return The unhook for this hook. Call {@code unhook.unhook()} to unregister the hook.
     * @throws NullPointerException If {@code method} or {@code callback} is null.
     * @throws IllegalArgumentException If {@code method} cannot be hooked, such as abstract method.
     */
    public static MethodHook.Unhook hook(Member method, MethodHook callback) {
        return hook(method, callback, true);
    }

    /**
     * Register a hook that will be invoked when the {@code method} is invoked.
     * Note that this will initialize Pierce library if uninitialized.
     * @param method The method want to control.
     * @param callback The callback that will be invoked when the {@code method} is invoked.
     * @param canInitDeclaringClass {@code true} if initializing the class is allowed, {@code false} otherwise.
     * @return The unhook for this hook. Call {@code unhook.unhook()} to unregister the hook.
     * @throws NullPointerException If {@code method} or {@code callback} is null.
     * @throws IllegalArgumentException If {@code method} cannot be hooked, such as abstract method.
     */
    public static MethodHook.Unhook hook(Member method, MethodHook callback, boolean canInitDeclaringClass) {
        //pierce特有添加
        if (PierceConfig.disableHooks){
            return null;
        }

        if (method == null) throw new NullPointerException("method == null");
        if (callback == null) throw new NullPointerException("callback == null");

        int modifiers = method.getModifiers();
        if (method instanceof Method) {
            if (Modifier.isAbstract(modifiers))
                throw new IllegalArgumentException("Cannot hook abstract methods: " + method);
            ((Method) method).setAccessible(true);
        } else if (method instanceof Constructor) {
            if (Modifier.isStatic(modifiers)) // TODO: We really cannot hook this?
                throw new IllegalArgumentException("Cannot hook class initializer: " + method);
            ((Constructor<?>) method).setAccessible(true);
        } else {
            throw new IllegalArgumentException("Only methods and constructors can be hooked: " + method);
        }

        ensureInitialized();

        PierceLogUtils.alwaysLogI("Hooking method " + method + " with callback " + callback);

        HookListener hookListener = sHookListener;

        if (hookListener != null)
            hookListener.beforeHook(method, callback);

        long artMethod = PierceNative.getArtMethod(method);
        HookRecord hookRecord;
        boolean newMethod = false;

        synchronized (sHookLock) {
            hookRecord = sHookRecords.get(artMethod);
            if (hookRecord == null) {
                newMethod = true;
                hookRecord = new HookRecord(method, artMethod);
                sHookRecords.put(artMethod, hookRecord);
            }
        }

        MethodHook.Unhook unhook = sHookHandler.handleHook(hookRecord, callback, modifiers,
                newMethod, canInitDeclaringClass);

        if (hookListener != null)
            hookListener.afterHook(method, unhook);

        return unhook;
    }

    static void hookNewMethod(HookRecord hookRecord, MethodHook hook, int modifiers, boolean canInitDeclaringClass) {
        Member method = hookRecord.target;
        final int mode = hookMode;
        boolean isInlineHook = mode == HookMode.INLINE || mode == HookMode.INLINE_WITHOUT_JIT;

        long thread = PierceNative.currentArtThread0();
        if ((hookRecord.isStatic = Modifier.isStatic(modifiers)) && canInitDeclaringClass) {
            resolve((Method) method);
            if (PierceConfig.sdkLevel >= Build.VERSION_CODES.Q) {
                // Android R has a new class state called "visibly initialized",
                // and FixupStaticTrampolines will be called after class was initialized.
                // The entry point will be reset. Make this class be visibly initialized before hook
                // Note: this feature does not exist on official Android Q,
                // but some weird ROMs cherry-pick this commit to these Android Q ROMs
                // https://github.com/crdroidandroid/android_art/commit/ef76ced9d2856ac988377ad99288a357697c4fa2
                PierceNative.makeClassesVisiblyInitialized(thread);
            }
        }

        Class<?> declaring = method.getDeclaringClass();

        final boolean jni = Modifier.isNative(modifiers);
        final boolean proxy = Proxy.isProxyClass(declaring);

        // Only try compile target method when trying inline hook.
        if (isInlineHook) {
            // Cannot compile native or proxy methods.
            if (!(jni || proxy)) {
                if (mode == HookMode.INLINE) {
                    boolean compiled = PierceNative.compile0(thread, method);
                    if (!compiled) {
                        PierceLogUtils.alwaysLogW("hookNewMethod " + method + " Cannot compile the target method, force replacement mode.");
                        isInlineHook = false;
                    }
                }
            } else {
                isInlineHook = false;
            }
        }

        // FIXME: WARNING: The following code will cause parameter types and return type to be initialized!!!
        if (method instanceof Method) {
            hookRecord.paramTypes = ((Method) method).getParameterTypes();
        } else {
            hookRecord.paramTypes = ((Constructor<?>) method).getParameterTypes();
        }

        hookRecord.paramNumber = hookRecord.paramTypes.length;

        genereateDexAndLoad(hookRecord, hook);

        hookRecord.skipUpdateDeclaringClass = true;

        Method backup = PierceNative.hook0(thread,
                declaring,
                hookRecord,
                method,
                hookRecord.bridge,
                hookRecord.backup,
                isInlineHook,
                jni,
                proxy);

        if (backup == null) {
            throw new RuntimeException("Failed to hook method " + method);
        }

    }

    private static void genereateDexAndLoad(HookRecord hookRecord, MethodHook hook) {
        Member targetMethod = hookRecord.target;
        long artTargetMethod = hookRecord.artMethod;

        File dirFile = new File(dexDirPath);
        if (!dirFile.exists()) {
            throw new RuntimeException("genereateDexAndLoad dexDirPath=" + dexDirPath + " doesn't exist");
        }

        if (!dirFile.canWrite()) {
            throw new RuntimeException("genereateDexAndLoad dexDirPath=" + dexDirPath + " can't write");
        }

        //生成Dex
        String generateShorty = computeShorty(targetMethod);
        String callbackClassName = hook.getClass().getName();
        //文件名需要具有唯一性
        String fileName = "pg_vc_" + BuildConfig.VERSION_CODE + "_" + callbackClassName + "_" + generateShorty + ".dex";
        String generateClassName = callbackClassName + "_G_" + generateShorty;
        String generateMethodName = (targetMethod instanceof Constructor) ? "constructor" : targetMethod.getName();
        String generateBackupMethodName = generateMethodName + "Backup";
        String generateFieldName = "artTargetMethod";

        File dexFile = new File(dirFile, fileName);

        String dexFilePath = dexFile.getAbsolutePath();
        if (dexFile.exists()) {
            PierceLogUtils.alwaysLogI("genereateDexAndLoad targetMethod=" + targetMethod + " dexFilePath=" + dexFilePath + " already exist.");
        } else {
            long startGenerateDexMillis = System.currentTimeMillis();
            boolean generateRet = PierceNative.generateDex(dexFilePath,
                    targetMethod,
                    hookRecord.isStatic,
                    handleCallMethod,
                    generateClassName,
                    generateMethodName,
                    generateBackupMethodName,
                    generateShorty,
                    generateFieldName
            );
            if (!generateRet) {
                throw new RuntimeException("genereateDexAndLoad targetMethod=" + targetMethod +
                        " dexFilePath=" + dexFilePath + " can't generate.");
            }
            long generateDexDuration = System.currentTimeMillis() - startGenerateDexMillis;
            PierceLogUtils.alwaysLogI("genereateDexAndLoad generate dex success, targetMethod=" + targetMethod
                    + " dexFilePath=" + dexFilePath
                    + " generateDuration=" + generateDexDuration + "ms");
        }

        if (dexOptDirPath != dexDirPath) {
            File dirOptDirFile = new File(dexOptDirPath);
            if (!dirOptDirFile.exists()) {
                throw new RuntimeException("genereateDexAndLoad dexOptDirPath=" + dexOptDirPath + " doesn't exist");
            }

            if (!dirOptDirFile.canWrite()) {
                throw new RuntimeException("genereateDexAndLoad dexOptDirPath=" + dexOptDirPath + " can't write");
            }
        }
        ClassLoader parentClassLoader = Pierce.class.getClassLoader();
        DexClassLoader dexClassLoader = new DexClassLoader(dexFilePath,
                dexOptDirPath,
                null,
                parentClassLoader);
        PierceLogUtils.alwaysLogI("genereateDexAndLoad DexClassLoader() success,targetMethod=" + targetMethod
                + " dexFilePath=" + dexFilePath
                + " dexOptDirPath=" + dexOptDirPath);

        try {
            Class<?> generatedClass = dexClassLoader.loadClass(generateClassName);
            PierceLogUtils.alwaysLogI("genereateDexAndLoad loadClass success,targetMethod=" + targetMethod
                    + " dexFilePath=" + dexFilePath
                    + " generateClassName=" + generateClassName);

            Field generatedField = generatedClass.getDeclaredField(generateFieldName);
            generatedField.setAccessible(true);
            generatedField.set(null, artTargetMethod);

            Method bridgeMethod = null;
            Method backupMethod = null;
            for (Method method : generatedClass.getDeclaredMethods()) {
                if (generateMethodName.equals(method.getName())) {
                    bridgeMethod = method;
                    bridgeMethod.setAccessible(true);
                    continue;
                }

                if (generateBackupMethodName.equals(method.getName())) {
                    backupMethod = method;
                    backupMethod.setAccessible(true);
                    continue;
                }
            }

            if (null == bridgeMethod) {
                throw new RuntimeException("genereateDexAndLoad targetMethod=" + targetMethod + " failed to find bridgeMethod generateMethodName=" + generateMethodName);
            }

            if (null == backupMethod) {
                throw new RuntimeException("genereateDexAndLoad targetMethod=" + targetMethod + " failed to find backupMethod generateBackupMethodName=" + generateBackupMethodName);
            }


            if (PierceConfig.sdkLevel >= Build.VERSION_CODES.Q) {
                long thread = PierceNative.currentArtThread0();
                // Android R has a new class state called "visibly initialized",
                // and FixupStaticTrampolines will be called after class was initialized.
                // The entry point will be reset. Make this class be visibly initialized before hook
                // Note: this feature does not exist on official Android Q,
                // but some weird ROMs cherry-pick this commit to these Android Q ROMs
                // https://github.com/crdroidandroid/android_art/commit/ef76ced9d2856ac988377ad99288a357697c4fa2
                PierceNative.makeClassesVisiblyInitialized(thread);
            }

            hookRecord.bridge = bridgeMethod;
            hookRecord.backup = backupMethod;

        } catch (Throwable e) {
            throw new RuntimeException("genereateDexAndLoad targetMethod=" + targetMethod + " failed to load dex class " + generateClassName, e);
        }
    }

    private static char toShorty(Class<?> clazz) {
        if (clazz == void.class) return 'V';
        if (clazz == boolean.class) return 'Z';
        if (clazz == byte.class) return 'B';
        if (clazz == char.class) return 'C';
        if (clazz == short.class) return 'S';
        if (clazz == int.class) return 'I';
        if (clazz == long.class) return 'J';
        if (clazz == float.class) return 'F';
        if (clazz == double.class) return 'D';
        return 'L';
    }

    private static String computeShorty(Member method) {
        StringBuilder sb = new StringBuilder();
        if (method instanceof Method) {
            sb.append(toShorty(((Method) method).getReturnType()));
        } else {
            sb.append('V');
        }
        Class<?>[] paramTypes = (method instanceof Method)
                ? ((Method) method).getParameterTypes()
                : ((Constructor<?>) method).getParameterTypes();
        for (Class<?> pt : paramTypes) {
            sb.append(toShorty(pt));
        }
        return sb.toString();
    }

    public static Method hookReplace(HookRecord hookRecord, Method replacement, Method backup,
                                     boolean canInitDeclaringClass) {
        Member method = hookRecord.target;
        long artMethod = PierceNative.getArtMethod(method);
        synchronized (sHookRecords) {
            if (sHookRecords.containsKey(artMethod))
                throw new IllegalStateException("Attempting to re-hook " + method);
            sHookRecords.put(artMethod, hookRecord);
        }
        int modifiers = method.getModifiers();
        final int mode = hookMode;

        boolean isInlineHook = mode != HookMode.REPLACEMENT;

        long thread = PierceNative.currentArtThread0();
        if ((hookRecord.isStatic = Modifier.isStatic(modifiers)) && canInitDeclaringClass) {
            resolve((Method) method);
            if (PierceConfig.sdkLevel >= Build.VERSION_CODES.Q) {
                // Android R has a new class state called "visibly initialized",
                // and FixupStaticTrampolines will be called after class was initialized.
                // The entry point will be reset. Make this class be visibly initialized before hook
                // Note: this feature does not exist on official Android Q,
                // but some weird ROMs cherry-pick this commit to these Android Q ROMs
                // https://github.com/crdroidandroid/android_art/commit/ef76ced9d2856ac988377ad99288a357697c4fa2
                PierceNative.makeClassesVisiblyInitialized(thread);
            }
        }

        Class<?> declaring = method.getDeclaringClass();

        final boolean jni = Modifier.isNative(modifiers);
        final boolean proxy = Proxy.isProxyClass(declaring);

        // Only try compile target method when trying inline hook.
        if (isInlineHook) {
            // Cannot compile native or proxy methods.
            if (!(jni || proxy)) {
                if (mode == HookMode.INLINE) {
                    boolean compiled = PierceNative.compile0(thread, method);
                    if (!compiled) {
                        PierceLogUtils.alwaysLogW("hookReplace method " + method + " Cannot compile the target method, force replacement mode.");
                        isInlineHook = false;
                    }
                }
            } else {
                isInlineHook = false;
            }
        }

        hookRecord.bridge = replacement;
        hookRecord.skipUpdateDeclaringClass = true;

        backup = PierceNative.hookReplace0(thread, declaring, hookRecord, method, replacement, backup,
                isInlineHook, jni, proxy);

        if (backup == null)
            throw new RuntimeException("Failed to hook method " + method);

        backup.setAccessible(true);
        return hookRecord.backup = backup;
    }

    private static void resolve(Method method) {
        Object[] badArgs;
        if (method.getParameterTypes().length > 0) {
            badArgs = null;
        } else {
            badArgs = new Object[1];
        }
        try {
            method.invoke(null, badArgs);
        } catch (IllegalArgumentException e) {
            // Only should happen. We used the unmatched parameter array.
            return;
        } catch (Exception e) {
            throw new RuntimeException("Unknown exception thrown when resolve static method.", e);
        }
        throw new RuntimeException("No IllegalArgumentException thrown when resolve static method.");
    }

    /**
     * Return whether the given method has been hooked before.
     * Note that once the method is hooked, this will return {@code true}, even it has been unhooked.
     * @param method the method you want to check.
     * @return {@code true} if the method has been hooked before, {@code false} otherwise.
     */
    public static boolean isHooked(Member method) {
        if (!(method instanceof Method || method instanceof Constructor))
            throw new IllegalArgumentException("Only methods and constructors can be hooked: " + method);
        return sHookRecords.containsKey(PierceNative.getArtMethod(method));
    }

    public static String dump() {
        String ret = sHookRecords.toString();
        return ret;
    }

    public static long getArtMethodEntryPointFromCompiledCode(Member method) {
        //需要初始化，防止java.lang.UnsatisfiedLinkError: No implementation found
        ensureInitialized();
        return PierceNative.getArtMethodEntryPointFromCompiledCode(method);
    }

    public static String getArtMethodEntryPointHexString(Member method,int maxDumpHexSize) {
        //需要初始化，防止java.lang.UnsatisfiedLinkError: No implementation found
        ensureInitialized();
        return PierceNative.getArtMethodEntryPointHexString(method,maxDumpHexSize);
    }

    public static HookRecord getHookRecord(long artMethod) {
        HookRecord result = sHookRecords.get(artMethod);
        if (result == null) {
            throw new AssertionError("No HookRecord found for ArtMethod pointer 0x" + Long.toHexString(artMethod));
        }
        return result;
    }

    public static Object getObject(long thread, long address) {
        if (address == 0) return null;
        return PierceNative.getObject0(thread, address);
    }

    public static long getAddress(long thread, Object o) {
        if (o == null) return 0;
        return PierceNative.getAddress0(thread, o);
    }

    static Object callBackupMethod(HookRecord hookRecord, Object thisObject, Object[] args) throws InvocationTargetException, IllegalAccessException {
        // native entry of JNI method may be changed by RegisterNatives and UnregisterNatives,
        // so we need to update them when invoke backup method.
        Member origin = hookRecord.target;
        Method backup = hookRecord.backup;
        PierceNative.syncMethodInfo(origin, backup, hookRecord.skipUpdateDeclaringClass);
        Object result = backup.invoke(thisObject, args);
        return result;
    }

    /**
     * Invoke the original implementation of the given method.
     * If the method is not hooked, the behavior is undefined. Now Pierce will try to directly invoke it,
     *   but if other threads hooked the given method between we check if the method is hooked
     *   and invoke it directly, this call will be intercepted and the registered hooks will be
     *   triggered. DO NOT RELY ON THIS UNRELIABLE INTERNAL BEHAVIOR.
     * @param method The method you want to invoke its original implementation.
     * @param thisObject  The object the underlying method is invoked from
     * @param args The arguments used for the method call
     * @return The result of the original method
     * @throws NullPointerException If the given method is null.
     * @throws IllegalAccessException Should never happen
     * @throws InvocationTargetException If the underlying method throws an exception.
     * @throws IllegalArgumentException If the method cannot be invoked with the given args.
     * @see CallFrame#invokeOriginalMethod()
     * @see CallFrame#invokeOriginalMethod(Object, Object...)
     * @see Method#invoke(Object, Object...)
     */
    public static Object invokeOriginalMethod(Member method, Object thisObject, Object... args) throws IllegalAccessException, InvocationTargetException {
        if (method == null) throw new NullPointerException("method == null");
        if (method instanceof Method) {
            ((Method) method).setAccessible(true);
        } else if (method instanceof Constructor) {
            ((Constructor<?>) method).setAccessible(true);
        } else {
            throw new IllegalArgumentException("method must be of type Method or Constructor");
        }

        HookRecord hookRecord = sHookRecords.get(PierceNative.getArtMethod(method));
        if (hookRecord == null) {
            // Not hooked, try to invoke it directly (but it may have side effect)
            if (PierceConfig.debugLog)
                PierceLogUtils.alwaysLogW("Attempting to invoke original implementation on a not-hooked method " + method
                        + ". This is undefined behavior and may have side effect (e.g. if other threads hooked "
                        + "the method before we actually call Method.invoke(), the registered hooks will be triggered).", new Throwable("here"));
            if (method instanceof Constructor) {
                if (thisObject != null)
                    throw new IllegalArgumentException(
                            "Cannot invoke a not hooked Constructor with a non-null receiver");
                try {
                    return ((Constructor<?>) method).newInstance(args);
                } catch (InstantiationException e) {
                    throw new IllegalArgumentException("invalid Constructor", e);
                }
            } else {
                return ((Method) method).invoke(thisObject, args);
            }
        }

        if (hookRecord.backup == null) {
            // Pending, we need to make the declaring class initialized
            // the backup will be set in FixupStaticTrampolines or MarkClassInitialized
            // I think we don't need makeClassesVisiblyInitialized here
            assert method instanceof Method;
            resolve((Method) method);
//            if (PierceConfig.sdkLevel >= Build.VERSION_CODES.R) {
//                makeClassesVisiblyInitialized(currentArtThread0());
//            }
        }

        return callBackupMethod(hookRecord, thisObject, args);
    }

    /**
     * Compile the given method. Note that this will always do nothing on Android R+,
     * and may crash if JIT compilation is not allowed the current process,
     * like some system process. Make sure you really need this before use!
     * @param method The method you want to compile.
     * @return {@code true} if successfully compile the method, {@code false} otherwise.
     * @throws NullPointerException If the given method is null.
     * @throws IllegalArgumentException If the given method cannot be compiled.
     */
    public static boolean compile(Member method) {
        int modifiers = method.getModifiers();
        Class<?> declaring = method.getDeclaringClass();

        if (!(method instanceof Method || method instanceof Constructor))
            throw new IllegalArgumentException("Only methods and constructors can be compiled: " + method);

        if (Modifier.isAbstract(modifiers))
            throw new IllegalArgumentException("Cannot compile abstract methods: " + method);

        if (Modifier.isNative(modifiers) || Proxy.isProxyClass(declaring)) {
            // Cannot compile native methods and proxy methods
            return false;
        }

        ensureInitialized();
        return PierceNative.compile0(PierceNative.currentArtThread0(), method);
    }

    /**
     * Decompile the given method. Force the given method executes by interpreter.
     * This may be very useful when hooking a method that is inlined into caller.
     * Note that in that case, you should decompile the caller rather than the callee.
     * @param method The method you want to decompile.
     * @param disableJit {@code true} if you want to prevent the method gets JIT compiled again
     * @return {@code true} If successfully decompiled this method, {@code false} otherwise.
     */
    public static boolean decompile(Member method, boolean disableJit) {
        int modifiers = method.getModifiers();
        Class<?> declaring = method.getDeclaringClass();

        if (!(method instanceof Method || method instanceof Constructor))
            throw new IllegalArgumentException("Only methods and constructors can be decompiled: " + method);

        if (Modifier.isAbstract(modifiers))
            throw new IllegalArgumentException("Cannot decompile abstract methods: " + method);

        if (Proxy.isProxyClass(declaring)) {
            // Proxy methods entry is fixed at art_quick_proxy_invoke_handler.
            return false;
        }
        ensureInitialized();
        return PierceNative.decompile0(method, disableJit);
    }

    /**
     * Prevent any JIT inlining in the current process. DOES NOT WORK FOR NOW.
     * @return {@code true} if successfully disabled jit inlining, {@code false} otherwise.
     */
    //pierce特有
    private static boolean disableJitInlineAfterInit() {
        if (PierceConfig.sdkLevel < Build.VERSION_CODES.N) return false;
        boolean ret = false;

        if ((Build.VERSION_CODES.N == PierceConfig.sdkLevel)
                || (Build.VERSION_CODES.N_MR1 == PierceConfig.sdkLevel)
                || (Build.VERSION_CODES.O == PierceConfig.sdkLevel)
                || (Build.VERSION_CODES.O_MR1 == PierceConfig.sdkLevel)) {
            ret = PierceNative.disableJitInline0();
        }
        return ret;
    }
    /**
     * Set whether we can manually JIT compile a method.
     * @param allowed {@code true} if allowed, {@code false} otherwise.
     */
    public static void setJitCompilationAllowed(boolean allowed) {
        setJitCompilationAllowed(allowed, false);
    }

    /**
     * Set whether we can manually JIT compile a method.
     * @param allowed {@code true} if allowed, {@code false} otherwise.
     * @param autoCompileBridge {@code true} if try to automatically compile bridge methods for better performance
     */
    public static void setJitCompilationAllowed(boolean allowed, boolean autoCompileBridge) {
        if (PierceConfig.sdkLevel < Build.VERSION_CODES.N) {
            // No JIT.
            return;
        }
        ensureInitialized();
        PierceNative.setJitCompilationAllowed0(allowed, autoCompileBridge);
    }

    /**
     * Prevent art recording our method call profile. This can prevent methods being AOT-compiled,
     * so can avoid some hook invalidation caused by optimization, but will cause performance problems.
     * @return {@code true} if we successfully disabled profile saver, {@code false} otherwise.
     */
    //pierce修改
    public static boolean disableProfileSaver() {
        if (PierceConfig.disableHooks) {
            PierceLogUtils.alwaysLogI("disableProfileSaver: disableHooks=true disableProfilerSaverRet=" + disableProfileSaverRet);
            return disableProfileSaverRet;
        }

        if (profileSaverDisabled){
            return disableProfileSaverRet;
        }

        //需要初始化，防止java.lang.UnsatisfiedLinkError: No implementation found
        ensureInitialized();

        synchronized (Pierce.class) {
            if (profileSaverDisabled){
                return disableProfileSaverRet;
            }
            disableProfileSaverRet = disableProfileSaverAfterInit();
            profileSaverDisabled = true;
        }
        return disableProfileSaverRet;
    }

    private static boolean disableProfileSaverAfterInit() {
        if (PierceConfig.sdkLevel < Build.VERSION_CODES.N) return false;
        boolean ret = false;

        //7.0<=AndroidVersion<=16.0
//        if((Build.VERSION_CODES.P == PierceConfig.sdkLevel)
//           ||(34 == PierceConfig.sdkLevel)
//           ||(36 == PierceConfig.sdkLevel)){
        //release包在huawei p10 Android 9,有出现过profile-guided AOT
        //release包在云机 小米 14 Pro Android 14,有出现过profile-guided AOT
        //release包在测机 honor magic4 Android 15,有出现过profile-guided AOT
        //在云真机 xiaomi15 android 16 ,有出现过profile-guided AOT
        //后面有实际出现过，在添加
        ret = PierceNative.disableProfileSaver0();
//        }
        return ret;
    }

    /**
     * Set whether the current process is debuggable, like {@code PierceConfig#debuggable} but allows
     * you set the value after Pierce library is initialized.
     * @param debuggable whether the current process is debuggable.
     * @see PierceConfig#debuggable
     */
    public static void setDebuggable(boolean debuggable) {
        //pierce特有添加
        if(PierceConfig.disableHooks){
            return;
        }

        if (!initialized) {
            synchronized (Pierce.class) {
                if (!initialized) {
                    PierceConfig.debuggable = debuggable;
                    initialize();
                    initialized = true;
                    return;
                }
            }
        }
        PierceConfig.debuggable = debuggable;
        PierceNative.setDebuggable0(debuggable);
    }

    /**
     * Disable the hidden api restriction policy in the current process.
     * @param application whether the restriction policy for application domain should be disabled
     * @param platform whether the restriction policy for platform domain should be disabled
     * @see PierceConfig#disableHiddenApiPolicy
     * @see PierceConfig#disableHiddenApiPolicyForPlatformDomain
     */
    public static void disableHiddenApiPolicy(boolean application, boolean platform) {
        if (initialized) {
            PierceNative.disableHiddenApiPolicy0(application, platform);
        } else {
            PierceConfig.disableHiddenApiPolicy = application;
            PierceConfig.disableHiddenApiPolicyForPlatformDomain = platform;
            ensureInitialized();
        }
    }

    public static final class HandleCallWrapClass {
        public static Object handleCall(Object artTargetMethod, Object thisObject, Object[] args)
                throws Throwable {
            HookRecord hookRecord = sHookRecords.get((long) artTargetMethod);
            Object object = Pierce.handleCall(hookRecord, thisObject, args);
            return object;
        }
    }

    public static Object handleCall(HookRecord hookRecord, Object thisObject, Object[] args)
            throws Throwable {
        // WARNING: DO NOT print thisObject or args, else the toString() method will be called on it
        // At this time the object may not "ready"
        log("handleCall for method " + hookRecord.target);

        if (PierceConfig.disableHooks || hookRecord.emptyCallbacks()) {
            try {
                return callBackupMethod(hookRecord, thisObject, args);
            } catch (InvocationTargetException e) {
                throw e.getTargetException();
            }
        }

        CallFrame callFrame = new CallFrame(hookRecord, thisObject, args);
        MethodHook[] callbacks = hookRecord.getCallbacks();

        // call before callbacks
        int beforeIdx = 0;
        do {
            MethodHook callback = callbacks[beforeIdx];
            try {
                callback.beforeCall(callFrame);
            } catch (Throwable e) {
                PierceLogUtils.alwaysLogE("Unexpected exception occurred when calling " + callback.getClass().getName() + ".beforeCall()", e);
                // reset result (ignoring what the unexpectedly exiting callback did)
                callFrame.resetResult();
                continue;
            }
            if (callFrame.returnEarly) {
                // skip remaining "before" callbacks and corresponding "after" callbacks
                beforeIdx++;
                break;
            }
        } while (++beforeIdx < callbacks.length);

        // call original method if not requested otherwise
        if (!callFrame.returnEarly) {
            try {
                callFrame.setResult(callFrame.invokeOriginalMethod());
            } catch (InvocationTargetException e) {
                callFrame.setThrowable(e.getTargetException());
            }
        }

        // call after callbacks
        int afterIdx = beforeIdx - 1;
        do {
            MethodHook callback = callbacks[afterIdx];
            Object lastResult = callFrame.getResult();
            Throwable lastThrowable = callFrame.getThrowable();
            try {
                callback.afterCall(callFrame);
            } catch (Throwable e) {
                PierceLogUtils.alwaysLogE("Unexpected exception occurred when calling " + callback.getClass().getName() + ".afterCall()", e);

                // reset to last result (ignoring what the unexpectedly exiting callback did)
                if (lastThrowable == null)
                    callFrame.setResult(lastResult);
                else
                    callFrame.setThrowable(lastThrowable);
            }
        } while (--afterIdx >= 0);

        // return
        if (callFrame.hasThrowable())
            throw callFrame.getThrowable();
        else
            return callFrame.getResult();
    }

    /**
     * Print a log with "Pierce" tag if {@code PierceConfig#debug} is set, or do nothing.
     *
     * @param message The message you want print.
     */
    private static void log(String message) {
        if (PierceConfig.debugLog) {
            PierceLogUtils.alwaysLogI(message);
        }
    }

    /**
     * Print a log with "Pierce" tag if {@code PierceConfig#debug} is set, or do nothing.
     *
     * @param fmt  The message format you want print.
     * @param args The args used to format {@code format}.
     * @see String#format(String, Object...)
     */
    private static void log(String fmt, Object... args) {
        if (PierceConfig.debugLog) {
            PierceLogUtils.alwaysLogI(String.format(fmt, args));
        }
    }

    /**
     * Interface definition for a callback to be invoked when a method is hooked.
     */
    public interface HookListener {
        /**
         * Invoked before a method hooking.
         * @param method The method that will be hooked
         * @param callback The hook that will be registered
         */
        void beforeHook(Member method, MethodHook callback);

        /**
         * Invoke after a method hooking.
         * @param method The hooked method
         * @param unhook The registered hook
         */
        void afterHook(Member method, MethodHook.Unhook unhook);
    }

    /**
     * Interface definition for an implementation to be invoked when load our native library (libPierce.so)
     */
    public interface LibLoader {
        /**
         * Will be invoked when our native library (libPierce.so) needs to be loaded.
         */
        void loadLib();
    }

    /**
     * Enum definition for how to hook method.
     * @see Pierce#setHookMode(int)
     */
    public interface HookMode {
        /**
         * AUTO: Let Pierce itself to decide how to hook. The default value.
         */
        int AUTO = 0;

        /**
         * INLINE: Prefer inline hook (overwrite the first few instructions to hook),
         * try to manually compile the method if not compiled.
         * If the method cannot be hooked in this mode, fallback to {@code REPLACEMENT}.
         * @deprecated Since manually do a JIT compilation causes crashes on some devices,
         * we prefer {@code INLINE_WITHOUT_JIT} instead.
         */
        @Deprecated
        int INLINE = 1;

        /**
         * REPLACEMENT: Always change entry point of the method to hook it.
         */
        int REPLACEMENT = 2;

        /**
         * Similar to {@code INLINE}, but when the target method isn't compiled yet,
         * automatically fallback to {@code REPLACEMENT} mode instead of manually compile it
         */
        int INLINE_WITHOUT_JIT = 3;
    }

    /**
     * Internal API. Implement the hook logic by implementing this interface.
     * @see Pierce#setHookHandler(HookHandler)
     */
    public interface HookHandler {
        MethodHook.Unhook handleHook(HookRecord hookRecord, MethodHook hook, int modifiers,
                                     boolean newMethod, boolean canInitDeclaringClass);
        void handleUnhook(HookRecord hookRecord, MethodHook hook);
    }

    /**
     * Internal API. Record hook info about a method.
     */
    public static final class HookRecord {
        public final Member target;
        public final long artMethod;
        public Method bridge;
        public Method backup;
        public long trampoline;
        public boolean isStatic;
        public int paramNumber;
        public Class<?>[] paramTypes;
        private Set<MethodHook> callbacks = new HashSet<>();
        public volatile Object paramTypesCache;
        public boolean skipUpdateDeclaringClass;

        public HookRecord(Member target, long artMethod) {
            this.target = target;
            this.artMethod = artMethod;
        }

        public synchronized void addCallback(MethodHook callback) {
            callbacks.add(callback);
        }

        public synchronized void removeCallback(MethodHook callback) {
            callbacks.remove(callback);
        }

        public synchronized boolean emptyCallbacks() {
            return callbacks.isEmpty();
        }

        public synchronized MethodHook[] getCallbacks() {
            return callbacks.toArray(new MethodHook[callbacks.size()]);
        }

        public boolean isPending() {
            return backup == null;
        }

        public Object callBackup(Object thisObject, Object... args) throws InvocationTargetException, IllegalAccessException {
            return callBackupMethod(this, thisObject, args);
        }

        @Override
        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("HookRecord{");
            stringBuilder.append("target=");
            stringBuilder.append(target);

            stringBuilder.append(", artMethod=0x");
            stringBuilder.append(Long.toHexString(artMethod));

            stringBuilder.append(", bridge=");
            stringBuilder.append(bridge);

            //backup 比较特殊，会导致崩溃，不打印
            //stringBuilder.append(", backup=");
            //stringBuilder.append(backup);

            stringBuilder.append(", trampoline=0x");
            stringBuilder.append(Long.toHexString(trampoline));

            stringBuilder.append(", callbacks=");
            stringBuilder.append(callbacks);

            stringBuilder.append(", skipUpdateDeclaringClass=");
            stringBuilder.append(skipUpdateDeclaringClass);

            //加个\n,让sHookRecords不会只打一行
            stringBuilder.append("}\n");
            String ret = stringBuilder.toString();
            return ret;
        }
    }

    /**
     * A Holder that holds the method, "this" object, arguments, result or exception of a method call.
     */
    public static class CallFrame {
        /**
         * The calling method.
         */
        public final Member method;

        /**
         * The "this" object of this call, {@code null} if executing a static method.
         * Change it in {@code beforeCall} to set new object as "this" when calling original method.
         */
        public Object thisObject;

        /**
         * The arguments passed to the method in this call. Will never be null.
         * Change it or its value in {@code beforeCall} to change arguments when calling original method.
         */
        public Object[] args;
        private Object result;
        private Throwable throwable;
        /* package */public boolean returnEarly;
        private HookRecord hookRecord;

        public CallFrame(HookRecord hookRecord, Object thisObject, Object[] args) {
            this.hookRecord = hookRecord;
            this.method = hookRecord.target;
            this.thisObject = thisObject;
            this.args = args;
        }

        /**
         * Get the result that will be returned in this method call.
         * @return The result that will be returned in this method call
         */
        public Object getResult() {
            return result;
        }

        /**
         * Set a result that will be returned in this method call.
         * If you call it {@code beforeCall}, the original method call will be prevented, and next
         * hooks will not be called.
         * @param result The return value you want to set.
         */
        public void setResult(Object result) {
            this.result = result;
            this.throwable = null;
            this.returnEarly = true;
        }

        /**
         * Like {@link CallFrame#setResult(Object)} but only set the return value if no exception will be thrown.
         * @param result The return value you want to set.
         */
        public void setResultIfNoException(Object result) {
            if (this.throwable == null) {
                this.result = result;
                this.returnEarly = true;
            }
        }

        /**
         * Get the exception that will be thrown in this method call.
         * @return The exception that will be thrown in this method call.
         */
        public Throwable getThrowable() {
            return throwable;
        }

        /**
         * Return whether an exception will be thrown as the result of this method call.
         * @return {@code true} If there is an exception will be thrown, {@code false} otherwise.
         */
        public boolean hasThrowable() {
            return throwable != null;
        }

        /**
         * Set the exception that will be thrown in this method call.
         * If you call it {@code beforeCall}, the original method call will be prevented, and next
         * hooks will not be called.
         * @param throwable The exception you want to throw.
         */
        public void setThrowable(Throwable throwable) {
            this.throwable = throwable;
            this.result = null;
            this.returnEarly = true;
        }

        /**
         * Like {@link CallFrame#getResult()} but throwing an exception if there is an exception set.
         * @return The result of this method call
         * @throws Throwable The exception happened in this method call
         */
        public Object getResultOrThrowable() throws Throwable {
            if (throwable != null)
                throw throwable;
            return result;
        }

        /**
         * Reset any previous result or exception, and allows the original method to be executed.
         */
        public void resetResult() {
            this.result = null;
            this.throwable = null;
            this.returnEarly = false;
        }

        /**
         * Invoke the original implementation of the method with current {@code thisObject} and {@code args}.
         * @return The return value of this method.
         * @throws InvocationTargetException If the original method throws an exception.
         * @throws IllegalAccessException Should never happen
         * @see #invokeOriginalMethod(Object, Object...)
         * @see Pierce#invokeOriginalMethod(Member, Object, Object...)
         */
        public Object invokeOriginalMethod() throws InvocationTargetException, IllegalAccessException {
            return callBackupMethod(hookRecord, thisObject, args);
        }

        /**
         * Like {@link #invokeOriginalMethod()} but use the passed {@code thisObject} and {@code args}.
         * @param thisObject The "this" object of this method call.
         * @param args The arguments of this method call.
         * @return The return value of this method.
         * @throws InvocationTargetException If the original method throws an exception.
         * @throws IllegalAccessException Should never happen
         * @see #invokeOriginalMethod()
         * @see #invokeOriginalMethod(Member, Object, Object...)
         */
        public Object invokeOriginalMethod(Object thisObject, Object... args) throws InvocationTargetException, IllegalAccessException {
            return callBackupMethod(hookRecord, thisObject, args);
        }
    }
}
