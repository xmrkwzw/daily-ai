package com.m4399.pierce.core.utils;

import android.annotation.SuppressLint;
import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.core.PierceNative;
/**
 * @author canyie
 */
@SuppressWarnings("JavaReflectionMemberAccess") @SuppressLint("PrivateApi") public final class Primitives {
    private static final String TAG = "Primitives";
    private static Class<?> unsafeClass;
    private static Object unsafe;
    private static Method putObject;
    private static Method getInt;
    private static boolean triedGetShadowKlassField;
    private static Field shadowKlassField;
    private static Field superClassField;
    private static Field classAccessFlagsField;
    private static int baseOffsetOfObjectArray;

    public static long currentArtThread() {
        Pierce.ensureInitialized();
        return PierceNative.currentArtThread0();
    }

    @SuppressLint("SoonBlockedPrivateApi")
    public static void setObjectClass(Object target, Class<?> newClass) {
        if (target.getClass() == newClass) return;
        if (!triedGetShadowKlassField) {
            triedGetShadowKlassField = true;
            try {
                shadowKlassField = Object.class.getDeclaredField("shadow$_klass_");
                shadowKlassField.setAccessible(true);
            } catch (NoSuchFieldException e) {
                PierceLogUtils.alwaysLogW("Object.shadow$_klass_ not found, use Unsafe.", e);
            }
        }
        try {
            if (shadowKlassField != null) {
                shadowKlassField.set(target, newClass);
            } else {
                ensureUnsafeReady();
                if (putObject == null) {
                    putObject = unsafeClass.getDeclaredMethod("putObject", Object.class, long.class, Object.class);
                    putObject.setAccessible(true);
                }
                putObject.invoke(unsafe, target, 0L, newClass); // offset 0 is first field
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void setSuperClass(Class<?> target, Class<?> newSuperClass) {
        if (target.getSuperclass() == newSuperClass) return;
        if (superClassField == null) {
            try {
                // noinspection SoonBlockedPrivateApi
                superClassField = Class.class.getDeclaredField("superClass");
                superClassField.setAccessible(true);
            } catch (NoSuchFieldException e) {
                throw new RuntimeException("Class.superClass not found", e);
            }
        }
        try {
            superClassField.set(target, newSuperClass);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public static int getFieldOffset(Field field) throws Exception {
        // 1. try Android-specific field
        try {
            // noinspection SoonBlockedPrivateApi
            Field offset = Field.class.getDeclaredField("offset");
            offset.setAccessible(true);
            return offset.getInt(field);
        } catch (Exception ignored) {
        }

        // 2. try Android-specific method
        try {
            // noinspection DiscouragedPrivateApi
            Method getOffset = Field.class.getDeclaredMethod("getOffset");
            getOffset.setAccessible(true);
            return (int) getOffset.invoke(field);
        } catch (Exception ignored) {
        }

        // 3. try Java traditional method
        // We assume that the field is non-static.
        ensureUnsafeReady();
        Method objectFieldOffset = unsafeClass.getDeclaredMethod("objectFieldOffset", Field.class);
        objectFieldOffset.setAccessible(true);
        return (int) objectFieldOffset.invoke(unsafe, field);
    }

    public static void removeClassFinalFlag(Class<?> target) {
        if (!Modifier.isFinal(target.getModifiers())) return;
        if (classAccessFlagsField == null) {
            try {
                // noinspection JavaReflectionMemberAccess
                classAccessFlagsField = Class.class.getDeclaredField("accessFlags");
                classAccessFlagsField.setAccessible(true);
            } catch (NoSuchFieldException e) {
                throw new RuntimeException("Class.accessFlags not found", e);
            }
        }
        try {
            classAccessFlagsField.setInt(target, classAccessFlagsField.getInt(target) & ~Modifier.FINAL);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public static long getAddress(Object o) {
        if (o == null) return 0;
        long address = Pierce.getAddress(currentArtThread(), o);
        if (address == 0) {
            // Thread::DecodeJObject is inlined
            ensureUnsafeReady();
            Object[] array = new Object[] { o };
            try {
                if (baseOffsetOfObjectArray == 0) {
                    Method arrayBaseOffset = unsafeClass.getDeclaredMethod("arrayBaseOffset", Class.class);
                    arrayBaseOffset.setAccessible(true);
                    baseOffsetOfObjectArray = (int) arrayBaseOffset.invoke(unsafe, Object[].class);

                    getInt = unsafeClass.getDeclaredMethod("getInt", Object.class, long.class);
                    getInt.setAccessible(true);
                }
                // ART allocates objects in the low 4GB memory region
                // so int32_t is enough for object references (actually stores addresses)
                address = (int) getInt.invoke(unsafe, array, baseOffsetOfObjectArray);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return address;
    }

    public static byte[] int2Bytes(int value) {
        // Android only use little-endian.
        return new byte[] {
                (byte) (value & 0xFF),
                (byte) ((value >> 8) & 0xFF),
                (byte) ((value >> 16) & 0xFF),
                (byte) ((value >> 24) & 0xFF)
        };
    }

    public static int bytes2Int(byte[] src) {
        // Android only use little-endian.
        return (src[0] & 0xFF)
                | ((src[1] & 0xFF) << 8)
                | ((src[2] & 0xFF) << 16)
                | ((src[3] & 0xFF) << 24);
    }

    public static long ints2Long(int l, int h) {
        // Android only use little-endian.
        return (((long) h) << 32) | (l & 0xffffffffL);
    }

    public static double ints2Double(int a, int b) {
        return Double.longBitsToDouble(ints2Long(a, b));
    }

    public static double floats2Double(float l, float h) {
        return Double.longBitsToDouble(ints2Long(Float.floatToIntBits(l), Float.floatToIntBits(h)));
    }

    public static int evenUp(int n) {
        if ((n & 1) == 1) {
            n++;
        }
        return n;
    }

    private static Object getUnsafe() throws Exception {
        try {
            // try Unsafe.getUnsafe()
            Method getUnsafe = unsafeClass.getDeclaredMethod("getUnsafe");
            getUnsafe.setAccessible(true);
            return getUnsafe.invoke(null);
        } catch (Exception ignored) {
        }

        Field theUnsafe;
        try {
            // try Unsafe.theUnsafe (art and hotspot vm)
            theUnsafe = unsafeClass.getDeclaredField("theUnsafe");
        } catch (NoSuchFieldException ignored) {
            // try Unsafe.THE_ONE (art and dalvik vm)
            theUnsafe = unsafeClass.getDeclaredField("THE_ONE");
        }
        theUnsafe.setAccessible(true);
        return theUnsafe.get(null);
    }

    private static void ensureUnsafeReady() {
        if (unsafe != null) return;
        try {
            unsafeClass = Class.forName("sun.misc.Unsafe");
            unsafe = getUnsafe();
        } catch (Exception e) {
            throw new RuntimeException("Unsafe API is unavailable", e);
        }
    }
}
