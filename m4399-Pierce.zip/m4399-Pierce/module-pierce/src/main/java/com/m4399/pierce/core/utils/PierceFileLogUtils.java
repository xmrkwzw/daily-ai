package com.m4399.pierce.core.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.util.Log;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.core.PierceConfig;
import com.m4399.pierce.core.PierceNative;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class PierceFileLogUtils {
    private static final String TAG = "PierceFileLogUtils";
    private static final String logDirPath = "/pluginGame/logs";
    private static final String logFilePrefix = "pierce_log_";

    private static final AtomicBoolean isInit = new AtomicBoolean(false);
    private static final AtomicBoolean isSetFileLogPath = new AtomicBoolean(false);
    private static final AtomicBoolean failedWarnLogged = new AtomicBoolean(false);

    public static void init(Context context) {
        if (context == null) {
            return;
        }

        if (!isInit.compareAndSet(false, true)) {
            Log.w(TAG, "init have been done,ignored");
            return;
        }

        try {
            //这里加载一次so,防止找不到符号崩溃
            Pierce.LibLoader libLoader = PierceConfig.libLoader;
            if (libLoader != null) libLoader.loadLib();

            File externalFilesDir = context.getExternalFilesDir(null);
            if (externalFilesDir == null) {
                Log.w(TAG, "init getExternalFilesDir(null) return null.");
                return;
            }

            String dirFilePath = externalFilesDir.getAbsolutePath() + logDirPath;
            File dirFile = new File(dirFilePath);
            if (!dirFile.exists() && !dirFile.mkdirs()) {
                Log.w(TAG, "init " + dirFile.getAbsolutePath() + " mkdirs() failed.");
                return;
            }

            String processName = currentProcessName(context);
            SimpleDateFormat fileNameDateFormat = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss", Locale.US);
            String fileNameTime = fileNameDateFormat.format(new Date());
            int pid = android.os.Process.myPid();
            File nativeFile = new File(dirFile, logFilePrefix + fileNameTime + "_" + pid + "_" + processName + ".log");
            String nativeLogFilePath = nativeFile.getAbsolutePath();
            PierceNative.setLogFilePath(nativeLogFilePath);
            Log.i(TAG, "init success, nativeLogFilePath=" + nativeLogFilePath);
            isSetFileLogPath.set(true);
        } catch (Throwable t) {
            Log.e(TAG, "init failed", t);
        }
    }

    private static String currentProcessName(Context ctx) {
        int pid = android.os.Process.myPid();
        String processName = "pid_" + pid;
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                List<ActivityManager.RunningAppProcessInfo> list = am.getRunningAppProcesses();
                if (list != null) {
                    for (ActivityManager.RunningAppProcessInfo info : list) {
                        if (info.pid == pid) {
                            processName = info.processName;
                            break;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "currentProcessName failed", t);
        }
        return processName;
    }

    public static boolean write(String level,
                                String tag,
                                String msg,
                                Throwable msgThrowable) {
        if (!isSetFileLogPath.get()) {
            return false;
        }

        StringBuilder logMsgBuilder = new StringBuilder(msg == null ? "null" : msg);
        if (msgThrowable != null) {
            logMsgBuilder.append("\n");
            logMsgBuilder.append(Log.getStackTraceString(msgThrowable));
        }
        String logMsg = logMsgBuilder.toString();
        boolean ret = PierceNative.writeLogToFile(level, tag, logMsg);
        if (!ret && failedWarnLogged.compareAndSet(false, true)) {
            Log.e(TAG, "write failed");
        }
        return ret;
    }
}
