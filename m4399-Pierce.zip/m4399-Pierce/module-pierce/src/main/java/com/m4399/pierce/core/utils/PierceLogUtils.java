package com.m4399.pierce.core.utils;

import android.util.Log;

public class PierceLogUtils {
    private static final String TAG = "Pierce";

    public static void alwaysLogI(String message) {
        Log.i(TAG, message);
        PierceFileLogUtils.write("I", TAG, message, null);
    }

    public static void alwaysLogI(String message, Throwable throwable) {
        Log.i(TAG, message, throwable);
        PierceFileLogUtils.write("I", TAG, message, throwable);
    }

    public static void alwaysLogI(String fmt, Object... args) {
        String msg = String.format(fmt, args);
        Log.i(TAG, msg);
        PierceFileLogUtils.write("I", TAG, msg, null);
    }

    public static void alwaysLogW(String message) {
        Log.e(TAG, message);
        PierceFileLogUtils.write("W", TAG, message, null);
    }

    public static void alwaysLogW(String fmt, Object... args) {
        String msg = String.format(fmt, args);
        Log.i(TAG, msg);
        PierceFileLogUtils.write("W", TAG, msg, null);
    }

    public static void alwaysLogE(String message) {
        Log.e(TAG, message);
        PierceFileLogUtils.write("E", TAG, message, null);
    }

    public static void alwaysLogE(String message, Throwable throwable) {
        Log.e(TAG, message, throwable);
        PierceFileLogUtils.write("E", TAG, message, throwable);
    }

}
