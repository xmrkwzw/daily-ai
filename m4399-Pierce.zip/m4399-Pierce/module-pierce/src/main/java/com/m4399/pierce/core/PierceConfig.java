package com.m4399.pierce.core;

import android.content.Context;
import android.os.Build;

import java.util.Locale;

/**
 * A class to stores some configures.
 * @author canyie
 */
@SuppressWarnings("WeakerAccess") public final class PierceConfig {
    public static int sdkLevel;
    /**
     * Whether we need to print more detailed logs.
     */
    public static boolean debugLog;

    /**
     * Whether the current process is debuggable.
     */
    // Android 8.0+ and debug mode, ART may force the use of interpreter mode,
    // and entry_point_from_compiled_code_ will be ignored. Set kAccNative to avoid it.
    // See ClassLinker::ShouldUseInterpreterEntrypoint(ArtMethod*, const void*)
    public static boolean debuggable;

    /**
     * Whether all Pierce hooks won't take effect.
     */
    public static boolean disableHooks;

    /**
     * Internal API. Whether we should use fast-native to speedup jni method calling.
     */
    public static boolean useFastNative;
    /** Set to true will try to hide certain features. Some information used for debugging may be erased.  */
    public static boolean antiChecks;
    /** Set to true will disable the hidden api policy for application domain */
    public static boolean disableHiddenApiPolicy = true;
    /** Set to true will disable the hidden api policy for platform domain */
    public static boolean disableHiddenApiPolicyForPlatformDomain = true;

    /**
     * A function to load our native library (libpierce.so)
     * @see Pierce.LibLoader
     */
    public static Pierce.LibLoader libLoader = new Pierce.LibLoader() {
        @Override public void loadLib() {
            System.loadLibrary("pierce");
        }
    };

    public static Context context;

    static {
        sdkLevel = Build.VERSION.SDK_INT;
        if (sdkLevel == 34/*Build.VERSION_CODES.UPSIDE_DOWN_CAKE*/) {
            if (isAtLeastPreReleaseCodename("VanillaIceCream")) {
                // Android 15 (VanillaIceCream) Preview
                sdkLevel = 34/*Build.VERSION_CODES.UPSIDE_DOWN_CAKE*/ + 1;
            }
        }

        //pierce特有
        debugLog = false;
        //pierce的宿主根据debuggable,外面在设置一下
        debuggable = true;
        disableHooks = false;
    }

    // https://cs.android.com/androidx/platform/frameworks/support/+/androidx-main:core/core/src/main/java/androidx/core/os/BuildCompat.java;l=49;drc=f8ab4c3030c3fbadca32a9593c522c89a9f2cadf
    private static boolean isAtLeastPreReleaseCodename(String codename) {
        final String buildCodename = Build.VERSION.CODENAME.toUpperCase(Locale.ROOT);

        // Special case "REL", which means the build is not a pre-release build.
        if ("REL".equals(buildCodename)) {
            return false;
        }

        return buildCodename.compareTo(codename.toUpperCase(Locale.ROOT)) >= 0;
    }

    private PierceConfig() {
        throw new RuntimeException();
    }
}
