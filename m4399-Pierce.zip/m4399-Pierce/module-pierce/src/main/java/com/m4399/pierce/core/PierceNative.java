package com.m4399.pierce.core;

import java.lang.reflect.Member;
import java.lang.reflect.Method;

public class PierceNative {

    public static int arch;

    /** Internal API, used by enhances library. DO NOT USE THEM. */
    public static long openElf, findElfSymbol, closeElf, getMethodDeclaringClass, syncMethodEntry,
            suspendVM, resumeVM;


    public static native void init0(int androidVersion, boolean debug, boolean debuggable,
                             boolean antiChecks, boolean disableHiddenApiPolicy,
                             boolean disableHiddenApiPolicyForPlatformDomain);

    public static native void enableFastNative();

    public static native long getArtMethod(Member method);

    public static native Method hook0(long thread, Class<?> declaring, Pierce.HookRecord hookRecord,
                                      Member target, Method bridge, Method backup, boolean isInlineHook,
                                      boolean jni, boolean proxy);

    public static native Method hookReplace0(long thread, Class<?> declaring, Pierce.HookRecord hookRecord,
                                              Member target, Method replacement, Method backup,
                                              boolean isInlineHook, boolean jni, boolean proxy);

    public static native boolean compile0(long thread, Member method);

    public static native boolean decompile0(Member method, boolean disableJit);

    public static native boolean disableJitInline0();

    public static native void setJitCompilationAllowed0(boolean allowed, boolean autoCompileBridge);

    public static native boolean disableProfileSaver0();

    public static native Object getObject0(long thread, long address);

    public static native long getAddress0(long thread, Object o);

    public static native void syncMethodInfo(Member origin, Method backup, boolean skipDeclaringClass);

    public static native long currentArtThread0();

    public static native void setDebuggable0(boolean debuggable);

    public static native void disableHiddenApiPolicy0(boolean application, boolean platform);

    public static native void makeClassesVisiblyInitialized(long thread);

    public static native long getArtMethodEntryPointFromCompiledCode(Member method);

    public static native String getArtMethodEntryPointHexString(Member method,int maxDumpHexSize);

    public static native boolean generateDex(String dexPath,
                                             Member targetMethod,
                                             boolean isStatic,
                                             Method handleCallMethod,
                                             String generateClassName,
                                             String generateMethodName,
                                             String generateBackupMethodName,
                                             String generateShorty,
                                             String generateFieldName);

    public static native void setLogFilePath(String logFilePath);

    public static native boolean writeLogToFile(String logLevel,
                                                String logTag,
                                                String logMsg);

}
