package com.plugin.proguard

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.TaskAction
import java.lang.Exception

/**
 * Description:
 *
 * @author  wang.zhiwei
 * @date    2021年09月15日 17:55
 *
 * Copyright (c) 2021年, 4399 Network CO.ltd. All Rights Reserved.
 */
open class ProguardDefaultTask : DefaultTask() {

    @Input
    lateinit var buildType: String

    fun doTask(block: () -> Unit) {
        try {
            block()
        }catch (e: Exception){
            e.printStackTrace()
        }
    }

}