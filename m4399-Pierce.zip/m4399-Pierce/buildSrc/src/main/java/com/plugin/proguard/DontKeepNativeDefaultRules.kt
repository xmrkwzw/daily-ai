package com.plugin.proguard

import org.gradle.api.tasks.TaskAction
import java.io.File

/**
 * @author  wang.zhiwei
 * @date    2021年12月02日 18:59
 *
 * Copyright (c) 2021年, 4399 Network CO.ltd. All Rights Reserved.
 */
open class DontKeepNativeDefaultRules : ProguardDefaultTask() {
    private val nativeKeep = "-keepclasseswithmembernames,includedescriptorclasses class * {\n" +
            "    native <methods>;\n" +
            "}"

    @TaskAction
    fun delete() {
        doTask {
            //删除系统默认的 native keep规则
            val defaultFile = File(project.buildDir, "intermediates/default_proguard_files/global")
            defaultFile.listFiles()?.forEach {
                var content = it.readText()
                content = content.replace(nativeKeep, "")
                it.writeText(content)
            }
        }

    }
}
