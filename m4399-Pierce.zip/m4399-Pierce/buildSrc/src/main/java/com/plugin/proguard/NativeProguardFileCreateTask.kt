package com.plugin.proguard

import com.android.build.gradle.AppExtension
import com.plugin.extension.android
import com.plugin.proguard.RandomNameHelper.randomLetterCheck
import org.gradle.api.tasks.TaskAction
import java.io.File

/**
 * Description: 动态生成三个混淆文件.
 *
 * @author  wang.zhiwei
 * @date    2021年09月16日 16:26
 *
 * Copyright (c) 2021年, 4399 Network CO.ltd. All Rights Reserved.
 */
open class NativeProguardFileCreateTask : ProguardDefaultTask() {
    private var isMinifyEnabled = false
    private var classMap = mutableMapOf<String, String>()

    fun setMinifyEnabled(minifyEnable: Boolean) {
        isMinifyEnabled = minifyEnable
    }

    @TaskAction
    fun create() {
        doTask {

            project.rootProject.subprojects {
                val nameHFile = File("${it.projectDir}/src/main/cpp/Named.h")
                if (!nameHFile.exists()) {
                    return@subprojects
                }

                //创建 NamedGen头文件
                val copyFile = File("${it.projectDir}/src/main/cpp/NamedGen.h")
                val rootDirPath =if(project.android is AppExtension){
                    "${project.projectDir}/build/intermediates/aapt_proguard_file/$buildType/process${buildType}Resources"
                }else{
                    "${project.projectDir}/build/intermediates/aapt_proguard_file/$buildType/generate${buildType}LibraryProguardRules"
                }

                //创建native.mapping文件用于指定native方法的混淆并修改复制的模板文件
                val nativeMappingFile = File("${rootDirPath}/native.mapping")
                if (!nativeMappingFile.parentFile.exists()) {
                    nativeMappingFile.parentFile.mkdirs()
                }

                //nameGen.h
                val fileStringBuffer = StringBuilder()
                //native.mapping
                val mappingStringBuffer = StringBuilder()

                if (isMinifyEnabled) {
                    val random = File("${project.projectDir}/build/intermediates", "temp.txt").readText()
                    nameHFile.readLines().forEach { line ->
                        when {
                            line.startsWith("O_CLASS") -> {
                                //O_CLASS(com___m4399___library_native___NativeUtils, com/m4399/library_native/NativeUtils);
                                val randomClassName = "${random}/${randomLetterCheck()}"
                                fileStringBuffer.append("${getClassName(line)[0].trim()}, $randomClassName)\n")
                                fileStringBuffer.append(defineClassName(line, randomClassName))
                                mappingStringBuffer.append("${getClassName(line)[1].trim()} -> ${randomClassName}:\n".replace("/", "."))
                                classMap[getKey(line)] = randomClassName
                            }
                            line.startsWith("O_FIELD") -> {
                                //O_FILED(int , arch ,arch)    int arch -> j
                                val randomFiledName = randomLetterCheck()
                                fileStringBuffer.append(line.replace(line.split(",")[2], "$randomFiledName)")).append("\n")
                                mappingStringBuffer.append("\t${
                                    line.run {
                                        substring(indexOf("(") + 1, indexOf(","))
                                    }
                                } ${line.split(",")[1].trim()} -> $randomFiledName\n")
                            }
                            line.startsWith("O_FUNC") -> {
                                //O_FUNC(boolean, nativeHookOpenDexFileNative(java.lang.reflect.Method), nativeHookOpenDexFileNative)
                                val randomFunName = randomLetterCheck()
                                val tempStr = line.replace(line.substring(line.lastIndexOf(",") + 1, line.lastIndexOf(")") + 1), "${randomFunName})")
                                fileStringBuffer.append("${tempStr}\n")
                                mappingStringBuffer.append("\t${resolveFuncName(line, randomFunName)}\n")
                            }
                            line.startsWith("O_INTERFACE") -> {
                                //O_INTERFACE(com___m4399___pierce___core___NativeMark$I, com/m4399/pierce/core/NativeMark$I)
                                val interfaceName = randomLetterCheck()
                                fileStringBuffer.append("${getClassName(line)[0].trim()}, ${classMap[getKey(line)]}\$$interfaceName)\n")
                                mappingStringBuffer.append("${getClassName(line)[1].trim()} -> ${classMap[getKey(line)]}\$$interfaceName:\n".replace("/", "."))
                            }
                            else -> {
                                fileStringBuffer.append("${line}\n")
                            }
                        }
                    }

                    copyFile.writeText(fileStringBuffer.toString())
                    nativeMappingFile.writeText(mappingStringBuffer.toString())
                } else {
                    val nameHContent = nameHFile.readText()
                    //debug模式下如果文件内容已经相同, 则不重新写入防止被判断为文件有修改
                    if (copyFile.exists() && nameHContent == copyFile.readText()) {
                        return@subprojects
                    }
                    nameHFile.readLines().forEach { line ->
                        fileStringBuffer.append("${line}\n")
                        if (line.startsWith("O_CLASS")) {
                            fileStringBuffer.append(defineClassName(line))
                        }
                    }
                    copyFile.writeText(fileStringBuffer.toString())
                }
            }
        }
    }

    /**
     * O_CLASS(com___m4399___pierce___core___PierceNative, com/m4399/pierce/core/PierceNative)
     * #define com___m4399___pierce___core___PierceNative___name Lcom/m4399/pierce/core/PierceNative;
     */
    private fun defineClassName(line: String, ofcuName_: String? = null): String {
        val cParam = line.substring(line.lastIndexOf("(") + 1, line.lastIndexOf(",")).trim()
        val ofcuName = ofcuName_ ?: line.substring(line.lastIndexOf(",") + 1, line.lastIndexOf(")")).trim()
        return "#define ${cParam}___name \"L$ofcuName;\"\n"
    }

    /**
     *  O_CLASS(com___m4399___pierce___core___NativeMark, com/m4399/pierce/core/NativeMark)
     *
     * 根据逗号拆分
     */
    private fun getClassName(line: String): List<String> {
        return line.substring(0, line.length - 1).split(",")
    }

    /**
     *  O_CLASS(com___m4399___pierce___core___NativeMark, com/m4399/pierce/core/NativeMark)
     *  O_INTERFACE(com___m4399___pierce___core___NativeMark$I, com/m4399/pierce/core/NativeMark$I)
     * 得到com___m4399___pierce___core___NativeMark
     */
    private fun getKey(line: String): String {
        return line.split(",")[0].run {
            substring(indexOf("(") + 1, if (contains("\$")) indexOf("\$") else length).trim()
        }
    }

    /**
     * 根据模板生成对应的混淆内容
     * O_FUNC(boolean, nativeHookOpenDexFileNative(java.lang.reflect.Method), nativeHookOpenDexFileNative)
     * boolean nativeHookOpenDexFileNative(java.lang.reflect.Method) -> aaa
     * @param line 原内容
     * @param funcProguardName 混淆后的方法名
     */
    private fun resolveFuncName(line: String, funcProguardName: String): String {
        return StringBuffer().apply {
            append(line.subSequence(line.indexOf("(") + 1, line.indexOf(",")))
            append(line.subSequence(line.indexOf(",") + 1, line.lastIndexOf(",")))
            append(" -> ")
            append(funcProguardName)
        }.toString()
    }
}