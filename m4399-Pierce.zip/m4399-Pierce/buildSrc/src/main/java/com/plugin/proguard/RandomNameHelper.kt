package com.plugin.proguard

/**
 * Description: TODO.
 *
 * @author  wang.zhiwei
 * @date    2022年05月23日 18:02
 *
 * Copyright (c) 2022年, 4399 Network CO.ltd. All Rights Reserved.
 */
object RandomNameHelper {
    private const val RANDOM_NUM = 2
    /**
     * 生成对应个数的随机字母
     */
    private fun getRandomLetter(): String {
        val letters = "abcdefghijklmnopqrstuvwxyz"

        val buff = StringBuffer()
        for (i in 1..RANDOM_NUM) {
            val str = letters[(Math.random() * letters.length).toInt()]
            buff.append(str)
        }
        return buff.toString()
    }

    /**
     * 避免出现同字母组合的情况
     */
    private var letterArray = mutableListOf<String>()
     fun randomLetterCheck():String{
        var letter = getRandomLetter()
        while (letterArray.contains(letter)){
            letter = getRandomLetter()
        }
        letterArray.add(letter)
        return letter
    }
}