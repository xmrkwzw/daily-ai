package com.plugin.extension

import com.android.build.gradle.AppExtension
import com.android.build.gradle.BaseExtension
import com.android.build.gradle.LibraryExtension
import com.android.build.gradle.api.AndroidSourceSet
import com.android.build.gradle.internal.api.ApplicationVariantImpl
import com.android.build.gradle.internal.api.LibraryVariantImpl
import com.android.build.gradle.internal.variant.LibraryVariantData
import org.gradle.api.DomainObjectSet
import org.gradle.api.NamedDomainObjectContainer
import org.gradle.api.Project


/**
 *
 * Android Gradle Plugin 扩展
 *
 * @author  LinZhiWei
 * @date    2020年01月02日 11:22
 *
 * Copyright (c) 2020年, 4399 Network CO.ltd. All Rights Reserved.
 */

/**
 * 返回引入的 "com.android.application" 或者 "com.android.library" 插件的扩展对象, 这个对象不包含 "applicationVariant" 和 "libraryVariant"
 */
val Project.android: BaseExtension
    get() = property("android") as BaseExtension


val BaseExtension.applicationVariants: DomainObjectSet<ApplicationVariantImpl>
    @SuppressWarnings("unchecked")
    get() {
        return ((this as AppExtension).applicationVariants) as DomainObjectSet<ApplicationVariantImpl>
    }

val BaseExtension.libraryVariants: DomainObjectSet<LibraryVariantImpl>
    @SuppressWarnings("unchecked")
    get() {
        return (this as LibraryExtension).libraryVariants as DomainObjectSet<LibraryVariantImpl>
    }

val NamedDomainObjectContainer<AndroidSourceSet>.main: AndroidSourceSet
    get() = getByName("main")

fun LibraryVariantImpl.getVariantData(): LibraryVariantData {
    return get("variantData") as LibraryVariantData
}

