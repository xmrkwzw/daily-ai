package com.plugin.proguard

import com.plugin.extension.android
import org.gradle.api.tasks.TaskAction
import java.io.File

/**
 * Description: TODO.
 *
 * @author  wang.zhiwei
 * @date    2021年12月02日 19:03
 *
 * Copyright (c) 2021年, 4399 Network CO.ltd. All Rights Reserved.
 */
open class RandomFileCreateTask : ProguardDefaultTask(){

    @TaskAction
    fun create(){
        val randomFile = File("${project.projectDir}/build/intermediates", "temp.txt")
        randomFile.parentFile.mkdirs()
        randomFile .writeText(getRandomLetter(1) + project.android.defaultConfig.versionCode)
    }


    /**
     * 生成对应个数的随机字母
     * @param num 生成个数
     */
    private fun getRandomLetter(num: Int): String {
        val letters = "abcdefghijklmnopqrstuvwxyz"

        val buff = StringBuffer()
        for (i in 1..num) {
            val str = letters[(Math.random() * letters.length).toInt()]
            buff.append(str)
        }
        return buff.toString()
    }
}