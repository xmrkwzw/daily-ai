package com.plugin.proguard

import com.android.build.gradle.AppExtension
import com.android.build.gradle.LibraryExtension
import com.android.build.gradle.internal.api.BaseVariantImpl
import com.android.build.gradle.internal.tasks.factory.dependsOn
import com.plugin.extension.android
import com.plugin.extension.applicationVariants
import com.plugin.extension.libraryVariants
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.tasks.TaskContainer
import java.io.File

/**
 * Description: TODO.
 *
 * @author  wang.zhiwei
 * @date    2021年12月02日 13:58
 *
 * Copyright (c) 2021年, 4399 Network CO.ltd. All Rights Reserved.
 */
class NativeProguardPlugin : Plugin<Project> {

    override fun apply(target: Project) {
        val taskContainer: TaskContainer = target.tasks

        target.afterEvaluate {
            if (it.android is AppExtension) {
                it.android.applicationVariants.forEach { variant ->
                    handleVariant(variant, it, taskContainer, target)
                }
            } else {
                it.android.libraryVariants.forEach { variant ->
                    handleVariant(variant, it, taskContainer, target)
                }
            }
        }
    }

    private fun handleVariant(variant: BaseVariantImpl, it: Project, taskContainer: TaskContainer, target: Project) {
        val buildType = variant.buildType.name.replaceFirstChar { it.uppercaseChar() }
        val rootDirPath = if (it.android is AppExtension) {
            "${it.projectDir}/build/intermediates/aapt_proguard_file/$buildType/process${buildType}Resources"
        } else {
            "${it.projectDir}/build/intermediates/aapt_proguard_file/$buildType/generate${buildType}LibraryProguardRules"
        }
        val proguardFile = File(
            "${it.projectDir}/build/intermediates/merged_consumer_proguard_file/${variant.name}/merge${buildType}ConsumerProguardFiles/proguard.txt"
        )

        val randomFileCreateTask = taskContainer.register("RandomFileCreateTask$buildType", RandomFileCreateTask::class.java) { task ->
            task.buildType = buildType
        }

        val preBuildReleaseTask = taskContainer.named("pre${buildType}Build")
        preBuildReleaseTask.configure { it.dependsOn(randomFileCreateTask) }

        /* 动态创建native.mapping文件用于指定native方法的混淆并修改复制的模板文件*/
        val proguardFileCreateTask = taskContainer.register("NativeProguardFileCreateTask$buildType", NativeProguardFileCreateTask::class.java) {
            it.buildType = buildType
            it.setMinifyEnabled(variant.buildType.isMinifyEnabled)
        }

        if (variant.buildType.isMinifyEnabled) {
            //保证merge${buildType}ConsumerProguardFiles/proguard.txt,append正常
            randomFileCreateTask.dependsOn("clean")

            randomFileCreateTask.configure { it.finalizedBy(proguardFileCreateTask) }
            //新as(Panda+首次出现) R8流程兼容，控制native编译时机，等待namedGen文件完成生成后再读取文件
            val libProject = target.rootProject.project(":module-pierce")
            libProject.tasks.matching {
                it.name.startsWith("pre${buildType}Build")
            }.configureEach {
                it.dependsOn(proguardFileCreateTask)
            }
        }
        preBuildReleaseTask.configure {
            it.dependsOn(proguardFileCreateTask)
        }

        if (!variant.buildType.isMinifyEnabled) {
            return
        }

        //native方法参与混淆
        val mergeJavaResource = taskContainer.findByName("merge${buildType}JavaResource")
        val nativeRulesDeleteTask = taskContainer.create("DontKeepNativeDefaultRules$buildType", DontKeepNativeDefaultRules::class.java)
        nativeRulesDeleteTask.buildType = buildType
        mergeJavaResource?.finalizedBy(nativeRulesDeleteTask)

        val nativeProguardRulesFile = File(rootDirPath, "native-proguard-rules.pro")
        val clazz = if (it.android is AppExtension) {
            AppExtension::class.java
        } else {
            LibraryExtension::class.java
        }
        target.extensions.getByType(clazz).run {
            buildTypes.getByName("release").apply {
                proguardFile(nativeProguardRulesFile)
            }
        }

        //动态添加混淆文件
        taskContainer.named("minify${buildType}WithR8").configure { r8Task ->
            r8Task.doFirst {
                nativeProguardRulesFile.writeText(StringBuffer().apply {
                    append("-applymapping native.mapping\n")
                    append("-dontshrink\n")
                }.toString())
                //有组件mapping时添加,无mapping首次打包会自动生成，后续使用同份文件
                val random = File("${target.projectDir}/build/intermediates", "temp.txt").readText()
                proguardFile.appendText(
                    "#--------------keep混淆，不再触发二次混淆--------------------#" +
                            "\n -keep class $random.** { *; }" +
                            "\n"
                )
                println("Custom proguard rules written to: ${nativeProguardRulesFile.absolutePath}")
            }
        }

    }
}