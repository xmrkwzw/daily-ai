---
name: bugfix
description: Use when the user provides Java, Native, Android crash, tombstone, logcat, or stack trace information and needs ABI/BuildId-matched symbol restoration, root-cause analysis, and a fix proposal.
---

# BugFix

根据用户提供的 Java、Native 或混合堆栈，优先使用日志中的 ABI、库名和 BuildId 精确匹配符号文件，再基于还原结果分析错误原因和给出解决方案。

## 工作边界

- 默认只分析和报告，不直接修改业务源码、构建配置或符号文件。
- 完成堆栈还原和根因分析，再提出最小修改方案；修改前仍需遵守项目的 AGENTS.md 规则。
- 不使用“最新版本”或“最接近版本”的 mapping、Native symbols 代替精确匹配结果。
- 若用户指定了符号信息的目录，则使用用户提供目录的符号信息进行分析。
- Native 无法确认 ABI、库名或 BuildId 匹配关系时，明确报告证据不足，不得猜测；仅缺少运行时包版本不阻塞 Native 分析。
- 不把未还原的函数名、地址或行号描述为确定根因。

## 1. 接收和分类堆栈

接受用户直接粘贴的堆栈、项目内的日志文件路径，或两者混合。保留原始内容，不修改原始日志。

识别以下类型：

- Java：`FATAL EXCEPTION`、`Caused by`、。
- Native：`Fatal signal`、`backtrace`、`#00 pc`、tombstone 格式。
- 混合崩溃：同时存在 Java 异常和 Native backtrace。分别还原，之后按时间、线程和调用关系关联分析。

只保存分析所需的上下文，不读取无关日志或源码：

- 异常类型、异常消息、线程名和线程状态。
- 进程包名、ABI、设备/系统版本、Build fingerprint（日志已提供时不重复查询）。
- Native 库名称、PC 地址/偏移、BuildId、信号和完整 backtrace。
- 运行时包版本及其来源，若存在；不得把它当作 native 构建版本。

## 2. 按 Native 身份定位符号文件

### Native 匹配

Native 版本通常不能从错误堆栈确定。以日志中的 `ABI + 库名 + BuildId` 为匹配键，版本目录名只能作为检索提示，不能替代 BuildId 校验。版本未知不应阻塞 Native 符号匹配。

如果需要设备包版本，只能写成“设备当前安装包版本”，证据必须明确来自 `dumpsys package`、APK 元数据或用户提供的信息；不能写成“Native 版本”。

Java 和 Native 分别匹配；若版本信息或 BuildId 不一致，明确标记为可能混合了不同构建产物。

### Java mapping

仅在 Java 堆栈需要还原且版本有可靠证据时，定向查找并确认文件内容确实是 R8/ProGuard mapping：

- `module-pierce/outputs/mapping/mapping-<version>.txt`

文件名版本必须与已确认的 Java 运行时版本完全相等。版本未知或证据不足时，报告 mapping 缺失，不得猜测。

### Native symbols

只定向查找日志库名对应的 `.so`，优先使用用户指定目录、精确 ABI 目录和 unstripped 产物；不要扫描整个项目的所有版本或所有源码文件。

通过 ELF BuildId 确认符号 SO 与日志完全匹配。若无法匹配，报告库名、ABI、BuildId 和已检查路径，不得用相邻版本替代。

确认目录中包含对应的 unstripped `.so`，并优先检查 `.debug_line`、`.debug_info` 和 `.symtab`。

Native symbols 通常按 ABI 分目录，例如：

```text
native-symbols/
└── <version>/
    ├── arm64-v8a/libpierce.so
    └── armeabi-v7a/libpierce.so
```

必须根据堆栈中的 ABI、设备信息或库架构选择具体 ABI 目录。`ndk-stack -sym` 应指向直接包含 `lib*.so` 的目录；不要默认把包含多个 ABI 子目录的版本根目录作为 `-sym` 参数。

## 3. 执行符号还原

### Java

仅在存在 Java 混淆堆栈时，定位可用的 R8 retrace 工具并先确认帮助信息；没有 Java 混淆堆栈时不执行 retrace。

使用精确版本的 mapping 还原 Java 堆栈，保留：

- 原始 Java 堆栈。
- 还原后的类名、方法名、文件名和行号。
- mapping 缺失、格式不匹配或行号无法还原的帧。

### Native

仅在 Native 符号已通过 ABI、库名和 BuildId 匹配后，核实并使用对应 ABI 的 `ndk-stack` 或 `llvm-addr2line`：

```text
ndk-stack -sym <version>/<abi> -dump <native-stack-file>
```

如果只有单个 PC 地址，使用对应 ABI 的 unstripped `.so` 和 `llvm-addr2line` 进行函数、文件和行号还原。使用前确认地址是相对 PC、是否包含 load bias，以及日志是否带有 offset；必要时说明地址调整依据。

还原后检查：

- Native 库名是否与 symbols 中的库名一致。
- ABI 是否一致。
- BuildId 是否一致（如果日志和 ELF 都提供）。
- 还原出的函数、源文件和行号是否来自当前版本。

## 4. 分析根因

按“事实、推断、待确认项”分层，不把推断写成事实。

优先分析：

- Java 异常类型和消息对应的失败条件。
- 最先出现的业务源码帧，而不是只看最外层框架帧。
- Native 中最早可还原的项目源码帧、崩溃信号、寄存器/访问地址和线程状态。
- Java 到 JNI/Native 的边界，以及跨线程、生命周期、锁和内存访问关系。
- 是否存在版本、ABI、BuildId 或 mapping 不匹配导致的假象。
- 是否能从源码、调用方、资源和构建配置中验证根因。

需要源码验证时，从最早的项目源码帧开始，完整阅读相关函数和实际调用链；不要读取无关整文件。若源码证据不足，明确列为“待确认”，并给出最小化的日志或复现建议。

## 5. 输出结果

使用以下结构输出：

```text
## 堆栈还原结果
- 类型：Java / Native / 混合
- 运行时包版本：<值或未知>（证据：<dumpsys/APK/用户信息；Native 日志未提供时不得补写>）
- Java mapping：<路径或缺失原因>
- Native symbols：<路径、ABI、库名、BuildId 或缺失原因>
- 工具：<实际使用的工具和版本/路径>

## 关键还原帧
- 原始帧：<原始内容>
- 还原帧：<类、方法、文件、行号或函数>
- 置信度：高 / 中 / 低

## 根因分析
- 已确认事实：<源码或堆栈证据>
- 主要根因：<结论及证据>
- 其他可能性：<替代解释>
- 待确认项：<缺失的日志、版本、ABI 或源码证据>

## 解决方案
1. <最小修复方案，以及适用原因>
2. <必要时的防御、监控或回归测试>

## 验证建议
- <复现步骤>
- <回归测试>
- <发布后需要保留的版本/ABI/symbols 信息>
```

如果还原失败，仍按同样结构输出失败点、已检查的路径、缺少的输入和下一步所需信息；不要输出伪造的源码位置或根因结论。
