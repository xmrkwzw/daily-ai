---
name: crash
description: 用于自动采集当前项目最新闪退并交给 bugfix 技能分析
---

# Crash

当用户提出“分析闪退问题”“分析闪退原因”或语义等价的请求时，先从已授权设备获取最新 crash buffer，再将单个完整事件交给 `bugfix`。不要先扫描项目目录或读取无关源码。

## 工作流程

### 1. 连接后立即取日志

先执行 `adb devices -l`。只有一个状态为 `device` 的设备时，立即执行：

```text
adb -s <serial> logcat -d -b crash -v threadtime
```

- 多个在线设备时不得猜测目标设备，要求用户选择 serial。
- 没有在线设备、设备未授权、离线或 adb 失败时停止自动采集。
- 从 crash buffer 按时间戳选择最新一个完整事件，只保留该事件原始行，不读取整份普通 logcat。
- 只有 crash buffer 为空或事件不完整时，才读取普通 buffer，并只提取包含闪退标志的完整事件。
- Java 标志：`FATAL EXCEPTION`、`Process:`、`Caused by:`。
- Native 标志：`Fatal signal`、`*** ***`、`backtrace:`、`#00 pc`、`Build fingerprint:`。

### 2. 先解析 Native 身份

Native 日志中的以下字段优先级最高，直接从日志提取，不用设备命令重复获取：

- ABI：`ABI:`。
- 库名、PC 和偏移：`backtrace` 中的 `.so` 帧。
- BuildId：每个 native `.so` 帧的 `BuildId`。
- 包名、进程、线程、信号、fault address、寄存器和完整 backtrace。

用“库名 + ABI + BuildId”核对符号文件。先检查用户指定路径，再定向检查对应库名的 Debug unstripped `.so` 、native symbols和合并产物；禁止先列出整个 build 目录或所有版本目录。

检查 ELF 是否含 `.debug_line`、`.debug_info` 或 `.symtab`，并核对 BuildId。只有库名、ABI、BuildId 全部匹配时，才能报告准确的源码函数或行号。

### 3. 版本只作上下文

Native 错误堆栈通常不能确定 `versionName` 或 `versionCode`。不得把 Native 日志中的 ABI、BuildId 或设备包信息表述为 native 构建版本。

- `dumpsys package <package>` 仅在确需运行时包版本、APK 路径或 Java mapping 时按需执行。
- 其结果只能标记为“设备当前安装包版本”，不能单独证明崩溃 `.so` 的构建版本。
- Native 符号选择以 ABI、库名和 BuildId 为准；版本未知不阻塞 BuildId 匹配。
- 日志和设备都无法提供版本时，写明“版本未知”，不得选择最新或相邻版本。
- 日志已提供 ABI、Android 版本或 Build fingerprint 时，不再执行对应 `getprop`。

### 4. 分类和最小交接

- 仅 Java 异常：Java。
- 含 native signal/backtrace/tombstone：Native。
- 两者同时存在：Mixed，分别保留和还原。

只向 `bugfix` 传递最新完整崩溃事件和必要上下文，不传整个 logcat buffer。源码分析只从最早的项目帧开始，定向读取相关函数及其实际调用链，避免读取无关整文件。

```text
## Crash -> BugFix Context
- device serial/status: <value>
- package: <value or unknown>
- runtime package version: <value or unknown; dumpsys evidence only>
- ABI: <value and log evidence>
- Android/fingerprint: <value if present in log>
- crash type/timestamp: <value>
- native identity: <library, ABI, BuildId, PC/offset>
- Java mapping: <exact path or not applicable/missing>
- Native symbols: <exact matching path or mismatch reason>
- tools: <actual tools used>

### Original crash event
<完整、未修改的最新闪退事件，不是整份 logcat>
```

### 5. 采集失败处理

- 没有设备或没有完整事件：报告缺少原始日志。
- Native 缺少 ABI、库名或 BuildId：报告无法精确匹配的字段。
- 符号库 BuildId、ABI 或库名不匹配：报告已检查的定向路径和不匹配原因。
- 版本未知：继续进行 Native BuildId 分析，并将版本标为未知。
- 任何未还原的地址、函数名或行号都不得作为确定根因。
