# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

`m4399-Pierce` 是一个 Android ART 运行时 Java 方法 Hook SDK（`libpierce.so` + AAR），源自 Pine（canyie/Pine）的二次开发。核心能力：在运行时修改 `ArtMethod` 结构，通过 **inline hook**（覆盖目标方法已编译机器码前几条指令）或 **entry-point replacement**（改写 `entry_point_from_compiled_code_`）拦截 Java 方法，支持 before/after 回调、整方法替换、JNI 方法、构造器、Proxy 方法、多线程压力场景。

三个 Gradle 工程：
- `:module-pierce` — SDK 库，产出 `libpierce.so`（C++）+ AAR（Java）
- `:app` — Demo App，启动即跑一整套 Hook 测试（参数类型 Arg0~Arg8888、JNI/Proxy/异常/多线程等）
- `buildSrc` — 自定义 Gradle 插件，实现 native 混淆与符号归档（见下文「Native 混淆机制」）

## 构建

**注意：仓库没有 `gradlew` 脚本**，只有 `gradle/wrapper/gradle-wrapper.jar`（Gradle 8.9）。用 Android Studio 或本机 `gradle` 命令构建。

版本配置集中在根目录 `config.gradle`：AGP 8.7.2、Kotlin 1.9.0、NDK 21.3.6528147、minSdk 21 / target 34 / compile 33、`versionCode`/`versionName`（实际 `versionName` 拼为 `${versionName}.${versionCode}`，当前为 `1.2.30`）。

常用任务（定义于 `gradle/gradle-maven-push.gradle`）：

| 命令 | 作用 |
|------|------|
| `gradle buildAARRelease` | 打包并发布 release AAR 到 maven-releases |
| `gradle buildAARReleaseWithSymbols` | 同上，但关闭 native 混淆（`-DPIERCE_STACKTRACE_BUILD=ON`），保留符号用于闪退还原 |
| `gradle buildAARSnapshot` | 发布 SNAPSHOT 到 maven-snapshots |
| `gradle buildAARSnapshotWithUnitTest` | 先跑 `:m4399-download:connectedAndroidTest` 再发布 SNAPSHOT |
| `gradle :app:assembleDebug` / `:app:assembleRelease` | 构建 Demo App（release 用 `app/libs` 下的 AAR，debug 用 `:module-pierce` 工程） |
| `gradle :app:installDebug` | 安装并自动启动 Demo App（`app/build.gradle` 的 `afterEvaluate` 里 adb 拉起 MainActivity） |

构建产物约定：
- AAR：`module-pierce/outputs/aar/module-pierce-release-<version>.aar`，同时复制到 `app/libs/`
- 混淆 mapping：`module-pierce/outputs/mapping/mapping-<version>.txt`
- native 符号：`module-pierce/outputs/native-symbols/<version>/<abi>/libpierce.so`（由 `copyNativeDebugSymbols` 任务生成）

## 核心架构

### Java 层（`module-pierce/src/main/java/com/m4399/pierce/core/`）

- `Pierce` — 主入口（`hook()`/`invokeOriginalMethod()`/`setHookMode()` 等）。关键点：hook 时会用 slicer 在运行时**生成一个 dex**（bridge 方法 + backup 方法），经 `DexClassLoader` 加载后，把目标 `ArtMethod` 的入口重定向到 bridge，backup 则用于调用原方法。`handleCall()` 是回调分发核心（before → 原方法 → after）。
- `PierceConfig` — 全局配置（`disableHooks`、`debugLog`、`debuggable`、`libLoader` 默认 `System.loadLibrary("pierce")` 等）。
- `PierceNative` — JNI 声明（所有 native 方法），`init0`/`hook0`/`hookReplace0`/`generateDex` 等。
- `callback/MethodHook`、`callback/MethodReplacement` — 用户回调抽象。
- `Pierce.HookRecord` / `Pierce.CallFrame` — hook 状态与调用帧。

Hook 模式：`AUTO`（默认，`< Android O` 走 `INLINE_WITHOUT_JIT`，`>= O` 走 `REPLACEMENT`）、`INLINE`、`REPLACEMENT`、`INLINE_WITHOUT_JIT`。

### Native 层（`module-pierce/src/main/cpp/`，C++17，仅 arm64-v8a + armeabi-v7a）

- `pine.cpp` — JNI 实现（`Pine_*`），native 方法注册表 `gMethods[]`；hook 核心逻辑（suspend VM → 装 trampoline → `BackupFrom`/`AfterHook`）。
- `jni_bridge.cpp` — `JNI_OnLoad`、`register_Pine`/`register_Ruler`。
- `art/` — ART 内部结构访问：`ArtMethod`（通过 `NativeMark` 定位字段偏移）、`Thread`、`Jit`。
- `trampoline/` — 各架构 inline hook 跳板（`trampoline_installer` + `arch/{arm32,thumb2,arm64,x86}`，含汇编 `.S`）。
- `external/DexBuilder` — slicer 库，运行时生成 bridge/backup dex。
- `external/xz-embedded` — xz 解压。
- `utils/` — `elf_image`、`memory`、`jni_helper`、`FileLog`、`ThreadLocalVar` 等。

`CMakeLists.txt` 注意：release 默认加 `-Oz -flto` 和 LLVM 混淆 `-mllvm -fla -mllvm -sobf`；当 `PIERCE_STACKTRACE_BUILD=ON` 时这些参数全部关闭以保留符号。符号导出受 `export_symbols` 版本脚本约束（仅导出 `JNI_OnLoad`）。

## Native 混淆机制（buildSrc 插件，本仓库特有）

`buildSrc` 的 `NativeProguardPlugin` 解决「Java 被 R8 混淆后，C++ 里的 JNI 字符串仍能定位到类/方法/字段」的问题：

- 唯一事实来源是 `module-pierce/src/main/cpp/Named.h`，用 `O_CLASS`/`O_FUNC`/`O_FIELD`/`O_INTERFACE` 宏声明 native 侧引用的所有 Java 符号。
- 插件在构建时生成：
  - `NamedGen.h`（从 `Named.h` 模板 + 随机名生成，native 代码 include 的是它）
  - `native.mapping`（混淆映射，R8 通过 `-applymapping` 消费）
  - `build/intermediates/temp.txt`（随机类名前缀，配合 `-keep class <random>.** { *; }` 防止二次混淆）

**关键约定：新增任何 native 方法、或 native 需要访问的 Java 类/字段/方法，必须同步在 `Named.h` 中用对应宏声明**，否则混淆包运行时 JNI 查找失败。

## 崩溃分析与符号还原

仓库内置两个 OpenCode 技能（`.opencode/skills/`）：
- `crash`：通过 `adb logcat -b crash` 采集最新闪退事件，交给 `bugfix`。
- `bugfix`：按 `ABI + 库名 + BuildId` 精确匹配 `module-pierce/outputs/native-symbols` 与 `mapping-<version>.txt`，用 `ndk-stack` / `llvm-addr2line` 还原 native 栈，再定位根因。**不得**用「最新/相邻版本」的 mapping 或 symbols 替代精确匹配。

只有 `buildAARReleaseWithSymbols` 任务产出的符号 `.so` 才含 `.debug_line`/`.debug_info` 可用于还原。

文档在 `doc/`：`pierce变更文档.md`（变更记录）、`pierce常见问题回答.txt`（如 Android 5-6 AOT 内联导致 hook 失效）、以及若干 `.txt` 修改点说明（含「无锁线程局部变量」完整流程）。

## 关键注意点

- Demo App 的 `MainActivity` 在 `onCreate` 即跑全量测试；release 构建 `assembleRelease` 会 `adb install` + 启动（见 `app/build.gradle`）。
- `app` 依赖头条广告 SDK（`tt_open_ad_sdk_4522.aar`，flatDir），`testTouTiaoJSON()` 会 hook `org.json.JSONObject.put`，且注释标明 Android 5.0/5.1 下头条 SDK 会造成堆内存持续增长。
- Android 5.0–5.1 存在 dex 优化目录与 dex 同目录冲突问题，`Pierce.initSaveDexDirPath` 已按 sdkLevel 分支处理（见 `Pierce.java`）。
- 全局代码规范（Kotlin/Java 风格、判空、集合链式、禁止 `?: return`/`?: throw` 流程控制等）见用户全局 CLAUDE.md，本仓库 Kotlin 与 Java 代码均应遵循。
