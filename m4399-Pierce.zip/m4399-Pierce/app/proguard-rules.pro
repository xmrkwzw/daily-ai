
# JNI_OnLoad 里用 FindClass 硬编码字符串引用的类
-keep class com.m4399.pierce.demo.test.multithread.MultiThreadDirectRegisterJNITest {
     private static native int target(int);
}

-keep class com.m4399.pierce.demo.test.multithread.MultiThreadDynamicLookupJNITest {
     private static native int target(int);
}

-keep class com.m4399.pierce.demo.test.DirectRegisterJNITest {
     private static native int target(int);
}

-keep class com.m4399.pierce.demo.test.DynamicLookupJNITest {
     private static native int target(int);
}

# Test.java / MultiThreadTest.java 通过 ReflectionHelper.getMethod(c, "target", ...)
# *** methodName(...) 意思是"任意返回类型、任意参数列表"。
-keep class com.m4399.pierce.demo.test.** {
    *** target(...);
}

# NotInitedTest 反射的是它的私有静态内部类 I 的 target(int)。
-keep class com.m4399.pierce.demo.test.NotInitedTest$I {
    static int target(int);
}

# TestBean 需要保类 + 保这些方法名。
-keep class com.m4399.pierce.demo.TestBean {
    public *** testString();
    public *** testBoolean();
    public *** testChar();
    public *** testByte();
    public *** testShort();
    public *** testInt();
    public *** testFloat();
    public *** testDouble();
    public *** testLong();
    public *** testPrivateInt();
    private *** privateInt();
}

#MainActivity 自反射 (javaClass.getDeclaredMethod("wrapMethod") 等)。
-keep class com.m4399.pierce.demo.MainActivity {
    private void wrapMethod();
    private void replaceMethod();
    private void testMethodHook();
    private void testMethodReturnValueHook();
    private void testHookNativeMethod();
    private void testHookReplaceMethod();
    private native java.lang.String test1();
}

# tt_open_ad_sdk_4522.aar R8 missing classes - suppress warnings for optional/runtime-only references
-dontwarn android.app.Activity$TranslucentConversionListener
-dontwarn com.android.server.SystemConfig
-dontwarn com.bytedance.JProtect
-dontwarn okhttp3.Call
-dontwarn okhttp3.Dispatcher
-dontwarn okhttp3.Dns
-dontwarn okhttp3.OkHttpClient$Builder
-dontwarn okhttp3.OkHttpClient
-dontwarn okhttp3.Protocol
-dontwarn okhttp3.Request$Builder
-dontwarn okhttp3.Request
-dontwarn okhttp3.Response
-dontwarn okhttp3.ResponseBody
-dontwarn okhttp3.internal.http2.StreamResetException