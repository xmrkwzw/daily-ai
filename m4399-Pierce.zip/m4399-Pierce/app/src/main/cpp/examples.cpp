//
// Created by canyie on 2020/4/24.
//

#include <jni.h>

jint DirectRegisterJNITest_target(JNIEnv*, jclass, jint arg) {
    return arg;
}

extern "C"
JNIEXPORT jint JNICALL Java_com_m4399_pierce_demo_test_DynamicLookupJNITest_target(
        JNIEnv*, jclass, jint i) {
    return i * i;
}

jint MultiThreadDirectRegisterJNITest_target(JNIEnv*, jclass, jint arg) {
    return arg;
}

extern "C"
JNIEXPORT jint JNICALL Java_com_m4399_pierce_demo_test_multithread_MultiThreadDynamicLookupJNITest_target(
        JNIEnv*, jclass, jint i) {
    return i * i;
}

static const JNINativeMethod gDirectRegisterMethods[] = {
        {"target", "(I)I", (void*) DirectRegisterJNITest_target}
};

static const JNINativeMethod gMultiThreadDirectRegisterMethods[] = {
        {"target", "(I)I", (void*) MultiThreadDirectRegisterJNITest_target}
};

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM* jvm, void*) {
    JNIEnv* env;
    if (jvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }
    jclass clazz = env->FindClass("com/m4399/pierce/demo/test/DirectRegisterJNITest");
    if (clazz == nullptr) {
        return JNI_ERR;
    }
    if (env->RegisterNatives(clazz, gDirectRegisterMethods, 1) != JNI_OK) {
        return JNI_ERR;
    }
    env->DeleteLocalRef(clazz);
    jclass multithreadclazz = env->FindClass("com/m4399/pierce/demo/test/multithread/MultiThreadDirectRegisterJNITest");
    if (multithreadclazz == nullptr) {
        return JNI_ERR;
    }
    if (env->RegisterNatives(multithreadclazz, gMultiThreadDirectRegisterMethods, 1) != JNI_OK) {
        return JNI_ERR;
    }
    env->DeleteLocalRef(multithreadclazz);
    return JNI_VERSION_1_6;
}
