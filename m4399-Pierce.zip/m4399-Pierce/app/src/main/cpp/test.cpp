#include <jni.h>

//
// Created by 4399-PC on 2023/6/28.
//
#include <android/log.h>
#define LOG_TAG "pierce_test"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
extern "C"
JNIEXPORT jstring JNICALL
Java_com_m4399_pierce_demo_MainActivity_test1(JNIEnv *env, jobject thiz) {
    LOGI("Java_com_m4399_pierce_MainActivity_test1=%p", Java_com_m4399_pierce_demo_MainActivity_test1);
    return env->NewStringUTF("jni native hook failed");
}