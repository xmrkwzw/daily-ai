package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8844Test extends Test {
    public Arg8844Test() {
        super("target", long.class, long.class, int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8844Test.testImpl() called");
        return target(88449922661100L, 719280880173455L, 180347137, 92848790);
    }

    private static int target(long l, long l2, int i, int i2) {
        PierceDemoLogUtil.logI("Arg8844Test.target() called with arg l " + l + ", l2 " + l2 + ", i " + i + ", i2 " + i2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != 88449922661100L) {
            PierceDemoLogUtil.logE("Arg8844Test [Thread-" + tid + "] l mismatch, expected(l)=" + 88449922661100L + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != 719280880173455L) {
            PierceDemoLogUtil.logE("Arg8844Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 719280880173455L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (i != 180347137) {
            PierceDemoLogUtil.logE("Arg8844Test [Thread-" + tid + "] i mismatch, expected(i)=" + 180347137 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != 92848790) {
            PierceDemoLogUtil.logE("Arg8844Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + 92848790 + ", actual(i2)=" + i2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
