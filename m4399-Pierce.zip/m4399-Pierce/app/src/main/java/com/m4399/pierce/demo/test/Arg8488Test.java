package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8488Test extends Test {
    public Arg8488Test() {
        super("target", long.class, int.class, long.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8488Test.testImpl() called");
        return target(-3135034700286534651L, -1763463188, -6994513459396660740L, -4775050132987728382L);
    }

    private static int target(long l, int i, long l2, long l3) {
        PierceDemoLogUtil.logI("Arg8488Test.target() called with arg l " + l + ", i " + i + ", l2 " + l2 + ", l3 " + l3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != -3135034700286534651L) {
            PierceDemoLogUtil.logE("Arg8488Test [Thread-" + tid + "] l mismatch, expected(l)=" + -3135034700286534651L + ", actual(l)=" + l);
            ok = false;
        }
        if (i != -1763463188) {
            PierceDemoLogUtil.logE("Arg8488Test [Thread-" + tid + "] i mismatch, expected(i)=" + -1763463188 + ", actual(i)=" + i);
            ok = false;
        }
        if (l2 != -6994513459396660740L) {
            PierceDemoLogUtil.logE("Arg8488Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + -6994513459396660740L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (l3 != -4775050132987728382L) {
            PierceDemoLogUtil.logE("Arg8488Test [Thread-" + tid + "] l3 mismatch, expected(l3)=" + -4775050132987728382L + ", actual(l3)=" + l3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
