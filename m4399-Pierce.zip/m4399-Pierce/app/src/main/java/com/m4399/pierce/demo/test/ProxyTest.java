package com.m4399.pierce.demo.test;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.Callable;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class ProxyTest extends Test {
    private static Callable<Long> callable;

    static {
        // noinspection unchecked
        callable = (Callable<Long>) Proxy.newProxyInstance(ProxyTest.class.getClassLoader(),
                new Class<?>[]{Callable.class},
                new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        String methodName = method.getName();
                        switch (methodName) {
                            case "toString":
                                return proxy.getClass().getName()
                                        + "@"
                                        + Integer.toHexString(proxy.hashCode());
                            case "hashCode":
                                return System.identityHashCode(proxy);
                            case "equals":
                                return args != null && proxy == args[0];
                            case "call": {
//                                 LogUtil.log("Proxy method called...");
                                return 114514L;
                            }
                            default: {
                                throw new UnsupportedOperationException("ProxyTest Unexpected method: " + method);
                                //return method.invoke(proxy, args); // 极少数情况尝试默认反射行为
                            }
                        }
                    }
                });
    }

    public ProxyTest() {
        super(callable.getClass(), "call", (Class<?>[]) null);
    }

    @Override
    protected int testImpl() {
        try {
            PierceDemoLogUtil.logI("ProxyTest.testImpl() called");
            Long callRet = callable.call();
            int ret = SUCCESS;
            if (callRet != 1919810L) {
                long tid = Thread.currentThread().getId();
                PierceDemoLogUtil.logE("ProxyTest.testImpl() [Thread-" + tid + "] callRet mismatch, expected(callRet)=" + 1919810L + ", actual(callRet)=" + callRet);
                ret = FAILED;
            }
            return ret;
        } catch (Exception e) {
            PierceDemoLogUtil.logE("ProxyTest.testImpl() Proxy call threw exception", e);
            return FAILED;
        }
    }

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        super.afterCall(callFrame);
        if (Long.valueOf(114514L).equals(callFrame.getResult())) {
            callFrame.setResult(1919810L);
        }
    }
}
