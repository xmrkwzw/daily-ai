package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4848Test extends Test {
    public Arg4848Test() {
        super("target", int.class, long.class, int.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4848Test.testImpl() called");
        return target(730449810, -514730386405315660L, 1019729630, 6134766824746200598L);
    }

    private static int target(int i, long l, int i2, long l2) {
        PierceDemoLogUtil.logI("Arg4848Test.target() called with arg i " + i + ", l " + l + ", i2 " + i2 + ", l2 " + l2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 730449810) {
            PierceDemoLogUtil.logE("Arg4848Test [Thread-" + tid + "] i mismatch, expected(i)=" + 730449810 + ", actual(i)=" + i);
            ok = false;
        }
        if (l != -514730386405315660L) {
            PierceDemoLogUtil.logE("Arg4848Test [Thread-" + tid + "] l mismatch, expected(l)=" + -514730386405315660L + ", actual(l)=" + l);
            ok = false;
        }
        if (i2 != 1019729630) {
            PierceDemoLogUtil.logE("Arg4848Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + 1019729630 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (l2 != 6134766824746200598L) {
            PierceDemoLogUtil.logE("Arg4848Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 6134766824746200598L + ", actual(l2)=" + l2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
