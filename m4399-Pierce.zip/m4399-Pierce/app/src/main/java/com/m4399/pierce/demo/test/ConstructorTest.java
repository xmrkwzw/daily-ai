package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class ConstructorTest extends Test {
    public ConstructorTest() {
        super(Target.class, null, int.class);
    }

    @Override
    protected int testImpl() {
        try {
            PierceDemoLogUtil.logI("ConstructorTest.testImpl() called");
            Target target = new Target(114514);
            int ret = SUCCESS;
            if (!target.success) {
                ret = FAILED;
            }
            return ret;
        } catch (IllegalArgumentException e) {
            PierceDemoLogUtil.logE("ConstructorTest modify constructor arguments error", e);
            return FAILED;
        }
    }

    @Override
    public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
        super.beforeCall(callFrame);
        int originArg = (int) callFrame.args[0];
        if (originArg != 114514)
            callFrame.setThrowable(new IllegalArgumentException("parse arguments error (got "
                    + originArg + ")"));

        callFrame.args[0] = 1145141919;
    }

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        super.afterCall(callFrame);
        ((Target) callFrame.thisObject).success = true;
    }

    static class Target {
        boolean success;

        Target(int i) {
            PierceDemoLogUtil.logI("Target constructor called with i=" + i);
            if (i != 1145141919) {
                long tid = Thread.currentThread().getId();
                PierceDemoLogUtil.logE("ConstructorTest [Thread-" + tid + "] i mismatch, expected(i)=" + 1145141919 + ", actual(i)=" + i);
                throw new IllegalArgumentException("Bad i " + i);
            }
        }
    }
}
