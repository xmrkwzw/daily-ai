package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8484Test extends Test {
    public Arg8484Test() {
        super("target", long.class, int.class, long.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8484Test.testImpl() called");
        return target(0x1f2e3d4a5b6088L, 0xff709394, -5723572043847482345L, -1145141919);
    }

    private static int target(long l, int i, long l2, int i2) {
        PierceDemoLogUtil.logI("Arg8484Test.target() called with arg l " + l + ", i " + i + ", l2 " + l2 + ", i2 " + i2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != 0x1f2e3d4a5b6088L) {
            PierceDemoLogUtil.logE("Arg8484Test [Thread-" + tid + "] l mismatch, expected(l)=" + 0x1f2e3d4a5b6088L + ", actual(l)=" + l);
            ok = false;
        }
        if (i != 0xff709394) {
            PierceDemoLogUtil.logE("Arg8484Test [Thread-" + tid + "] i mismatch, expected(i)=" + 0xff709394 + ", actual(i)=" + i);
            ok = false;
        }
        if (l2 != -5723572043847482345L) {
            PierceDemoLogUtil.logE("Arg8484Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + -5723572043847482345L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (i2 != -1145141919) {
            PierceDemoLogUtil.logE("Arg8484Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -1145141919 + ", actual(i2)=" + i2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
