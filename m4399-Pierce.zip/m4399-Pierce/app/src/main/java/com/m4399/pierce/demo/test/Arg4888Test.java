package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4888Test extends Test {
    public Arg4888Test() {
        super("target", int.class, long.class, long.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4888Test.testImpl() called");
        return target(224466880, -5792515540449094060L, -1796423543890059176L, -4733209378700948853L);
    }

    private static int target(int i, long l, long l2, long l3) {
         PierceDemoLogUtil.logI("Arg4888Test.target() called with arg i " + i + ", l " + l + ", l2 " + l2 + ", l3 " + l3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 224466880) {
            PierceDemoLogUtil.logE("Arg4888Test [Thread-" + tid + "] i mismatch, expected(i)=" + 224466880 + ", actual(i)=" + i);
            ok = false;
        }
        if (l != -5792515540449094060L) {
            PierceDemoLogUtil.logE("Arg4888Test [Thread-" + tid + "] l mismatch, expected(l)=" + -5792515540449094060L + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != -1796423543890059176L) {
            PierceDemoLogUtil.logE("Arg4888Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + -1796423543890059176L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (l3 != -4733209378700948853L) {
            PierceDemoLogUtil.logE("Arg4888Test [Thread-" + tid + "] l3 mismatch, expected(l3)=" + -4733209378700948853L + ", actual(l3)=" + l3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
