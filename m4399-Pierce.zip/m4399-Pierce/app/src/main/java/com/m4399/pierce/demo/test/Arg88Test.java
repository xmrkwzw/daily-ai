package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg88Test extends Test {
    public Arg88Test() {
        super("target", long.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg88Test.testImpl() called");
        return target(Long.MAX_VALUE, 0xffffffffL);
    }

    private static int target(long l, long l2) {
        PierceDemoLogUtil.logI("Arg88Test.target() called with arg l " + l + ", l2 " + l2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != Long.MAX_VALUE) {
            PierceDemoLogUtil.logE("Arg88Test [Thread-" + tid + "] l mismatch, expected(l)=" + Long.MAX_VALUE + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != 0xffffffffL) {
            PierceDemoLogUtil.logE("Arg88Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 0xffffffffL + ", actual(l2)=" + l2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
