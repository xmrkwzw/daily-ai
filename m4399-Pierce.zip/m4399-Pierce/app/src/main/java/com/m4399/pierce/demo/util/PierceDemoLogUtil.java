package com.m4399.pierce.demo.util;

import android.util.Log;

public class PierceDemoLogUtil {
    private static final String TAG = "PierceDemo";

    public static void logI(String message) {
        Log.i(TAG, message);
        PierceDemoFileLogUtil.write("I", TAG, message, null);
    }

    public static void logI(String message, Throwable throwable) {
        Log.i(TAG, message, throwable);
        PierceDemoFileLogUtil.write("I", TAG, message, throwable);
    }

    public static void logI(String fmt, Object... args) {
        String msg = String.format(fmt, args);
        Log.i(TAG, msg);
        PierceDemoFileLogUtil.write("I", TAG, msg, null);
    }

    public static void logW(String message) {
        Log.e(TAG, message);
        PierceDemoFileLogUtil.write("W", TAG, message, null);
    }

    public static void logE(String message) {
        Log.e(TAG, message);
        PierceDemoFileLogUtil.write("E", TAG, message, null);
    }

    public static void logE(String message, Throwable throwable) {
        Log.e(TAG, message, throwable);
        PierceDemoFileLogUtil.write("E", TAG, message, throwable);
    }

}
