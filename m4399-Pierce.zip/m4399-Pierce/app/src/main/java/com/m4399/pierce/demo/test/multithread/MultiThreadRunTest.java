package com.m4399.pierce.demo.test.multithread;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.m4399.pierce.demo.MainActivity;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

import java.util.concurrent.Callable;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class MultiThreadRunTest {
    private static final LinkedBlockingQueue<MultiThreadTest> taskQueue =
            new LinkedBlockingQueue<>();

    private static AtomicBoolean isHook = new AtomicBoolean(false);

    public static void hook() {
        taskQueue.clear();
        //int count = 1000;
        int count = 500;

        boolean isNeedHook = false;
        if (isHook.compareAndSet(false, true)) {
            isNeedHook = true;
        }

        boolean isHasProxyHook = true;
        boolean isHasShortFuncHook = true;

        if ((Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP)
//                || (Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP_MR1)
                || (Build.VERSION.SDK_INT == Build.VERSION_CODES.M)
        ) {
            isHasProxyHook = false;
        }

//        if ((Build.VERSION.SDK_INT == Build.VERSION_CODES.N)
//                || (Build.VERSION.SDK_INT == Build.VERSION_CODES.N_MR1)) {
//            isHasShortFuncHook = false;
//        }

        if (isHasShortFuncHook) {
            if (isNeedHook) {
                MultiThreadArg0Test.hook();
            }

            for (int i = 0; i < count; i++) {
                MultiThreadTest multiThreadArg0Test = new MultiThreadArg0Test();
                taskQueue.add(multiThreadArg0Test);
            }
        }

        if (isNeedHook) {
            MultiThreadThrowExceptionTest.hook();
        }
        for (int i = 0; i < count; i++) {
            MultiThreadTest throwExTest = new MultiThreadThrowExceptionTest();
            taskQueue.add(throwExTest);
        }

        if (isHasProxyHook) {
            //压力测试下
            // android 5.0 会崩溃
            // android 6.0 Proxy HOOK 单线程下出现崩溃。
            // A Abort message: 'art/runtime/art_method.cc:489] Check failed: IsConstructor() '
            if (isNeedHook) {
                MultiThreadProxyTest.hook();
            }
            for (int i = 0; i < count; i++) {
                MultiThreadTest proxyTest = new MultiThreadProxyTest();
                taskQueue.add(proxyTest);
            }
        }


        if (isNeedHook) {
            MultiThreadDynamicLookupJNITest.hook();
        }
        for (int i = 0; i < count; i++) {
            MultiThreadTest dynamicLookupJNITest = new MultiThreadDynamicLookupJNITest();
            taskQueue.add(dynamicLookupJNITest);
        }

        if (isNeedHook) {
            MultiThreadDirectRegisterJNITest.hook();
        }
        for (int i = 0; i < count; i++) {
            MultiThreadTest directRegisterJNITest = new MultiThreadDirectRegisterJNITest();
            taskQueue.add(directRegisterJNITest);
        }

        if (isNeedHook) {
            MultiThreadArgLLLILLZZZIIILTest.hook();
        }
        for (int i = 0; i < count; i++) {
            MultiThreadTest argLLLILLZZZIIILTest = new MultiThreadArgLLLILLZZZIIILTest();
            taskQueue.add(argLLLILLZZZIIILTest);
        }

        if (isNeedHook) {
            MultiThreadArgMultiIntStaticTest.hook();
        }
        for (int i = 0; i < count; i++) {
            MultiThreadTest argMultiIntStaticTest = new MultiThreadArgMultiIntStaticTest();
            taskQueue.add(argMultiIntStaticTest);
        }

        if (isNeedHook) {
            MultiThreadArgMultiLongTest.hook();
        }
        for (int i = 0; i < count; i++) {
            MultiThreadTest argMultiLongTest = new MultiThreadArgMultiLongTest();
            taskQueue.add(argMultiLongTest);
        }

    }

    public static void threadRun() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                MultiThreadRunTest.run();
            }
        });
        thread.start();
    }

    public static void run() {
        long startTimeMillis = System.currentTimeMillis();

        final int threadCount = 20;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        final int taskCount = taskQueue.size();
        final CountDownLatch countDownLatch = new CountDownLatch(taskCount);

        final AtomicInteger totalTaskCount = new AtomicInteger();
        final AtomicInteger successTaskCount = new AtomicInteger();
        final AtomicInteger failedTaskCount = new AtomicInteger();
        final AtomicInteger ignoreTaskCount = new AtomicInteger();

        final AtomicBoolean stopFlag = new AtomicBoolean(false);
        //用于保证"兜底 drain"只执行一次
        final AtomicBoolean latchDrained = new AtomicBoolean(false);
        final AtomicInteger pollCount = new AtomicInteger(0);
        final AtomicInteger pollReturnIsNotNullCount = new AtomicInteger(0);
        final Handler handler = new Handler(Looper.getMainLooper());
        for (int i = 0; i < threadCount; i++) {
            executor.submit(new Callable<Integer>() {
                @Override
                public Integer call() {

                    //排死锁导致崩溃的问题用
                    final Thread thread = Thread.currentThread();
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            StringBuilder stringBuilder = new StringBuilder("pine test");
                            for (StackTraceElement traceElement : thread.getStackTrace()) {
                                stringBuilder.append(traceElement.toString()).append("\n");
                            }
                            PierceDemoLogUtil.logI(stringBuilder.toString());
                        }
                    };
                    //设置一个 60 秒后的堆栈打印任务
                    handler.postDelayed(runnable, 60000);

                    while (true) {
                        if (stopFlag.get()) break;

                        int ret = MultiThreadTest.IGNORED;

                        MultiThreadTest test = taskQueue.poll();

                        pollCount.incrementAndGet();
                        if (test == null) {
                            break;
                        }
                        pollReturnIsNotNullCount.incrementAndGet();

                        try {
                            ret = test.run();
                            if (ret != MultiThreadTest.SUCCESS) {
                                PierceDemoLogUtil.logE("[Thread-" + Thread.currentThread().getId() + "] test failed: " + test.getClass().getSimpleName() + " failedTaskCount=" + failedTaskCount.get());
                                stopFlag.set(true);
                                //失败时触发兜底 drain
                                drainRemainingTasksIfNeeded(
                                        countDownLatch,
                                        latchDrained
                                );
                            } else {
                                PierceDemoLogUtil.logI("[Thread-" + Thread.currentThread().getId() + "_" + Thread.currentThread() + "] test succeeded: " + test.getClass().getSimpleName() + " successTaskCount=" + successTaskCount.get());
                            }
                        } catch (Throwable t) {
                            stopFlag.set(true);
                            //失败时触发兜底 drain
                            drainRemainingTasksIfNeeded(
                                    countDownLatch,
                                    latchDrained
                            );
                            ret = MultiThreadTest.FAILED;
                            PierceDemoLogUtil.logE("MultiThreadRunTest [Thread-" + Thread.currentThread().getId() + "] test exception: " + test.getClass().getSimpleName() + " failedTaskCount=" + failedTaskCount.get() + " t=" + t, t);
                        } finally {
                            countDownLatch.countDown();
                        }

                        totalTaskCount.incrementAndGet();
                        if (ret == MultiThreadTest.SUCCESS) {
                            successTaskCount.incrementAndGet();
                        } else if (ret == MultiThreadTest.IGNORED) {
                            ignoreTaskCount.incrementAndGet();
                        } else {
                            failedTaskCount.incrementAndGet();
                        }
                    }

                    PierceDemoLogUtil.logI("[Thread-" + Thread.currentThread().getId() + "] handler removeCallbacks"
                            + " countDownLatch.getCount()=" + countDownLatch.getCount()
                            + " pollCount=" + pollCount.get()
                            + " pollReturnIsNotNullCount=" + pollReturnIsNotNullCount.get()
                            + " stopFlag=" + stopFlag.get()
                            + " latchDrained=" + latchDrained.get()
                            + " taskQueue.size()=" + taskQueue.size());
                    handler.removeCallbacks(runnable);
                    return 0;
                }
            });
        }

        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        //立即中断所有线程
        executor.shutdownNow();
        try {
            if (!executor.awaitTermination(1, TimeUnit.MINUTES)) {
                PierceDemoLogUtil.logW("[Thread-" + Thread.currentThread().getId() + "] Warning: executor did not terminate in time.");
            }
        } catch (InterruptedException e) {
            PierceDemoLogUtil.logE("[Thread-" + Thread.currentThread().getId() + "] Interrupted while waiting for executor shutdown.");
        }

        long durationMs = System.currentTimeMillis() - startTimeMillis;
        PierceDemoLogUtil.logI("[Thread-" + Thread.currentThread().getId() + "] All tests finished "
                + " totalTaskCount=" + totalTaskCount.get()
                + " successTaskCount=" + successTaskCount.get()
                + " failedTaskCount=" + failedTaskCount.get()
                + " ignoreTaskCount=" + ignoreTaskCount.get()
                + " stopFlag=" + stopFlag.get()
                + " durationMs=" + durationMs
                + " jsonObjectPutCallCount=" + MainActivity.Companion.getJsonObjectPutCallCount());

        if (failedTaskCount.get() > 0) {
            throw new RuntimeException("[Thread-" + Thread.currentThread().getId() + "] All tests finished "
                    + " totalTaskCount=" + totalTaskCount.get()
                    + " successTaskCount=" + successTaskCount.get()
                    + " failedTaskCount=" + failedTaskCount.get()
                    + " ignoreTaskCount=" + ignoreTaskCount.get()
                    + " stopFlag=" + stopFlag.get()
                    + " durationMs=" + durationMs
                    + " jsonObjectPutCallCount=" + MainActivity.Companion.getJsonObjectPutCallCount());
        }

    }

    private static void drainRemainingTasksIfNeeded(
            CountDownLatch latch,
            AtomicBoolean latchDrained) {

        // 只允许一个线程执行
        if (!latchDrained.compareAndSet(false, true)) {
            return;
        }

        int remaining = 0;
        while (taskQueue.poll() != null) {
            remaining++;
        }

        for (int i = 0; i < remaining; i++) {
            latch.countDown();
        }

        PierceDemoLogUtil.logE("drainRemainingTasksIfNeeded countDown=" + remaining);
    }
}
