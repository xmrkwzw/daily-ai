package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg844Test extends Test {
    public Arg844Test() {
        super("target", long.class, int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg844Test.testImpl() called");
        return target(92233223322332233L, 1, -1);
    }

    private static int target(long l, int i, int i2) {
        PierceDemoLogUtil.logI("Arg844Test.target() called with arg l " + l + ", i " + i + ", i2 " + i2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != 92233223322332233L) {
            PierceDemoLogUtil.logE("Arg844Test [Thread-" + tid + "] l mismatch, expected(l)=" + 92233223322332233L + ", actual(l)=" + l);
            ok = false;
        }
        if (i != 1) {
            PierceDemoLogUtil.logE("Arg844Test [Thread-" + tid + "] i mismatch, expected(i)=" + 1 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != -1) {
            PierceDemoLogUtil.logE("Arg844Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -1 + ", actual(i2)=" + i2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
