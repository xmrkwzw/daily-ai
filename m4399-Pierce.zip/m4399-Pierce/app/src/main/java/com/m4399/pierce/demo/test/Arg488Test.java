package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg488Test extends Test {
    public Arg488Test() {
        super("target", int.class, long.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg488Test.testImpl() called");
        return target(1582270018, 8888888888888888888L, 0x1234567890abcdefL);
    }

    private static int target(int i, long l, long l2) {
        PierceDemoLogUtil.logI("Arg488Test.target() called with arg i " + i + ", l " + l + ", l2 " + l2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 1582270018) {
            PierceDemoLogUtil.logE("Arg488Test [Thread-" + tid + "] i mismatch, expected(i)=" + 1582270018 + ", actual(i)=" + i);
            ok = false;
        }
        if (l != 8888888888888888888L) {
            PierceDemoLogUtil.logE("Arg488Test [Thread-" + tid + "] l mismatch, expected(l)=" + 8888888888888888888L + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != 0x1234567890abcdefL) {
            PierceDemoLogUtil.logE("Arg488Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 0x1234567890abcdefL + ", actual(l2)=" + l2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
