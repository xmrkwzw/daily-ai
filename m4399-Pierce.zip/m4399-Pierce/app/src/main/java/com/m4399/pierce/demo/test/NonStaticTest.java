package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class NonStaticTest extends Test {
    public NonStaticTest() {
        super("target", (Class<?>[]) null);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("NonStaticTest.testImpl() called");
        boolean targetRet = target();
        int ret = SUCCESS;
        if (!targetRet) {
            long tid = Thread.currentThread().getId();
            PierceDemoLogUtil.logE("NonStaticTest [Thread-" + tid + "] targetRet mismatch, expected(targetRet)=" + true + ", actual(targetRet)=" + targetRet);
            ret = FAILED;
        }
        return ret;
    }

    public boolean target() {
        PierceDemoLogUtil.logI("NonStaticTest.target() called");
        return false;
    }

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        super.afterCall(callFrame);
        callFrame.setResultIfNoException(true);
    }
}
