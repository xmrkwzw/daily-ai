package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg448Test extends Test {
    public Arg448Test() {
        super("target", int.class, int.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg448Test.testImpl() called");
        return target(-289586806, -176218551, 1582270018L);
    }

    private static int target(int i, int i2, long l) {
        PierceDemoLogUtil.logI("Arg448Test.target() called with arg i " + i + ", i2 " + i2 + ", l " + l);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != -289586806) {
            PierceDemoLogUtil.logE("Arg448Test [Thread-" + tid + "] i mismatch, expected(i)=" + -289586806 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != -176218551) {
            PierceDemoLogUtil.logE("Arg448Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -176218551 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (l != 1582270018L) {
            PierceDemoLogUtil.logE("Arg448Test [Thread-" + tid + "] l mismatch, expected(l)=" + 1582270018L + ", actual(l)=" + l);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
