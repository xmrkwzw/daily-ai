package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class NotInitedTest extends Test {
    public NotInitedTest() {
        super(I.class, "target", int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("NotInitedTest.testImpl() called");
        int ret = I.target(114514);
        return ret;
    }

    @Override
    public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
        super.beforeCall(callFrame);
        callFrame.args[0] = 1919810;
    }

    private static class I {
        static {
            //at com.m4399.pierce.demo.test.NotInitedTest$I.<clinit>(NotInitedTest.java:27)
            //at java.lang.reflect.Method.invoke(Native Method)
            //at com.m4399.pierce.core.Pierce.resolve(Pierce.java:560)
            //at com.m4399.pierce.core.Pierce.hookNewMethod(Pierce.java:401)
            PierceDemoLogUtil.logI("NotInitedTest initializing,you should see a throwable stack info", new Throwable());
        }

        static int target(int i) {
            PierceDemoLogUtil.logI("NotInitedTest.target() called with arg i " + i);
            boolean ok = true;
            long tid = Thread.currentThread().getId();

            if (i != 1919810) {
                PierceDemoLogUtil.logE("NotInitedTest.target() [Thread-" + tid + "] i mismatch, expected(i)=" + 1919810 + ", actual(i)=" + i);
                ok = false;
            }
            return ok ? SUCCESS : FAILED;
        }
    }
}
