package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

import java.util.Random;

/**
 * @author canyie
 */
public class DynamicLookupJNITest extends Test {
    public DynamicLookupJNITest() {
        super("target", int.class);
    }

    static {
        System.loadLibrary("test1");
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("DynamicLookupJNITest.testImpl() called");
        int i = new Random().nextInt(100);
        int targetRet = target(i);
        int ret = SUCCESS;
        if (targetRet != 100000) {
            long tid = Thread.currentThread().getId();
            PierceDemoLogUtil.logE("DynamicLookupJNITest [Thread-" + tid + "] targetRet mismatch, expected(targetRet)=" + 100000 + ", actual(targetRet)=" + targetRet + " i=" + i);
            ret = FAILED;
        }
        return ret;
    }

    private static native int target(int i);

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        super.afterCall(callFrame);
        callFrame.setResult(100000);
    }
}
