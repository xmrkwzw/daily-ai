package com.m4399.pierce.demo.test.multithread;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

import java.util.Random;

/**
 * @author canyie
 */
public class MultiThreadDirectRegisterJNITest extends MultiThreadTest {
    public MultiThreadDirectRegisterJNITest() {

    }

    public static void hook() {
        hook(new MultiThreadDirectRegisterJNITestMethodHook(), MultiThreadDirectRegisterJNITest.class, "target", int.class);
    }

    static {
        System.loadLibrary("test1");
    }

    @Override
    protected int testImpl() {
        int arg = new Random().nextInt(100);
        int callTargetRet = callTarget(arg);
        int ret = SUCCESS;
        if (callTargetRet != 100000) {
            long tid = Thread.currentThread().getId();
            PierceDemoLogUtil.logE("MultiThreadDirectRegisterJNITest.testImpl() [Thread-" + tid + "] callTargetRet mismatch, expected(callTargetRet)=" + 100000 + ", actual(callTargetRet)=" + callTargetRet + " arg=" + arg);
            ret = FAILED;
        }
        return ret;
    }

    private static int callTarget(int arg) {
        calleeFunctionEnterCountAdd();
        int ret = target(arg);
        return ret;
    }

    private static native int target(int arg);

    static class MultiThreadDirectRegisterJNITestMethodHook extends DefaultMethodHook {
        @Override
        public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
            super.afterCall(callFrame);
            callFrame.setResult(100000);
        }
    }
}
