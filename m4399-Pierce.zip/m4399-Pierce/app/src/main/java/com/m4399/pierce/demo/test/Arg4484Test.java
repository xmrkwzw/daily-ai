package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4484Test extends Test {
    public Arg4484Test() {
        super("target", int.class, int.class, long.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4484Test.testImpl() called");
        return target(-80901020, 726338399, 5141237374391886252L, 884484444);
    }

    private static int target(int i, int i2, long l, int i3) {
        PierceDemoLogUtil.logI("Arg4484Test.target() called with arg i " + i + ", i2 " + i2 + ", l " + l + ", i3 " + i3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != -80901020) {
            PierceDemoLogUtil.logE("Arg4484Test [Thread-" + tid + "] i mismatch, expected(i)=" + -80901020 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != 726338399) {
            PierceDemoLogUtil.logE("Arg4484Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + 726338399 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (l != 5141237374391886252L) {
            PierceDemoLogUtil.logE("Arg4484Test [Thread-" + tid + "] l mismatch, expected(l)=" + 5141237374391886252L + ", actual(l)=" + l);
            ok = false;
        }
        if (i3 != 884484444) {
            PierceDemoLogUtil.logE("Arg4484Test [Thread-" + tid + "] i3 mismatch, expected(i3)=" + 884484444 + ", actual(i3)=" + i3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
