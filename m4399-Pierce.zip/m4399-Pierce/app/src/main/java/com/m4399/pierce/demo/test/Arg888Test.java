package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg888Test extends Test {
    public Arg888Test() {
        super("target", long.class, long.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg888Test.testImpl() called");
        return target(Long.MAX_VALUE, 0xffffffffL, Long.MIN_VALUE);
    }

    private static int target(long l, long l2, long l3) {
        PierceDemoLogUtil.logI("Arg888Test.target() called with arg l " + l + ", l2 " + l2 + ", l3 " + l3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != Long.MAX_VALUE) {
            PierceDemoLogUtil.logE("Arg888Test [Thread-" + tid + "] l mismatch, expected(l)=" + Long.MAX_VALUE + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != 0xffffffffL) {
            PierceDemoLogUtil.logE("Arg888Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 0xffffffffL + ", actual(l2)=" + l2);
            ok = false;
        }
        if (l3 != Long.MIN_VALUE) {
            PierceDemoLogUtil.logE("Arg888Test [Thread-" + tid + "] l3 mismatch, expected(l3)=" + Long.MIN_VALUE + ", actual(l3)=" + l3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
