package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class HookPrimitiveTest extends Test {
    public HookPrimitiveTest() {
        super("target", int.class); // 指定目标方法的参数类型
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("HookPrimitiveTest.testImpl() called");

        int ret = target(1145141919);
        return ret;
    }

    @Override
    public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
        super.beforeCall(callFrame);
        callFrame.args[0] = (int) callFrame.args[0] == 1145141919 ? 1919114514 : 0;
    }

    private static int target(int i) {
        PierceDemoLogUtil.logI("HookPrimitiveTest.target() called with arg i " + i);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 1919114514) {
            PierceDemoLogUtil.logE("HookPrimitiveTest [Thread-" + tid + "] i mismatch, expected(i)=" + 1919114514 + ", actual(i)=" + i);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }
}