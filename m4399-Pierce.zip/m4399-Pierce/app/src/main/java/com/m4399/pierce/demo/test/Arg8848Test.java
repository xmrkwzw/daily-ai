package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8848Test extends Test {
    public Arg8848Test() {
        super("target", long.class, long.class, int.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8848Test.testImpl() called");
        return target(8084514565968846528L, 6952285581784261717L, -2139865587, -3241569179806591056L);
    }

    private static int target(long l, long l2, int i, long l3) {
        PierceDemoLogUtil.logI("Arg8848Test.target() called with arg l " + l + ", l2 " + l2 + ", i " + i + ", l3 " + l3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != 8084514565968846528L) {
            PierceDemoLogUtil.logE("Arg8848Test [Thread-" + tid + "] l mismatch, expected(l)=" + 8084514565968846528L + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != 6952285581784261717L) {
            PierceDemoLogUtil.logE("Arg8848Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 6952285581784261717L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (i != -2139865587) {
            PierceDemoLogUtil.logE("Arg8848Test [Thread-" + tid + "] i mismatch, expected(i)=" + -2139865587 + ", actual(i)=" + i);
            ok = false;
        }
        if (l3 != -3241569179806591056L) {
            PierceDemoLogUtil.logE("Arg8848Test [Thread-" + tid + "] l3 mismatch, expected(l3)=" + -3241569179806591056L + ", actual(l3)=" + l3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
