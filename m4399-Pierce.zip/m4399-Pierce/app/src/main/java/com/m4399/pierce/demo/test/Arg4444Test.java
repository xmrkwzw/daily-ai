package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4444Test extends Test {
    public Arg4444Test() {
        super("target", int.class, int.class, int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4444Test.testImpl() called");
        return target(Integer.MIN_VALUE, 379978698, Integer.MAX_VALUE, -489408322);
    }

    private static int target(int i, int i2, int i3, int i4) {
        PierceDemoLogUtil.logI("Arg4444Test.target() called with arg i " + i + ", i2 " + i2 + ", i3 " + i3 + ", i4 " + i4);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != Integer.MIN_VALUE) {
            PierceDemoLogUtil.logE("Arg4444Test [Thread-" + tid + "] i mismatch, expected(i)=" + Integer.MIN_VALUE + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != 379978698) {
            PierceDemoLogUtil.logE("Arg4444Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + 379978698 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (i3 != Integer.MAX_VALUE) {
            PierceDemoLogUtil.logE("Arg4444Test [Thread-" + tid + "] i3 mismatch, expected(i3)=" + Integer.MAX_VALUE + ", actual(i3)=" + i3);
            ok = false;
        }
        if (i4 != -489408322) {
            PierceDemoLogUtil.logE("Arg4444Test [Thread-" + tid + "] i4 mismatch, expected(i4)=" + -489408322 + ", actual(i4)=" + i4);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
