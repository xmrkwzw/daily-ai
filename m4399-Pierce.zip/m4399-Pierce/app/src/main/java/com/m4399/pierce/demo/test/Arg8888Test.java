package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8888Test extends Test {
    public Arg8888Test() {
        super("target", long.class, long.class, long.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8888Test.testImpl() called");
        return target(6477721089490648113L, -1L, 6477721089490648113L, 5370953174012904355L);
    }

    private static int target(long l, long l2, long l3, long l4) {
        PierceDemoLogUtil.logI("Arg8888Test.target() called with arg l " + l + ", l2 " + l2 + ", l3 " + l3 + ", l4 " + l4);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != 6477721089490648113L) {
            PierceDemoLogUtil.logE("Arg8888Test [Thread-" + tid + "] l mismatch, expected(l)=" + 6477721089490648113L + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != -1L) {
            PierceDemoLogUtil.logE("Arg8888Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + -1L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (l3 != 6477721089490648113L) {
            PierceDemoLogUtil.logE("Arg8888Test [Thread-" + tid + "] l3 mismatch, expected(l3)=" + 6477721089490648113L + ", actual(l3)=" + l3);
            ok = false;
        }
        if (l4 != 5370953174012904355L) {
            PierceDemoLogUtil.logE("Arg8888Test [Thread-" + tid + "] l4 mismatch, expected(l4)=" + 5370953174012904355L + ", actual(l4)=" + l4);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
