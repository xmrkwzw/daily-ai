package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg0Test extends Test {
    public Arg0Test() {
        super("target", (Class<?>[]) null);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg0Test.testImpl() called");
        return target();
    }

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        super.afterCall(callFrame);
        callFrame.setResultIfNoException(SUCCESS);
    }

    private static int target() {
        PierceDemoLogUtil.logI("Arg0Test.target() called");
        int ret = FAILED;
        return ret;
    }
}
