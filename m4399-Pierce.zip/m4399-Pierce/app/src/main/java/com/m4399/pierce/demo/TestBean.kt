package com.m4399.pierce.demo

import com.m4399.pierce.demo.util.PierceDemoLogUtil

class TestBean {
    fun testString(): String {
        var ret = ""
        PierceDemoLogUtil.logI("TestBean testString: ret=$ret")
        return ret
    }

//    fun testBoolean():Boolean{
//        return false
//    }

    fun testBoolean(): Boolean {
        var ret = false
        PierceDemoLogUtil.logI("TestBean testBoolean: ret=$ret")
        return ret
    }

//    fun testChar(): Char {
//        return '0'
//    }

    fun testChar(): Char {
        var ret = '0'
        PierceDemoLogUtil.logI("TestBean testChar: ret=$ret")
        return ret
    }

//    fun testByte(): Byte {
//        return 0
//    }

    fun testByte(): Byte {
        var ret = 0.toByte()
        PierceDemoLogUtil.logI("TestBean testByte: ret=$ret")
        return ret
    }

//    fun testShort(): Short {
//        return 0
//    }

    fun testShort(): Short {
        var ret = 0.toShort()
        PierceDemoLogUtil.logI("TestBean testShort: ret=$ret")
        return ret
    }

//    fun testInt(): Int {
//        return 0
//    }

    fun testInt(): Int {
        var ret = 0
        PierceDemoLogUtil.logI("TestBean testInt: ret=$ret")
        return ret
    }

//    fun testFloat(): Float {
//        return 0.0f
//    }

    fun testFloat(): Float {
        var ret = 0.0f
        PierceDemoLogUtil.logI("TestBean testFloat: ret=$ret")
        return ret
    }

    fun testLong(): Long {
        var ret = 0L
        PierceDemoLogUtil.logI("TestBean testLong: ret=$ret")
        return ret
    }

    fun testDouble(): Double {
        var ret = 0.0
        PierceDemoLogUtil.logI("TestBean testDouble: ret=$ret")
        return ret
    }

    private fun privateInt(): Int {
        return 0
    }

    fun testPrivateInt(): Int {
        var ret = privateInt()
        PierceDemoLogUtil.logI("TestBean testPrivateInt: ret=$ret")
        return ret
    }

}