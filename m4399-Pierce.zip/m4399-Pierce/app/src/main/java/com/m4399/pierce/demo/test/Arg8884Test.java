package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8884Test extends Test {
    public Arg8884Test() {
        super("target", long.class, long.class, long.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8884Test.testImpl() called");
        return target(-6867511285804313987L, 4389430003392177491L, 8355994034371160043L, -853510870);
    }

    private static int target(long l, long l2, long l3, int i) {
        PierceDemoLogUtil.logI("Arg8884Test.target() called with arg l " + l + ", l2 " + l2 + ", l3 " + l3 + ", i " + i);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != -6867511285804313987L) {
            PierceDemoLogUtil.logE("Arg8884Test [Thread-" + tid + "] l mismatch, expected(l)=" + -6867511285804313987L + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != 4389430003392177491L) {
            PierceDemoLogUtil.logE("Arg8884Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 4389430003392177491L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (l3 != 8355994034371160043L) {
            PierceDemoLogUtil.logE("Arg8884Test [Thread-" + tid + "] l3 mismatch, expected(l3)=" + 8355994034371160043L + ", actual(l3)=" + l3);
            ok = false;
        }
        if (i != -853510870) {
            PierceDemoLogUtil.logE("Arg8884Test [Thread-" + tid + "] i mismatch, expected(i)=" + -853510870 + ", actual(i)=" + i);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
