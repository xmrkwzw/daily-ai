package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg44Test extends Test {
    public Arg44Test() {
        super("target", int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg44Test.testImpl() called");
        return target(326646792, -790347563);
    }

    private static int target(int i, int i2) {
        PierceDemoLogUtil.logI("Arg44Test.target() called with arg i " + i + ", i2 " + i2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 326646792) {
            PierceDemoLogUtil.logE("Arg44Test [Thread-" + tid + "] i mismatch, expected(i)=" + 326646792 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != -790347563) {
            PierceDemoLogUtil.logE("Arg44Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -790347563 + ", actual(i2)=" + i2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
