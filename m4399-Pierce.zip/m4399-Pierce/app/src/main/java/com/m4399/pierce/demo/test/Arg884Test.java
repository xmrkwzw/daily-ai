package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg884Test extends Test {
    public Arg884Test() {
        super("target", long.class, long.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg884Test.testImpl() called");
        return target(801702476100628398L, 74916439469399L, 0xfee1dead);
    }

    private static int target(long l1, long l2, int i) {
        PierceDemoLogUtil.logI("Arg884Test.target() called with arg l1 " + l1 + ", l2 " + l2 + ", i " + i);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l1 != 801702476100628398L) {
            PierceDemoLogUtil.logE("Arg884Test [Thread-" + tid + "] l1 mismatch, expected(l1)=" + 801702476100628398L + ", actual(l1)=" + l1);
            ok = false;
        }
        if (l2 != 74916439469399L) {
            PierceDemoLogUtil.logE("Arg884Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 74916439469399L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (i != 0xfee1dead) {
            PierceDemoLogUtil.logE("Arg884Test [Thread-" + tid + "] i mismatch, expected(i)=" + 0xfee1dead + ", actual(i)=" + i);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
