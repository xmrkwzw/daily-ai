package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg444Test extends Test {
    public Arg444Test() {
        super("target", int.class, int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg444Test.testImpl() called");
        return target(-289586806, -176218551, 379978698);
    }

    private static int target(int i, int i2, int i3) {
        PierceDemoLogUtil.logI("Arg444Test.target() called with arg i " + i + ", i2 " + i2 + ", i3 " + i3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != -289586806) {
            PierceDemoLogUtil.logE("Arg444Test [Thread-" + tid + "] i mismatch, expected(i)=" + -289586806 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != -176218551) {
            PierceDemoLogUtil.logE("Arg444Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -176218551 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (i3 != 379978698) {
            PierceDemoLogUtil.logE("Arg444Test [Thread-" + tid + "] i3 mismatch, expected(i3)=" + 379978698 + ", actual(i3)=" + i3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
