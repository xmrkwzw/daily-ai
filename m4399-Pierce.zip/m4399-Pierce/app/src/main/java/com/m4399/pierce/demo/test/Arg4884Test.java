package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4884Test extends Test {
    public Arg4884Test() {
        super("target", int.class, long.class, long.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4884Test.testImpl() called");
        return target(998125748, 7770769711165259810L, 8886104551363442247L, 233345666);
    }

    private static int target(int i, long l, long l2, int i2) {
         PierceDemoLogUtil.logI("Arg4884Test.target() called with arg i " + i + ", l " + l + ", l2 " + l2 + ", i2 " + i2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 998125748) {
            PierceDemoLogUtil.logE("Arg4884Test [Thread-" + tid + "] i mismatch, expected(i)=" + 998125748 + ", actual(i)=" + i);
            ok = false;
        }
        if (l != 7770769711165259810L) {
            PierceDemoLogUtil.logE("Arg4884Test [Thread-" + tid + "] l mismatch, expected(l)=" + 7770769711165259810L + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != 8886104551363442247L) {
            PierceDemoLogUtil.logE("Arg4884Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 8886104551363442247L + ", actual(l2)=" + l2);
            ok = false;
        }
        if (i2 != 233345666) {
            PierceDemoLogUtil.logE("Arg4884Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + 233345666 + ", actual(i2)=" + i2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
