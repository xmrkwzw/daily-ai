package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4448Test extends Test {
    public Arg4448Test() {
        super("target", int.class, int.class, int.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4448Test.testImpl() called");
        return target(1, 685597707, 414481781, -9179983674551041920L);
    }

    private static int target(int i, int i2, int i3, long l) {
        PierceDemoLogUtil.logI("Arg4448Test.target() called with arg i " + i + ", i2 " + i2 + ", i3 " + i3 + ", l " + l);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 1) {
            PierceDemoLogUtil.logE("Arg4448Test [Thread-" + tid + "] i mismatch, expected(i)=" + 1 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != 685597707) {
            PierceDemoLogUtil.logE("Arg4448Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + 685597707 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (i3 != 414481781) {
            PierceDemoLogUtil.logE("Arg4448Test [Thread-" + tid + "] i3 mismatch, expected(i3)=" + 414481781 + ", actual(i3)=" + i3);
            ok = false;
        }
        if (l != -9179983674551041920L) {
            PierceDemoLogUtil.logE("Arg4448Test [Thread-" + tid + "] l mismatch, expected(l)=" + -9179983674551041920L + ", actual(l)=" + l);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
