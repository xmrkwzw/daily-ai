package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4488Test extends Test {
    public Arg4488Test() {
        super("target", int.class, int.class, long.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4488Test.testImpl() called");
        return target(1582270018, -981197949, -6831695582081439071L, -2631279363657431691L);
    }

    private static int target(int i, int i2, long l, long l2) {
        PierceDemoLogUtil.logI("Arg4488Test.target() called with arg i " + i + ", i2 " + i2 + ", l " + l + ", l2 " + l2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 1582270018) {
            PierceDemoLogUtil.logE("Arg4488Test [Thread-" + tid + "] i mismatch, expected(i)=" + 1582270018 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != -981197949) {
            PierceDemoLogUtil.logE("Arg4488Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -981197949 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (l != -6831695582081439071L) {
            PierceDemoLogUtil.logE("Arg4488Test [Thread-" + tid + "] l mismatch, expected(l)=" + -6831695582081439071L + ", actual(l)=" + l);
            ok = false;
        }
        if (l2 != -2631279363657431691L) {
            PierceDemoLogUtil.logE("Arg4488Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + -2631279363657431691L + ", actual(l2)=" + l2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
