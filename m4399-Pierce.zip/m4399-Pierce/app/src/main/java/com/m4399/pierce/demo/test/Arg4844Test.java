package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4844Test extends Test {
    public Arg4844Test() {
        super("target", int.class, long.class, int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4844Test.testImpl() called");
        return target(703329779, -8229704164037894322L, -301838892, 448077914);
    }

    private static int target(int i, long l, int i2, int i3) {
        PierceDemoLogUtil.logI("Arg4844Test.target() called with arg i " + i + ", l " + l + ", i2 " + i2 + ", i3 " + i3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 703329779) {
            PierceDemoLogUtil.logE("Arg4844Test [Thread-" + tid + "] i mismatch, expected(i)=" + 703329779 + ", actual(i)=" + i);
            ok = false;
        }
        if (l != -8229704164037894322L) {
            PierceDemoLogUtil.logE("Arg4844Test [Thread-" + tid + "] l mismatch, expected(l)=" + -8229704164037894322L + ", actual(l)=" + l);
            ok = false;
        }
        if (i2 != -301838892) {
            PierceDemoLogUtil.logE("Arg4844Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -301838892 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (i3 != 448077914) {
            PierceDemoLogUtil.logE("Arg4844Test [Thread-" + tid + "] i3 mismatch, expected(i3)=" + 448077914 + ", actual(i3)=" + i3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
