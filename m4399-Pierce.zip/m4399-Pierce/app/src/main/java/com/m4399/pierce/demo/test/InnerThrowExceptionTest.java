package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class InnerThrowExceptionTest extends Test {
    public InnerThrowExceptionTest() {
        super("target", (Class<?>[]) null);
    }

    @Override
    protected int testImpl() {
        try {
            target();
            return FAILED;
        } catch (MyEx e) {
            int ret = e.b ? SUCCESS : FAILED;
            if (ret == SUCCESS) {
                PierceDemoLogUtil.logI("InnerThrowExceptionTest testImpl catch e=" + e + " e.b=" + e.b, e);
            } else {
                PierceDemoLogUtil.logE("InnerThrowExceptionTest testImpl catch e=" + e + " e.b=" + e.b, e);
            }
            return ret;
        }
    }

    private static void target() throws MyEx {
        int a = 1;
        innerTarget(1);
    }

    private static void innerTarget(int a) throws MyEx {
        a = a + 1;
        moreInnerTarget(a);
    }

    private static void moreInnerTarget(int a) throws MyEx {
        a = a + 2;
        throw new MyEx();
    }

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        super.afterCall(callFrame);
        MyEx e = (MyEx) callFrame.getThrowable();
        e.b = true;
    }

    static class MyEx extends Exception {
        boolean b = false;
    }
}
