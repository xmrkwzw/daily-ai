package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg84Test extends Test {
    public Arg84Test() {
        super("target", long.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg84Test.testImpl() called");
        return target(5150256501661869116L, 326646792);
    }

    private static int target(long l, int i) {
        PierceDemoLogUtil.logI("Arg84Test.target() called with arg l " + l + ", i " + i);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != 5150256501661869116L) {
            PierceDemoLogUtil.logE("Arg84Test [Thread-" + tid + "] l mismatch, expected(l)=" + 5150256501661869116L + ", actual(l)=" + l);
            ok = false;
        }
        if (i != 326646792) {
            PierceDemoLogUtil.logE("Arg84Test [Thread-" + tid + "] i mismatch, expected(i)=" + 326646792 + ", actual(i)=" + i);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
