package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg848Test extends Test {
    public Arg848Test() {
        super("target", long.class, int.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg848Test.testImpl() called");
        return target(7273979761264812568L, 949888394, 0xed709394aac7cebfL);
    }

    private static int target(long l1, int i, long l2) {
        PierceDemoLogUtil.logI("Arg848Test.target() called with arg l1 " + l1 + ", i " + i + ", l2 " + l2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l1 != 7273979761264812568L) {
            PierceDemoLogUtil.logE("Arg848Test [Thread-" + tid + "] l1 mismatch, expected(l1)=" + 7273979761264812568L + ", actual(l1)=" + l1);
            ok = false;
        }
        if (i != 949888394) {
            PierceDemoLogUtil.logE("Arg848Test [Thread-" + tid + "] i mismatch, expected(i)=" + 949888394 + ", actual(i)=" + i);
            ok = false;
        }
        if (l2 != 0xed709394aac7cebfL) {
            PierceDemoLogUtil.logE("Arg848Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + 0xed709394aac7cebfL + ", actual(l2)=" + l2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
