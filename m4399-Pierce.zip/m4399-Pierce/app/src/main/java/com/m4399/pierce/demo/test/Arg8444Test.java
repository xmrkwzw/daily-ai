package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8444Test extends Test {
    public Arg8444Test() {
        super("target", long.class, int.class, int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8444Test.testImpl() called");
        return target(-1173143541535159835L, 303764431, -779044230, 109886902);
    }

    private static int target(long l, int i, int i2, int i3) {
        PierceDemoLogUtil.logI("Arg8444Test.target() called with arg l " + l + ", i " + i + ", i2 " + i2 + ", i3 " + i3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != -1173143541535159835L) {
            PierceDemoLogUtil.logE("Arg8444Test [Thread-" + tid + "] l mismatch, expected(l)=" + -1173143541535159835L + ", actual(l)=" + l);
            ok = false;
        }
        if (i != 303764431) {
            PierceDemoLogUtil.logE("Arg8444Test [Thread-" + tid + "] i mismatch, expected(i)=" + 303764431 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != -779044230) {
            PierceDemoLogUtil.logE("Arg8444Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -779044230 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (i3 != 109886902) {
            PierceDemoLogUtil.logE("Arg8444Test [Thread-" + tid + "] i3 mismatch, expected(i3)=" + 109886902 + ", actual(i3)=" + i3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
