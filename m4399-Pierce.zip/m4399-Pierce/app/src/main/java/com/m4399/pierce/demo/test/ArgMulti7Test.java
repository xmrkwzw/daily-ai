package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class ArgMulti7Test extends Test {
    private int rawI1 = 1, rawI2 = 2, rawI3 = 3, rawI4 = 4,
            rawI5 = 5, rawI6 = 6, rawI7 = 7;

    public ArgMulti7Test() {
        super("target", int.class, int.class, int.class, int.class,
                int.class, int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("ArgMulti7Test.testImpl() called");

        int i1 = 1;
        int i2 = 2;
        int i3 = 3;
        int i4 = 4;
        int i5 = 5;
        int i6 = 6;
        int i7 = 7;
        return target(i1, i2, i3, i4, i5, i6, i7);
    }

    private int target(int i1, int i2, int i3, int i4, int i5, int i6, int i7) {
        PierceDemoLogUtil.logI("ArgMulti7Test.target() called with arg i1 " + i1 + ", i2 " + i2 + ", i3 " + i3 + ", i4 " + i4 + ", i5 " + i5 + ", i6 " + i6 + ", i7 " + i7);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i1 != rawI1) {
            PierceDemoLogUtil.logE("ArgMulti7Test [Thread-" + tid + "] i1 mismatch, expected(i1)=" + rawI1 + ", actual(i1)=" + i1);
            ok = false;
        }
        if (i2 != rawI2) {
            PierceDemoLogUtil.logE("ArgMulti7Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + rawI2 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (i3 != rawI3) {
            PierceDemoLogUtil.logE("ArgMulti7Test [Thread-" + tid + "] i3 mismatch, expected(i3)=" + rawI3 + ", actual(i3)=" + i3);
            ok = false;
        }
        if (i4 != rawI4) {
            PierceDemoLogUtil.logE("ArgMulti7Test [Thread-" + tid + "] i4 mismatch, expected(i4)=" + rawI4 + ", actual(i4)=" + i4);
            ok = false;
        }
        if (i5 != rawI5) {
            PierceDemoLogUtil.logE("ArgMulti7Test [Thread-" + tid + "] i5 mismatch, expected(i5)=" + rawI5 + ", actual(i5)=" + i5);
            ok = false;
        }
        if (i6 != rawI6) {
            PierceDemoLogUtil.logE("ArgMulti7Test [Thread-" + tid + "] i6 mismatch, expected(i6)=" + rawI6 + ", actual(i6)=" + i6);
            ok = false;
        }

        if (i7 != 99) {
            PierceDemoLogUtil.logE("ArgMulti7Test [Thread-" + tid + "] i7 mismatch, expected(i7)=" + 99 + ", actual(i7)=" + i7);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

    @Override
    public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
        super.beforeCall(callFrame);
        callFrame.args[6] = 99;
    }
}
