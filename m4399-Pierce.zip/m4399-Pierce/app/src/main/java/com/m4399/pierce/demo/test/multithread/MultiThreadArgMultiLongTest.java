package com.m4399.pierce.demo.test.multithread;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class MultiThreadArgMultiLongTest extends MultiThreadTest {
    private long rawL1 = 1L, rawL2 = 2L, rawL3 = 3L, rawL4 = 4L,
            rawL5 = 5L, rawL6 = 6L, rawL7 = 7L, rawL8 = 8L,
            rawL9 = 9L, rawL10 = 10L, rawL11 = 11L, rawL12 = 12L;

    public MultiThreadArgMultiLongTest() {

    }

    public static void hook() {
        hook(new MultiThreadArgMultiLongTestMethodHook(), MultiThreadArgMultiLongTest.class, "target", long.class, long.class, long.class, long.class,
                long.class, long.class, long.class, long.class, long.class, long.class,
                long.class, long.class);
    }

    @Override
    protected int testImpl() {
        long l1 = 1L;
        long l2 = 2L;
        long l3 = 3L;
        long l4 = 4L;
        long l5 = 5L;
        long l6 = 6L;
        long l7 = 7L;
        long l8 = 8L;
        long l9 = 9L;
        long l10 = 10L;
        long l11 = 11L;
        long l12 = 12L;

        return target(l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12);
    }

    private int target(long l1, long l2, long l3, long l4, long l5, long l6,
                       long l7, long l8, long l9, long l10, long l11, long l12) {
        calleeFunctionEnterCountAdd();
//        LogUtil.log("MultiThreadArgMultiLongTest target enter");

        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l1 != rawL1) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL1 mismatch, expected(rawL1)=" + rawL1 + ", actual(l1)=" + l1);
            ok = false;
        }
        if (l2 != rawL2) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL1 mismatch, expected(rawL2)=" + rawL2 + ", actual(l2)=" + l2);
            ok = false;
        }
        if (l3 != rawL3) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL3 mismatch, expected(rawL3)=" + rawL3 + ", actual(l3)=" + l3);
            ok = false;
        }
        if (l4 != rawL4) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL4 mismatch, expected(rawL4)=" + rawL4 + ", actual(l4)=" + l4);
            ok = false;
        }
        if (l5 != rawL5) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL5 mismatch, expected(rawL5)=" + rawL5 + ", actual(i5)=" + l5);
            ok = false;
        }
        if (l6 != rawL6) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL6 mismatch, expected(rawL6)=" + rawL6 + ", actual(l6)=" + l6);
            ok = false;
        }
        if (l7 != rawL7) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL7 mismatch, expected(rawL7)=" + rawL7 + ", actual(l7)=" + l7);
            ok = false;
        }
        if (l8 != rawL8) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL8 mismatch, expected(rawL8)=" + rawL8 + ", actual(l8)=" + l8);
            ok = false;
        }
        if (l9 != rawL9) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL9 mismatch, expected(rawL9)=" + rawL9 + ", actual(l9)=" + l9);
            ok = false;
        }
        if (l10 != rawL10) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL10 mismatch, expected(rawL10)=" + rawL10 + ", actual(l10)=" + l10);
            ok = false;
        }
        if (l11 != rawL11) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] rawL11 mismatch, expected(rawL11)=" + rawL11 + ", actual(l11)=" + l11);
            ok = false;
        }

        // 这里检测 HOOK 是否生效，把最后一个参数修改成 99
        if (l12 != 99L) {
            PierceDemoLogUtil.logE("MultiThreadArgMultiLongTest [Thread-" + tid + "] l12 mismatch, expected=" + 99L + ", actual(l12)=" + l12);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

    static class MultiThreadArgMultiLongTestMethodHook extends DefaultMethodHook {
        @Override
        public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
            super.beforeCall(callFrame);
            // 修改最后一个参数检测 hook 是否生效
            callFrame.args[11] = 99L;
        }
    }
}
