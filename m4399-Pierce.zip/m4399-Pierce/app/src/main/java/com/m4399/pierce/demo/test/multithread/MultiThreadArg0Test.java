package com.m4399.pierce.demo.test.multithread;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author canyie
 */
public class MultiThreadArg0Test extends MultiThreadTest {
    public MultiThreadArg0Test() {

    }

    public static void hook() {
        hook(new MultiThreadArg0TestMethodHook(), MultiThreadArg0Test.class, "target", (Class<?>[]) null);
    }

    static class MultiThreadArg0TestMethodHook extends DefaultMethodHook {
        @Override
        public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
            super.afterCall(callFrame);
            callFrame.setResultIfNoException(SUCCESS);
        }
    }

//    //在android 6.0,有些机器
//    //testImpl与target会由于OAT 链接器的代码去重(code deduplication)
//    //dex2oat 把两个方法编译出相同的机器码后，让两个 ArtMethod 的
//    //entry_point_from_compiled_code_ 指向同一份代码。
//    // target arm32 AOT的汇编为4F F0 FF 30 70 47           mov.w r0, #-1       bx lr
//    // target arm64 AOT的汇编为00 00 80 12 C0 03 5F D6     mov w0, #-1         ret
//    // target的inline hook由于字节太小转replace hook,而调用者又不走入口方式，导致hook失效
//    // 除了让target函数体变大外，还要让1.testImpl不能内联target 2.testImpl不能和target同一个入口
//    @Override
//    protected int testImpl() {
//        int ret = target();
//        return ret;
//    }

//    private static int target() {
//        calleeFunctionEnterCountAdd();
////      LogUtil.log("MultiThreadArg0Test.target()");
//        return FAILED;
//    }

    private static AtomicBoolean isTestImplFirstLog = new AtomicBoolean(false);

    @Override
    protected int testImpl() {
        if (isTestImplFirstLog.compareAndSet(false, true)) {
            PierceDemoLogUtil.logI("MultiThreadArg0Test.testImpl() called");
        }
        int ret = target();
        return ret;
    }

    private static AtomicBoolean isTargetFirstLog = new AtomicBoolean(false);

    private static int target() {
        calleeFunctionEnterCountAdd();
        if (isTargetFirstLog.compareAndSet(false, true)) {
            PierceDemoLogUtil.logI("MultiThreadArg0Test.target() called");
        }
        int ret = FAILED;
        return ret;
    }
}
