package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg4Test extends Test {
    public Arg4Test() {
        super("target", int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg4Test.testImpl() called");
        return target(2001361295);
    }

    private static int target(int i) {
        PierceDemoLogUtil.logI("Arg4Test.target() called with arg i " + i);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 2001361295) {
            PierceDemoLogUtil.logE("Arg4Test [Thread-" + tid + "] i mismatch, expected(i)=" + 2001361295 + ", actual(i)=" + i);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
