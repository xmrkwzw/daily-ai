package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8Test extends Test {
    public Arg8Test() {
        super("target", long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8Test.testImpl() called");
        return target(1145141919810L);
    }

    private static int target(long l) {
        PierceDemoLogUtil.logI("Arg8Test.target() called with arg l " + l);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != 1145141919810L) {
            PierceDemoLogUtil.logE("Arg8Test [Thread-" + tid + "] l mismatch, expected(l)=" + 1145141919810L + ", actual(l)=" + l);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
