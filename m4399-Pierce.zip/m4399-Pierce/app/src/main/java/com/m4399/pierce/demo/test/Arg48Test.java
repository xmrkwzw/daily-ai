package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg48Test extends Test {
    public Arg48Test() {
        super("target", int.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg48Test.testImpl() called");
        return target(326646792, 5150256501661869116L);
    }

    private static int target(int i, long l) {
         PierceDemoLogUtil.logI("Arg48Test.target() called with arg i " + i + ", l " + l);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 326646792) {
            PierceDemoLogUtil.logE("Arg48Test [Thread-" + tid + "] i mismatch, expected(i)=" + 326646792 + ", actual(i)=" + i);
            ok = false;
        }
        if (l != 5150256501661869116L) {
            PierceDemoLogUtil.logE("Arg48Test [Thread-" + tid + "] l mismatch, expected(l)=" + 5150256501661869116L + ", actual(l)=" + l);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
