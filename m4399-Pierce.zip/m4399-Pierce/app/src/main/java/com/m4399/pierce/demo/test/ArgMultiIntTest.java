package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class ArgMultiIntTest extends Test {
    private int rawI1 = 1, rawI2 = 2, rawI3 = 3, rawI4 = 4,
            rawI5 = 5, rawI6 = 6, rawI7 = 7, rawI8 = 8,
            rawI9 = 9, rawI10 = 10, rawI11 = 11, rawI12 = 12;

    public ArgMultiIntTest() {
        super("target", int.class, int.class, int.class, int.class,
                int.class, int.class, int.class, int.class, int.class, int.class,
                int.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("ArgMultiIntTest.testImpl() called");
        int i1 = 1;
        int i2 = 2;
        int i3 = 3;
        int i4 = 4;
        int i5 = 5;
        int i6 = 6;
        int i7 = 7;
        int i8 = 8;
        int i9 = 9;
        int i10 = 10;
        int i11 = 11;
        int i12 = 12;
        return target(i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12);
    }

    private int target(int i1, int i2, int i3, int i4, int i5, int i6,
                       int i7, int i8, int i9, int i10, int i11, int i12) {
        PierceDemoLogUtil.logI("ArgMultiIntTest.target() called with arg i1 " + i1 + ", i2 " + i2 + ", i3 " + i3 + ", i4 " + i4 + ", i5 " + i5 + ", i6 " + i6 + ", i7 " + i7 + ", i8 " + i8 + ", i9 " + i9 + ", i10 " + i10 + ", i11 " + i11 + ", i12 " + i12);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i1 != rawI1) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i1 mismatch, expected(i1)=" + rawI1 + ", actual(i1)=" + i1);
            ok = false;
        }
        if (i2 != rawI2) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i2 mismatch, expected(i2)=" + rawI2 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (i3 != rawI3) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i3 mismatch, expected(i3)=" + rawI3 + ", actual(i3)=" + i3);
            ok = false;
        }
        if (i4 != rawI4) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i4 mismatch, expected(i4)=" + rawI4 + ", actual(i4)=" + i4);
            ok = false;
        }
        if (i5 != rawI5) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i5 mismatch, expected(i5)=" + rawI5 + ", actual(i5)=" + i5);
            ok = false;
        }
        if (i6 != rawI6) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i6 mismatch, expected(i6)=" + rawI6 + ", actual(i6)=" + i6);
            ok = false;
        }
        if (i7 != rawI7) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i7 mismatch, expected(i7)=" + rawI7 + ", actual(i7)=" + i7);
            ok = false;
        }
        if (i8 != rawI8) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i8 mismatch, expected(i8)=" + rawI8 + ", actual(i8)=" + i8);
            ok = false;
        }
        if (i9 != rawI9) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i9 mismatch, expected(i9)=" + rawI9 + ", actual(i9)=" + i9);
            ok = false;
        }
        if (i10 != rawI10) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i10 mismatch, expected(i10)=" + rawI10 + ", actual(i10)=" + i10);
            ok = false;
        }
        if (i11 != rawI11) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i11 mismatch, expected(i11)=" + rawI11 + ", actual(i11)=" + i11);
            ok = false;
        }

        if (i12 != 99) {
            PierceDemoLogUtil.logE("ArgMultiIntTest [Thread-" + tid + "] i12 mismatch, expected(i12)=" + 99 + ", actual(i12)=" + i12);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

    @Override
    public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
        super.beforeCall(callFrame);
        // 修改最后一个参数来检测 HOOK 成功
        callFrame.args[11] = 99;
    }
}
