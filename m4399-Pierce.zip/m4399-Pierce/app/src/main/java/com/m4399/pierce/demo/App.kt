package com.m4399.pierce.demo

import android.app.Application
import com.m4399.pierce.core.PierceConfig
import com.m4399.pierce.demo.util.PierceDemoFileLogUtil

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        PierceDemoFileLogUtil.init(this.applicationContext)
        PierceConfig.debugLog = false
        PierceConfig.debuggable = BuildConfig.DEBUG
        PierceConfig.disableHooks = false
        PierceConfig.context = this;
    }
}