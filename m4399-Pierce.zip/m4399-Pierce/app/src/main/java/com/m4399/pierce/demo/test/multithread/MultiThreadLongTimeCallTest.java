package com.m4399.pierce.demo.test.multithread;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class MultiThreadLongTimeCallTest extends MultiThreadTest {
    public MultiThreadLongTimeCallTest() {

    }

    public static void hook() {
        hook(new MultiThreadLongTimeTestMethodHook(), MultiThreadLongTimeCallTest.class, "target", (Class<?>[]) null);
    }


    @Override
    protected int testImpl() {
        int ret = target();
        return ret;
    }

    static class MultiThreadLongTimeTestMethodHook extends DefaultMethodHook {
        @Override
        public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
            super.afterCall(callFrame);
            callFrame.setResultIfNoException(SUCCESS);
        }
    }


    private static int target() {
        calleeFunctionEnterCountAdd();
        try {
            Thread.sleep(1000 * 30);
            PierceDemoLogUtil.logI("MultiThreadLongTimeCallTest.target() sleep end");
            return FAILED;
        } catch (Exception exception) {
            return FAILED;
        }
    }
}
