package com.m4399.pierce.demo.test;

import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.Arrays;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.core.callback.MethodHook;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public abstract class Test extends MethodHook {
    public static final int IGNORED = 0;
    public static final int SUCCESS = 1;
    public static final int FAILED = -1;
    private Member target;
    private boolean hookEnabled = true;
    public boolean isCallbackInvoked;

    protected Test() {
    }

    protected Test(String targetName, Class<?>... paramTypes) {
        init(getClass(), targetName, paramTypes);
    }

    protected Test(Class<?> c, String targetName, Class<?>... paramTypes) {
        init(c, targetName, paramTypes);
    }

    protected Test(Member target) {
        this.target = target;
    }

    private void init(Class<?> c, String targetName, Class<?>... paramTypes) {
        if (targetName != null) {
            target = ReflectionHelper.getMethod(c, targetName, paramTypes);
        } else {
            target = ReflectionHelper.getConstructor(c, paramTypes);
        }
    }

    public void setHookEnabled(boolean enabled) {
        this.hookEnabled = enabled;
    }

    public int run() {
        if (hookEnabled) {
            long entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(target);
            MethodHook.Unhook unhook = Pierce.hook(target, this);
            long entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(target);

            int result = testImpl();
            if (result != SUCCESS) {
                long entryPointWhenRun = Pierce.getArtMethodEntryPointFromCompiledCode(target);
                PierceDemoLogUtil.logE("Test.run() result != SUCCESS " + "target="
                        + target + "\n entryPointBeforeHook=" + String.format("%#x", entryPointBeforeHook)
                        + "\n entryPointAfterHook=" + String.format("%#x", entryPointAfterHook)
                        + "\n entryPointWhenRun=" + String.format("%#x", entryPointWhenRun));

                if (this instanceof Test) {
                    assembleTestImpl();
                }

                String dump = Pierce.dump();
                PierceDemoLogUtil.logE("Test.run() result != SUCCESS " + "target="
                        + target + " pierceDump=\n" + dump);
            }
            unhook.unhook();
            return result;
        } else {
            return testImpl();
        }
    }

    public void assembleTestImpl() {
        try {
            Method testImplMethod = this.getClass().getDeclaredMethod("testImpl");
            String hexString = Pierce.getArtMethodEntryPointHexString(testImplMethod, 0x2000);
            PierceDemoLogUtil.logE(this.getClass().getName() + " assemble testImplMethod=" + testImplMethod + "\n" + hexString);
        } catch (NoSuchMethodException e) {
            PierceDemoLogUtil.logE("Test assembleTestImpl Could not find testImpl method in " + this.getClass().getName(), e);
        }
    }

    protected abstract int testImpl();

    @Override
    public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
        isCallbackInvoked = true;
        PierceDemoLogUtil.logI("Before " + target.getDeclaringClass().getName() + "."
                + target.getName() + "() with thisObject " + callFrame.thisObject
                + " and args " + Arrays.toString(callFrame.args));
    }

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        PierceDemoLogUtil.logI("After " + target.getDeclaringClass().getName() + "."
                + target.getName() + "(): result " + callFrame.getResult()
                + " throwable " + callFrame.getThrowable());
    }
}
