package com.m4399.pierce.demo.test.multithread;

//import android.util.Log;
//
//import com.m4399.pierce.core.LockStatics;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.core.callback.MethodHook;
import com.m4399.pierce.demo.test.ReflectionHelper;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class MultiThreadTest {
    public static final int IGNORED = 0;
    public static final int SUCCESS = 1;
    public static final int FAILED = -1;

    private static final class HookInfo {
        //写入 volatile 变量后，其他线程马上能看到这个值
        //编译器 / CPU 不会把对 volatile 变量的读写重排序（保证顺序）
        private volatile Member target;
        private volatile long entryPointBeforeHook;
        private volatile long entryPointAfterHook;

        public HookInfo() {
            target = null;
            entryPointBeforeHook = -1;
            entryPointAfterHook = -1;
        }

        public void setHookInfo(Member target,
                                long entryPointBeforeHook,
                                long entryPointAfterHook) {
            this.target = target;
            this.entryPointBeforeHook = entryPointBeforeHook;
            this.entryPointAfterHook = entryPointAfterHook;
        }

        public Member getTarget() {
            return target;
        }

        public long getArtMethodEntryPointFromCompiledCodeBeforeHook() {
            return entryPointBeforeHook;
        }

        public long getArtMethodEntryPointFromCompiledCodeAfterHook() {
            return entryPointAfterHook;
        }
    }

    private static final ConcurrentHashMap<Class<?>, HookInfo> mapHookInfos =
            new ConcurrentHashMap<>();

    private static HookInfo getHookInfo(Class<?> c) {
        HookInfo info = mapHookInfos.get(c);
        if (info != null) {
            return info;
        }
        HookInfo newInfo = new HookInfo();
        HookInfo old = mapHookInfos.putIfAbsent(c, newInfo);
        return old != null ? old : newInfo;
    }

    protected MultiThreadTest() {
    }

    public static void hook(MethodHook methodHook, Class<?> c, String targetName, Class<?>... paramTypes) {
        Member target = null;
        if (targetName != null) {
            target = ReflectionHelper.getMethod(c, targetName, paramTypes);
        } else {
            target = ReflectionHelper.getConstructor(c, paramTypes);
        }

        long entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(target);
        MethodHook.Unhook unhook = Pierce.hook(target, methodHook);
        long entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(target);
        HookInfo info = getHookInfo(c);
        info.setHookInfo(target, entryPointBeforeHook, entryPointAfterHook);
    }

    public void assembleTestImpl() {
        try {
            Method testImplMethod = this.getClass().getDeclaredMethod("testImpl");
            String hexString = Pierce.getArtMethodEntryPointHexString(testImplMethod, 0x2000);
            PierceDemoLogUtil.logE(this.getClass().getName() + " assemble testImplMethod=" + testImplMethod + "\n" + hexString);
        } catch (NoSuchMethodException e) {
            PierceDemoLogUtil.logE("MultiThreadTest assembleTestImpl Could not find testImpl method in " + this.getClass().getName(), e);
        }
    }

    private static final AtomicBoolean sAssembledParse = new AtomicBoolean(false);

    public int run() throws RuntimeException {
//        LockStatics.callerFunctionEnterCount.incrementAndGet();
//        PierceDemoLogUtil.logI("pierce,testImpl enter callerFunctionEnterCount=" + LockStatics.callerFunctionEnterCount.get()
//                + " callerFunctionLeaveCount=" + LockStatics.callerFunctionLeaveCount.get()
//                + " bridgeFunctionEnterCount=" + LockStatics.bridgeFunctionEnterCount.get()
//                + " bridgeReleaseLockCount=" + LockStatics.bridgeReleaseLockCount.get()
//                + " calleeFunctionEnterCount=" + LockStatics.calleeFunctionEnterCount.get()
//        );

        //压力测试GC移动问题
        Runtime.getRuntime().gc();

        int result = testImpl();
//        LockStatics.callerFunctionLeaveCount.incrementAndGet();
//        PierceDemoLogUtil.logI("pierce,testImpl leave callerFunctionEnterCount=" + LockStatics.callerFunctionEnterCount.get()
//                + " callerFunctionLeaveCount=" + LockStatics.callerFunctionLeaveCount.get()
//                + " bridgeFunctionEnterCount=" + LockStatics.bridgeFunctionEnterCount.get()
//                + " bridgeReleaseLockCount=" + LockStatics.bridgeReleaseLockCount.get()
//                + " calleeFunctionEnterCount=" + LockStatics.calleeFunctionEnterCount.get()
//        );
        if (result != SUCCESS) {
            HookInfo info = getHookInfo(getClass());
            Member target = info.getTarget();
            long entryPointBeforeHook = info.getArtMethodEntryPointFromCompiledCodeBeforeHook();
            long entryPointAfterHook = info.getArtMethodEntryPointFromCompiledCodeAfterHook();
            long entryPointWhenRun = Pierce.getArtMethodEntryPointFromCompiledCode(target);
            PierceDemoLogUtil.logE("MultiThreadTest.run() result != SUCCESS " + "target="
                    + target + "\n entryPointBeforeHook=" + String.format("%#x", entryPointBeforeHook)
                    + "\n entryPointAfterHook=" + String.format("%#x", entryPointAfterHook)
                    + "\n entryPointWhenRun=" + String.format("%#x", entryPointWhenRun));

            if (this instanceof MultiThreadTest) {
                assembleTestImpl();
            }

            String dump = Pierce.dump();
            PierceDemoLogUtil.logE("MultiThreadTest.run() result != SUCCESS " + "target="
                    + target + " pierceDump=\n" + dump);

            throw new RuntimeException(this.getClass().getName() + " result != SUCCESS");
        }
        return result;
    }

    protected abstract int testImpl();

    protected static void calleeFunctionEnterCountAdd() {
//        LockStatics.calleeFunctionEnterCount.incrementAndGet();
    }

    static class DefaultMethodHook extends MethodHook {
        @Override
        public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
//             LogUtil.log("Before " + callFrame.method.getDeclaringClass().getName() + "."
//                    +  callFrame.method.getName() + "() with thisObject " + callFrame.thisObject
//                    + " and args " + Arrays.toString(callFrame.args));
        }

        @Override
        public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
//             LogUtil.log("After " +  callFrame.method.getDeclaringClass().getName() + "."
//                    +  callFrame.method.getName() + "(): result " + callFrame.getResult()
//                    + " throwable " + callFrame.getThrowable());
        }
    }
}
