package com.m4399.pierce.demo.test.multithread;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.Callable;

/**
 * @author canyie
 */
public class MultiThreadProxyTest extends MultiThreadTest {
    private static Callable<Long> callable;

    static {
        // noinspection unchecked
        callable = (Callable<Long>) Proxy.newProxyInstance(MultiThreadProxyTest.class.getClassLoader(),
                new Class<?>[]{Callable.class},
                new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        String methodName = method.getName();
                        switch (methodName) {
                            case "toString": {
                                return proxy.getClass().getName()
                                        + "@"
                                        + Integer.toHexString(proxy.hashCode());
                            }
                            case "hashCode": {
                                return System.identityHashCode(proxy);
                            }
                            case "equals": {
                                return args != null && proxy == args[0];
                            }
                            case "call": {
                                MultiThreadTest.calleeFunctionEnterCountAdd();
//                                 LogUtil.log("Proxy method called...");
                                return 114514L;
                            }
                            default: {
                                throw new UnsupportedOperationException("MultiThreadProxyTest Unexpected method: " + method);
                                //return method.invoke(proxy, args); // 极少数情况尝试默认反射行为
                            }
                        }


                    }
                });
    }

    public MultiThreadProxyTest() {

    }

    public static void hook() {
        hook(new MultiThreadProxyTestMethodHook(), callable.getClass(), "call", (Class<?>[]) null);
    }

    @Override
    protected int testImpl() {
        try {
            Long callRet = callable.call();
            int ret = SUCCESS;
            if (callRet != 1919810L) {
                long tid = Thread.currentThread().getId();
                PierceDemoLogUtil.logE("MultiThreadProxyTest.testImpl() [Thread-" + tid + "] callRet mismatch, expected(callRet)=" + 1919810L + ", actual(callRet)=" + callRet);
                ret = FAILED;
            }
            return ret;
        } catch (Exception e) {
            PierceDemoLogUtil.logE("MultiThreadProxyTest.testImpl() Proxy call threw exception", e);
            return FAILED;
        }
    }

    static class MultiThreadProxyTestMethodHook extends DefaultMethodHook {
        @Override
        public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
            super.afterCall(callFrame);
            if (Long.valueOf(114514L).equals(callFrame.getResult())) {
                callFrame.setResult(1919810L);
            }
        }
    }

}
