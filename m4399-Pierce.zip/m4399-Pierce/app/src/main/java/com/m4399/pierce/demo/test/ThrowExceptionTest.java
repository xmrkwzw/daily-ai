package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class ThrowExceptionTest extends Test {
    public ThrowExceptionTest() {
        super("target", (Class<?>[]) null);
    }

    @Override
    protected int testImpl() {
        try {
            target();
            return FAILED;
        } catch (MyEx e) {
            int ret = e.b ? SUCCESS : FAILED;
            if (ret == SUCCESS) {
                PierceDemoLogUtil.logI("ThrowExceptionTest testImpl catch e=" + e + " e.b=" + e.b, e);
            } else {
                PierceDemoLogUtil.logE("ThrowExceptionTest testImpl catch e=" + e + " e.b=" + e.b, e);
            }
            return ret;
        }
    }

    private static void target() throws MyEx {
        throw new MyEx();
    }

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        super.afterCall(callFrame);
        MyEx e = (MyEx) callFrame.getThrowable();
        e.b = true;
    }

    static class MyEx extends Exception {
        boolean b = false;
    }
}
