package com.m4399.pierce.demo

//import com.m4399.pierce.demo.test.HookReplacementPrimitiveTest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.bytedance.sdk.openadsdk.TTAdConfig
import com.bytedance.sdk.openadsdk.TTAdConstant
import com.bytedance.sdk.openadsdk.TTAdSdk
import com.bytedance.sdk.openadsdk.TTAppContextHolder
import com.m4399.pierce.core.Pierce
import com.m4399.pierce.core.callback.MethodHook
import com.m4399.pierce.core.callback.MethodReplacement
import com.m4399.pierce.demo.test.Arg0Test
import com.m4399.pierce.demo.test.Arg4444Test
import com.m4399.pierce.demo.test.Arg4448Test
import com.m4399.pierce.demo.test.Arg444Test
import com.m4399.pierce.demo.test.Arg4484Test
import com.m4399.pierce.demo.test.Arg4488Test
import com.m4399.pierce.demo.test.Arg448Test
import com.m4399.pierce.demo.test.Arg44Test
import com.m4399.pierce.demo.test.Arg4844Test
import com.m4399.pierce.demo.test.Arg4848Test
import com.m4399.pierce.demo.test.Arg484Test
import com.m4399.pierce.demo.test.Arg4884Test
import com.m4399.pierce.demo.test.Arg4888Test
import com.m4399.pierce.demo.test.Arg488Test
import com.m4399.pierce.demo.test.Arg48Test
import com.m4399.pierce.demo.test.Arg4Test
import com.m4399.pierce.demo.test.Arg8444Test
import com.m4399.pierce.demo.test.Arg8448Test
import com.m4399.pierce.demo.test.Arg844Test
import com.m4399.pierce.demo.test.Arg8484Test
import com.m4399.pierce.demo.test.Arg8488Test
import com.m4399.pierce.demo.test.Arg848Test
import com.m4399.pierce.demo.test.Arg84Test
import com.m4399.pierce.demo.test.Arg8844Test
import com.m4399.pierce.demo.test.Arg8848Test
import com.m4399.pierce.demo.test.Arg884Test
import com.m4399.pierce.demo.test.Arg8884Test
import com.m4399.pierce.demo.test.Arg8888Test
import com.m4399.pierce.demo.test.Arg888Test
import com.m4399.pierce.demo.test.Arg88Test
import com.m4399.pierce.demo.test.Arg8Test
import com.m4399.pierce.demo.test.ArgLLLILLZZZIIILTest
import com.m4399.pierce.demo.test.ArgMulti7Test
import com.m4399.pierce.demo.test.ArgMulti8Test
import com.m4399.pierce.demo.test.ArgMultiIntStaticTest
import com.m4399.pierce.demo.test.ArgMultiIntTest
import com.m4399.pierce.demo.test.ArgMultiLongTest
import com.m4399.pierce.demo.test.ConstructorTest
import com.m4399.pierce.demo.test.DirectMethodTest
import com.m4399.pierce.demo.test.DirectRegisterJNITest
import com.m4399.pierce.demo.test.DynamicLookupJNITest
import com.m4399.pierce.demo.test.HookPrimitiveTest
import com.m4399.pierce.demo.test.InnerThrowExceptionTest
import com.m4399.pierce.demo.test.NonStaticTest
import com.m4399.pierce.demo.test.NotInitedTest
import com.m4399.pierce.demo.test.ProxyTest
import com.m4399.pierce.demo.test.Test
import com.m4399.pierce.demo.test.ThrowExceptionTest
import com.m4399.pierce.demo.test.multithread.MultiThreadGCTest
import com.m4399.pierce.demo.test.multithread.MultiThreadLongTimeCallTest
import com.m4399.pierce.demo.test.multithread.MultiThreadRunTest
import com.m4399.pierce.demo.util.PierceDemoLogUtil
import java.lang.reflect.Method
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {

    lateinit var logView: TextView

    public companion object {
        private var isTestHookSuccess: AtomicBoolean = AtomicBoolean(false)
        private var isTestLongTimeFuncSuccess: AtomicBoolean = AtomicBoolean(false)
        private var isTestHookMultiRunSuccess: AtomicBoolean = AtomicBoolean(false)
        private var isToutiaoHook: AtomicBoolean = AtomicBoolean(false)
        private var isTestHookBtnEnabled = true
        private var isTestHookMultiRunBtnEnabled = true
        private var isTestLongTimeBtnEnabled = true

        var jsonObjectPutCallCount: AtomicInteger = AtomicInteger(0)
        var isFirstLongTimeHook: AtomicBoolean = AtomicBoolean(false)
    }

    private fun showTestHookTextViewTip() {
        if (isTestHookSuccess.get()
            && isTestLongTimeFuncSuccess.get()
            && isTestHookMultiRunSuccess.get()
        ) {
            val tvTestHookTip = findViewById<TextView>(R.id.tvTestHookTip)
            tvTestHookTip.text = "测试正常";
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        System.loadLibrary("test1")
        logView = findViewById(R.id.log)
        testHook(null)
        testLongTimeFunc(null)
        testHookMultiRun(null)
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private fun log(msg: String) {
        PierceDemoLogUtil.logI(msg)
        // 允许子线程调用：UI 更新切回主线程
        if (Thread.currentThread() === mainLooper.thread) {
            logView.append("\n$msg")
        } else {
            mainHandler.post {
                logView.append("\n$msg")
            }
        }
    }

    private fun replaceMethod() {
        throw RuntimeException("替换replaceMethod方法的Hook失败")
    }

    private external fun test1(): String;


    private var beforeCall = false
    private var originalExecuted = false
    private var afterCall = false

    private fun reset() {
        beforeCall = false
        originalExecuted = false
        afterCall = false
    }

    private fun wrapMethod() {
        //Release 打包
        //notice: code size of target method is too small size=12,it should be size=16,it may lead to hook failure.
        for (i in 1..5) {
            originalExecuted = true
        }
        originalExecuted = true
    }

    fun testHookMultiRun(view: View?) {
        val testHookMultiRunBtn = findViewById<Button>(R.id.btnTestHookMultiRun)
        if (!isTestHookMultiRunBtnEnabled) {
            return
        }

        isTestHookMultiRunBtnEnabled = false
        testHookMultiRunBtn.isEnabled = false
        testHookMultiRunBtn.alpha = 0.5f

        // 启动线程执行 hook + 测试
        Thread {
            try {
                log("testHookMultiRun thread enter")

//                //androidVersion>=7.0 androidVersion<11.0强制走inline hook
//                Pierce.ensureInitialized()
//                Pierce.setHookMode(Pierce.HookMode.INLINE)
//                Pierce.setJitCompilationAllowed(true, true)
//
                MultiThreadRunTest.hook()

                MultiThreadRunTest.run()
                // 所有任务完成后，切回主线程恢复按钮
                testHookMultiRunBtn.post {
                    isTestHookMultiRunBtnEnabled = true
                    testHookMultiRunBtn.isEnabled = true
                    testHookMultiRunBtn.alpha = 1.0f

                    PierceDemoLogUtil.logI("testHookMultiRun success")
                    isTestHookMultiRunSuccess.set(true)
                    showTestHookTextViewTip()
                }
            } catch (e: Throwable) {
                PierceDemoLogUtil.logE("testHookMultiRun error, e=$e", e)
                throw e
            }
        }.start()
    }


    fun testLongTimeFunc(view: View?) {
        val testLongTimeBtn = findViewById<Button>(R.id.btnLongTimeFunc)
        if (!isTestLongTimeBtnEnabled) {
            return
        }

        isTestLongTimeBtnEnabled = false
        testLongTimeBtn.isEnabled = false
        testLongTimeBtn.alpha = 0.5f

        Thread {
            try {
                log("testLongTimeFunc thread enter")

                if (isFirstLongTimeHook.compareAndSet(false, true)) {
                    MultiThreadGCTest.hook()
                    MultiThreadLongTimeCallTest.hook()
                }

                //测试各个阶段GC是否正常
                val argMultiGCTest = MultiThreadGCTest()
                argMultiGCTest.run()

                //测试长时间禁止GC的情况
                val multiThreadLongTimeCallTest = MultiThreadLongTimeCallTest()
                multiThreadLongTimeCallTest.run()

                testLongTimeBtn.post {
                    isTestLongTimeBtnEnabled = true
                    testLongTimeBtn.isEnabled = true
                    testLongTimeBtn.alpha = 1.0f

                    PierceDemoLogUtil.logI("testLongTimeFunc success")
                    isTestLongTimeFuncSuccess.set(true)
                    showTestHookTextViewTip()
                }
            } catch (e: Throwable) {
                PierceDemoLogUtil.logE("testLongTimeFunc error, e=$e", e)
                throw e
            }
        }.start()
    }

    fun disableTestHookTouTiaoBtn() {
        // UI 操作切主线程，业务逻辑允许子线程调用
        runOnUiThread {
            val testHookToutiaoBtn = findViewById<Button>(R.id.btnTestHookTouTiao)
            testHookToutiaoBtn.isEnabled = false
            testHookToutiaoBtn.alpha = 0.5f
        }
    }

    fun testHookTouTiao(view: View?) {
        if (!isToutiaoHook.compareAndSet(false, true)) {
            //头条hook一次
            return;
        }

        disableTestHookTouTiaoBtn()

        //在huawei5s android 5.0 没有任何hook 只有TouTiao本身动作，会发生堆内存一直涨
        //2026-04-01 11:33:55.321   880-898   art                     pid-880                              I  Background sticky concurrent mark sweep GC freed 17800(2MB) AllocSpace objects, 0(0B) LOS objects, 6% free, 26MB/28MB, paused 7.165ms total 51.128ms
        //2026-04-01 11:33:56.239 27069-27089 art                     pid-27069                            I  Background partial concurrent mark sweep GC freed 72643(4MB) AllocSpace objects, 25(500KB) LOS objects, 1% free, 208MB/212MB, paused 6.341ms total 1.486s
        //2026-04-01 11:33:58.379 27069-27089 art                     pid-27069                            I  Background partial concurrent mark sweep GC freed 78077(4MB) AllocSpace objects, 25(500KB) LOS objects, 1% free, 222MB/226MB, paused 6.140ms total 1.626s
        //2026-04-01 11:34:00.634 27069-27089 art                     pid-27069                            I  Background partial concurrent mark sweep GC freed 84350(5MB) AllocSpace objects, 28(560KB) LOS objects, 1% free, 237MB/241MB, paused 7.567ms total 1.762s
        //2026-04-01 11:34:02.881 27069-27089 art                     pid-27069                            I  Background partial concurrent mark sweep GC freed 81464(5MB) AllocSpace objects, 23(460KB) LOS objects, 1% free, 250MB/254MB, paused 2.307ms total 1.758s
        //2026-04-01 11:34:02.881 27069-27088 art                     pid-27069                            I  WaitForGcToComplete blocked for 1.642s for cause HeapTrim
        //2026-04-01 11:34:02.883 27069-27230 art                     pid-27069                            I  WaitForGcToComplete blocked for 322.932ms for cause Alloc
        //2026-04-01 11:34:02.884 27069-27116 art                     pid-27069                            I  WaitForGcToComplete blocked for 322.993ms for cause Alloc
        //2026-04-01 11:34:04.822 27069-27089 art                     pid-27069                            I  Clamp target GC heap from 257MB to 256MB
        //2026-04-01 11:34:04.822 27069-27089 art                     pid-27069                            I  Background partial concurrent mark sweep GC freed 47087(2MB) AllocSpace objects, 3(60KB) LOS objects, 0% free, 253MB/256MB, paused 2.509ms total 1.502s
        //2026-04-01 11:34:04.822 27069-27230 art                     pid-27069                            I  WaitForGcToComplete blocked for 1.338s for cause Alloc
        //2026-04-01 11:34:04.823 27069-27116 art                     pid-27069                            I  WaitForGcToComplete blocked for 1.339s for cause Alloc
        //2026-04-01 11:34:06.503 27069-27089 art                     pid-27069                            I  Clamp target GC heap from 259MB to 256MB
        //2026-04-01 11:34:06.503 27069-27089 art                     pid-27069                            I  Background partial concurrent mark sweep GC freed 10441(541KB) AllocSpace objects, 3(60KB) LOS objects, 0% free, 255MB/256MB, paused 2.190ms total 1.408s
        //2026-04-01 11:34:06.504 27069-27230 art                     pid-27069                            I  WaitForGcToComplete blocked for 1.391s for cause Alloc
        testTouTiaoJSON()
        if ((Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP)
            || (Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP_MR1)
        ) {
            //不让多线程压力测试
            runOnUiThread {
                val multiRunBtn = findViewById<Button>(R.id.btnTestHookMultiRun)
                isTestHookMultiRunBtnEnabled = false
                multiRunBtn.isEnabled = false
                multiRunBtn.alpha = 0.5f
            }

            log("android 5.0/5.1 heap memory will grow in TouTiao,it will lead to anr or crash");
        } else {
            log("testTouTiaoJSON Hook")
        }
    }

    fun testHook(view: View?) {
        val testHookBtn = findViewById<Button>(R.id.btnTestHook)
        if (!isTestHookBtnEnabled) {
            //不能采用!testHookBtn.isEnabled来判断。因为Activity有可能被重建
            return
        }

        isTestHookBtnEnabled = false
        testHookBtn.isEnabled = false
        testHookBtn.alpha = 0.5f

//        //androidVersion>=7.0 androidVersion<11.0强制走inline hook
//        Pierce.ensureInitialized()
//        Pierce.setHookMode(Pierce.HookMode.INLINE)
//        Pierce.setJitCompilationAllowed(true,true)

        var isTestToutiao = false
        if ((Build.VERSION.SDK_INT != Build.VERSION_CODES.LOLLIPOP)
            && (Build.VERSION.SDK_INT != Build.VERSION_CODES.LOLLIPOP_MR1)
        ) {
            isTestToutiao = true
        }

        if (isTestToutiao) {
            disableTestHookTouTiaoBtn()
        }

        // 启动线程执行 hook + 测试
        Thread {
            try {
                log("TestHook thread enter")
                testThrowExceptionHook()

                testInnerThrowExceptionHook()

                testMethodHook()

                testHookReplaceMethod()

                testMethodReturnValueHook()

                testHookNativeMethod()

                testNonStaticMethodHook()

                testDirectMethodHook()

                testConstructorHook()

                testDynamicLookupJNIHook()

                testDirectRegisterJNIHook()

                testProxyHook()

                testNotInitedHook()

                testArg0Hook()

                testArg4Hook()

                testArg8Hook()

                testArg44Hook()

                testArg48Hook()

                testArg84Hook()

                testArg88Hook()

                testArg444Hook()

                testArg448Hook()

                testArg484Hook()

                testArg488Hook()

                testArg844Hook()

                testArg848Hook()

                testArg884Hook()

                testArg888Hook()

                testArg4444Hook()

                testArg4448Hook()

                testArg4484Hook()

                testArg4488Hook()

                testArg4844Hook()

                testArg4848Hook()

                testArg4884Hook()

                testArg4888Hook()

                testArg8444Hook()

                testArg8448Hook()

                testArg8484Hook()

                testArg8488Hook()

                testArg8844Hook()

                testArg8848Hook()

                testArg8884Hook()

                testArg8888Hook()

                testArgMulti7Hook()

                testArgMulti8Hook()

                testArgMultiIntHook()

                testArgMultiIntStaticHook()

                testArgMultiLongHook()

                testArgLLLILLZZZIIILHook()

                testHookPrimitive()

//        testHookReplacementPrimitive()

                if (isTestToutiao) {
                    testHookTouTiao(view)
                }

                testHookBtn.post {
                    //只需测试一次，不需要恢复按钮
                    Toast.makeText(this, "success", Toast.LENGTH_LONG).show()

                    log("TestHook success")
                    isTestHookSuccess.set(true)
                    showTestHookTextViewTip()
                }
            } catch (e: Throwable) {
                PierceDemoLogUtil.logE("TestHook error, e=$e", e)
                throw e
            }
        }.start()
    }

    /**
     * 测试函数Hook后的返回值
     */
    private fun testMethodReturnValueHook() {
        val testBean = TestBean()

        log("测试String方法替换返回值")
        var testStringMethod = TestBean::class.java.getDeclaredMethod("testString")
        var entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testStringMethod)
        Pierce.hook(testStringMethod, object : MethodHook() {
            override fun beforeCall(callFrame: Pierce.CallFrame) {
                callFrame.result = "returnEarly"
                callFrame.returnEarly = true
            }

//            override fun afterCall(callFrame: Pierce.CallFrame) {
//                callFrame.result = "returnEarly"
//            }
        })
        var entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testStringMethod)
        val callerMethod = javaClass.getDeclaredMethod("testMethodReturnValueHook")

        if ("returnEarly" != testBean.testString()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testStringMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testString() error ,testBean.testString()=" + testBean.testString() + " != " + "returnEarly"
            )
        }

        log("测试Boolean方法替换返回值")
        val testBooleanMethod = TestBean::class.java.getDeclaredMethod("testBoolean")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testBooleanMethod)
        Pierce.hook(testBooleanMethod, object : MethodHook() {
            override fun afterCall(callFrame: Pierce.CallFrame) {
                callFrame.result = true
            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testBooleanMethod)
        if (true != testBean.testBoolean()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testBooleanMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testBoolean() error ,testBean.testBoolean()=" + testBean.testBoolean() + " != " + true
            )
        }

        log("测试Char方法替换返回值")
        val testCharMethod = TestBean::class.java.getDeclaredMethod("testChar")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testCharMethod)
        Pierce.hook(testCharMethod, object : MethodHook() {
            override fun afterCall(callFrame: Pierce.CallFrame) {
                callFrame.result = Char.MAX_VALUE
            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testCharMethod)
        if (Char.MAX_VALUE != testBean.testChar()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testCharMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testChar() error ,testBean.testChar()=" + testBean.testChar() + " != " + Char.MAX_VALUE
            )
        }

        log("测试Byte方法替换返回值")
        val testByteMethod = TestBean::class.java.getDeclaredMethod("testByte")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testByteMethod)
        Pierce.hook(testByteMethod, object : MethodHook() {
            override fun afterCall(callFrame: Pierce.CallFrame) {
                callFrame.result = Byte.MAX_VALUE
            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testByteMethod)
        if (Byte.MAX_VALUE != testBean.testByte()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testByteMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testByte() error ,testBean.testByte()=" + testBean.testByte() + " != " + Byte.MAX_VALUE
            )
        }

        log("测试Short方法替换返回值")
        val testShortMethod = TestBean::class.java.getDeclaredMethod("testShort")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testShortMethod)
        Pierce.hook(testShortMethod, object : MethodHook() {
            override fun beforeCall(callFrame: Pierce.CallFrame) {
                callFrame.result = Short.MAX_VALUE
                callFrame.returnEarly = true
            }

//            override fun afterCall(callFrame: Pierce.CallFrame) {
//                callFrame.result = Short.MAX_VALUE
//            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testShortMethod)
        if (Short.MAX_VALUE != testBean.testShort()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testShortMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testShort() error ,testBean.testShort()=" + testBean.testShort() + " != " + Short.MAX_VALUE
            )
        }

        log("测试Int方法替换返回值")
        val testIntMethod = TestBean::class.java.getDeclaredMethod("testInt")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testIntMethod)
        Pierce.hook(testIntMethod, object : MethodHook() {
            override fun afterCall(callFrame: Pierce.CallFrame) {
                callFrame.result = Int.MAX_VALUE
            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testIntMethod)
        if (Int.MAX_VALUE != testBean.testInt()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testIntMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testInt() error ,testBean.testInt()=" + testBean.testInt() + " != " + Int.MAX_VALUE
            )
        }

        log("测试Float方法替换返回值")
        val testFloatMethod = TestBean::class.java.getDeclaredMethod("testFloat")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testFloatMethod)
        Pierce.hook(testFloatMethod, object : MethodHook() {
            override fun afterCall(callFrame: Pierce.CallFrame) {
                callFrame.result = Float.MAX_VALUE
            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testFloatMethod)
        if (Float.MAX_VALUE != testBean.testFloat()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testFloatMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testFloat() error ,testBean.testFloat()=" + testBean.testFloat() + " != " + Float.MAX_VALUE
            )
        }

        log("测试Double方法替换返回值")
        val testDoubleMethod = TestBean::class.java.getDeclaredMethod("testDouble")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testDoubleMethod)
        Pierce.hook(testDoubleMethod, object : MethodHook() {
            override fun afterCall(callFrame: Pierce.CallFrame) {
                callFrame.result = Double.MAX_VALUE
            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testDoubleMethod)
        if (Double.MAX_VALUE != testBean.testDouble()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testDoubleMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testDouble() error ,testBean.testDouble()=" + testBean.testDouble() + " != " + Double.MAX_VALUE
            )
        }

        log("测试Long方法replaceCall替换返回值")
        val testLongMethod = TestBean::class.java.getDeclaredMethod("testLong")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testLongMethod)
        Pierce.hook(testLongMethod, object : MethodReplacement() {
            override fun replaceCall(callFrame: Pierce.CallFrame): Any {
                return Long.MAX_VALUE
            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testLongMethod)
        if (Long.MAX_VALUE != testBean.testLong()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testLongMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testLong() error ,testBean.testLong()=" + testBean.testLong() + " != " + Long.MAX_VALUE
            )
        }

        log("测试Int private 替换返回值")
        val testPrivateIntMethod = TestBean::class.java.getDeclaredMethod("testPrivateInt")
        entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(testPrivateIntMethod)
        Pierce.hook(testPrivateIntMethod, object : MethodHook() {
            override fun afterCall(callFrame: Pierce.CallFrame) {
                callFrame.result = Int.MAX_VALUE
            }
        })
        entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(testPrivateIntMethod)
        if (Int.MAX_VALUE != testBean.testPrivateInt()) {
            logAndThrowException(
                "testMethodReturnValueHook",
                testPrivateIntMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "testBean.testPrivateInt() error ,testBean.testPrivateInt()=" + testBean.testPrivateInt() + " != " + Int.MAX_VALUE
            )
        }
    }

    private fun logAndThrowException(
        methodName: String,
        targetMethod: Method,
        entryPointBeforeHook: Long,
        entryPointAfterHook: Long,
        callerMethod: Method,
        failLog: String
    ) {
        var tip = ""
        if (targetMethod == null) {
            tip = "logAndThrowException $methodName targetMethod is null "
            PierceDemoLogUtil.logE(tip)
            throw RuntimeException(tip)
        }

        if (callerMethod == null) {
            tip = "logAndThrowException $methodName callerMethod is null "
            PierceDemoLogUtil.logE(tip)
            throw RuntimeException(tip)
        }

        val entryPointWhenRun = Pierce.getArtMethodEntryPointFromCompiledCode(targetMethod)
        tip = buildString {
            append("logAndThrowException ")
            append(methodName)
            append(" error, ")
            append(failLog)
            append("\n")

            append(" targetMethod=")
            append(targetMethod)
            append("\n")

            append(" entryPointBeforeHook=")
            append(String.format("%#x", entryPointBeforeHook))
            append("\n")

            append(" entryPointAfterHook=")
            append(String.format("%#x", entryPointAfterHook))
            append("\n")

            append(" entryPointWhenRun=")
            append(String.format("%#x", entryPointWhenRun))
        }

        PierceDemoLogUtil.logE(tip)

        val hexString = Pierce.getArtMethodEntryPointHexString(callerMethod, 0x2000)
        PierceDemoLogUtil.logE("logAndThrowException ${methodName} callerMethod=${callerMethod} hexString=\n" + hexString)


        val dump = Pierce.dump()
        PierceDemoLogUtil.logE("logAndThrowException ${methodName} callerMethod=${callerMethod} pierceDump=\n" + dump)

        throw RuntimeException(tip)
    }

    private fun testMethodHook() {
        log("测试Hook方法的before和after")
        val wrapMethod = javaClass.getDeclaredMethod("wrapMethod")
        val entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(wrapMethod)
        Pierce.hook(wrapMethod, object : MethodHook() {
            override fun beforeCall(callFrame: Pierce.CallFrame) {
                beforeCall = true
            }

            override fun afterCall(callFrame: Pierce.CallFrame) {
                afterCall = true
            }
        })
        val entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(wrapMethod)
        wrapMethod()
        val callerMethod = javaClass.getDeclaredMethod("testMethodHook")
        checkAfterCall(
            "testMethodHook",
            wrapMethod,
            entryPointBeforeHook,
            entryPointAfterHook,
            callerMethod,
            true,
            true,
            true
        )
    }

    /**
     * 测试替换整个方法内容的Hook
     */
    private fun testHookReplaceMethod() {
        log("测试Hook方法的整个替换")
        val replaceMethod = javaClass.getDeclaredMethod("replaceMethod")

        val entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(replaceMethod)
        Pierce.hook(replaceMethod, MethodReplacement.DO_NOTHING)
        val entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(replaceMethod)

        try {
            replaceMethod()
        } catch (t: Throwable) {
            val callerMethod = javaClass.getDeclaredMethod("testHookReplaceMethod")
            logAndThrowException(
                "testHookReplaceMethod",
                replaceMethod,
                entryPointBeforeHook,
                entryPointAfterHook,
                callerMethod,
                "replaceMethod hook failed."
            )
        }
    }

    /**
     * 测试Native方法的Hook, 包含before 和 after
     */
    private fun testHookNativeMethod() {
        log("测试Hook Native 方法 before 和 after")
        val test1Method = javaClass.getDeclaredMethod("test1")
        val entryPointBeforeHook = Pierce.getArtMethodEntryPointFromCompiledCode(test1Method)
        Pierce.hook(test1Method, object : MethodHook() {
            override fun beforeCall(callFrame: Pierce.CallFrame) {
                beforeCall = true
            }

            override fun afterCall(callFrame: Pierce.CallFrame) {
                afterCall = true
            }
        })
        val entryPointAfterHook = Pierce.getArtMethodEntryPointFromCompiledCode(test1Method)
        test1()
        val callerMethod = javaClass.getDeclaredMethod("testHookNativeMethod")
        checkAfterCall(
            "testHookNativeMethod",
            test1Method,
            entryPointBeforeHook,
            entryPointAfterHook,
            callerMethod,
            true,
            false,
            true
        )
    }

    private fun checkAfterCall(
        methodName: String,
        targetMethod: Method,
        entryPointBeforeHook: Long,
        entryPointAfterHook: Long,
        callerMethod: Method,
        before: Boolean,
        original: Boolean,
        after: Boolean
    ) {
        var tip = ""
        if (targetMethod == null) {
            tip = "checkAfterCall $methodName targetMethod is null "
            PierceDemoLogUtil.logE(tip)
            throw RuntimeException(tip)
        }

        if (callerMethod == null) {
            tip = "checkAfterCall $methodName callerMethod is null "
            PierceDemoLogUtil.logE(tip)
            throw RuntimeException(tip)
        }

        if ((beforeCall != before)
            || (originalExecuted != original)
            || (afterCall != after)
        ) {
            val entryPointWhenRun = Pierce.getArtMethodEntryPointFromCompiledCode(targetMethod)
            tip = buildString {
                append("checkAfterCall ")
                append(methodName)
                append(" error, beforeCall=")
                append(beforeCall)
                append(" expectedBefore=")
                append(before)

                append(" originalExecuted=")
                append(originalExecuted)
                append(" expectedOriginal=")
                append(original)

                append(" afterCall=")
                append(afterCall)
                append(" expectedAfter=")
                append(after)
                append("\n")

                append(" targetMethod=")
                append(targetMethod)
                append("\n")

                append(" entryPointBeforeHook=")
                append(String.format("%#x", entryPointBeforeHook))
                append("\n")

                append(" entryPointAfterHook=")
                append(String.format("%#x", entryPointAfterHook))
                append("\n")

                append(" entryPointWhenRun=")
                append(String.format("%#x", entryPointWhenRun))
            }

            PierceDemoLogUtil.logE(tip)

            val hexString = Pierce.getArtMethodEntryPointHexString(callerMethod, 0x2000)
            PierceDemoLogUtil.logE("checkAfterCall ${methodName} callerMethod=${callerMethod} hexString=\n" + hexString)

            val dump = Pierce.dump()
            PierceDemoLogUtil.logE("checkAfterCall ${methodName} callerMethod=${callerMethod} pierceDump=\n" + dump)

            throw RuntimeException(tip)
        }

        reset()
    }

    private fun testNonStaticMethodHook() {
        log("test Non-Static Method Hook")
        var test = NonStaticTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Non-Static Method Hook failed")
        }
    }

    private fun testDirectMethodHook() {
        log("test Direct Method Hook")
        var test = DirectMethodTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Direct Method Hook failed")
        }
    }

    private fun testConstructorHook() {
        log("test Constructor Hook")
        var test = ConstructorTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Constructor Hook failed")
        }
    }

    private fun testDynamicLookupJNIHook() {
        log("test Dynamic Lookup JNI Hook")
        var test = DynamicLookupJNITest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Dynamic Lookup JNI Hook failed")
        }
    }

    private fun testDirectRegisterJNIHook() {
        log("test Direct Register JNI Hook")
        var test = DirectRegisterJNITest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Direct Register JNI Hook failed")
        }
    }

    private fun testProxyHook() {
        log("test Proxy Hook")
        var test = ProxyTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Proxy Hook failed")
        }
    }

    private fun testThrowExceptionHook() {
        log("test Throw Exception Hook")
        var test = ThrowExceptionTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Throw Exception Hook failed")
        }
    }

    private fun testInnerThrowExceptionHook() {
        log("test Inner Throw Exception Hook")
        var test = InnerThrowExceptionTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Inner Throw Exception Hook failed")
        }
    }

    private fun testNotInitedHook() {
        log("test Not Inited Hook")
        var test = NotInitedTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Not Inited Hook failed")
        }
    }

    private fun testArg0Hook() {
        log("test Arg0 Hook")
        var test = Arg0Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg0 Hook failed")
        }
    }

    private fun testArg4Hook() {
        log("test Arg4 Hook")
        var test = Arg4Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4 Hook failed")
        }
    }

    private fun testArg8Hook() {
        log("test Arg8 Hook")
        var test = Arg8Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8 Hook failed")
        }
    }

    private fun testArg44Hook() {
        log("test Arg44 Hook")
        var test = Arg44Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg44 Hook failed")
        }
    }

    private fun testArg48Hook() {
        log("test Arg48 Hook")
        var test = Arg48Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg48 Hook failed")
        }
    }

    private fun testArg84Hook() {
        log("test Arg84 Hook")
        var test = Arg84Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg84 Hook failed")
        }
    }

    private fun testArg88Hook() {
        log("test Arg88 Hook")
        var test = Arg88Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg88 Hook failed")
        }
    }

    private fun testArg444Hook() {
        log("test Arg444 Hook")
        var test = Arg444Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg444 Hook failed")
        }
    }

    private fun testArg448Hook() {
        log("test Arg448 Hook")
        var test = Arg448Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg448 Hook failed")
        }
    }

    private fun testArg484Hook() {
        log("test Arg484 Hook")
        var test = Arg484Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg484 Hook failed")
        }
    }

    private fun testArg488Hook() {
        log("test Arg488 Hook")
        var test = Arg488Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg488 Hook failed")
        }
    }

    private fun testArg844Hook() {
        log("test Arg844 Hook")
        var test = Arg844Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg844 Hook failed")
        }
    }

    private fun testArg848Hook() {
        log("test Arg848 Hook")
        var test = Arg848Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg848 Hook failed")
        }
    }

    private fun testArg884Hook() {
        log("test Arg884 Hook")
        var test = Arg884Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg884 Hook failed")
        }
    }

    private fun testArg888Hook() {
        log("test Arg888 Hook")
        var test = Arg888Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg888 Hook failed")
        }
    }

    private fun testArg4444Hook() {
        log("test Arg4444 Hook")
        var test = Arg4444Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4444 Hook failed")
        }
    }

    private fun testArg4448Hook() {
        log("test Arg4448 Hook")
        var test = Arg4448Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4448 Hook failed")
        }
    }

    private fun testArg4484Hook() {
        log("test Arg4484 Hook")
        var test = Arg4484Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4484 Hook failed")
        }
    }

    private fun testArg4488Hook() {
        log("test Arg4488 Hook")
        var test = Arg4488Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4488 Hook failed")
        }
    }

    private fun testArg4844Hook() {
        log("test Arg4844 Hook")
        var test = Arg4844Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4844 Hook failed")
        }
    }

    private fun testArg4848Hook() {
        log("test Arg4848 Hook")
        var test = Arg4848Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4848 Hook failed")
        }
    }

    private fun testArg4884Hook() {
        log("test Arg4884 Hook")
        var test = Arg4884Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4884 Hook failed")
        }
    }

    private fun testArg4888Hook() {
        log("test Arg4888 Hook")
        var test = Arg4888Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg4888 Hook failed")
        }
    }

    private fun testArg8444Hook() {
        log("test Arg8444 Hook")
        var test = Arg8444Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8444 Hook failed")
        }
    }

    private fun testArg8448Hook() {
        log("test Arg8448 Hook")
        var test = Arg8448Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8448 Hook failed")
        }
    }

    private fun testArg8484Hook() {
        log("test Arg8484 Hook")
        var test = Arg8484Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8484 Hook failed")
        }
    }

    private fun testArg8488Hook() {
        log("test Arg8488 Hook")
        var test = Arg8488Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8488 Hook failed")
        }
    }

    private fun testArg8844Hook() {
        log("test Arg8844 Hook")
        var test = Arg8844Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8844 Hook failed")
        }
    }

    private fun testArg8848Hook() {
        log("test Arg8848 Hook")
        var test = Arg8848Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8848 Hook failed")
        }
    }

    private fun testArg8884Hook() {
        log("test Arg8884 Hook")
        var test = Arg8884Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8884 Hook failed")
        }
    }

    private fun testArg8888Hook() {
        log("test Arg8888 Hook")
        var test = Arg8888Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Arg8888 Hook failed")
        }
    }

    private fun testArgMulti7Hook() {
        log("test ArgMulti7 Hook")
        var test = ArgMulti7Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test ArgMulti7 Hook failed")
        }
    }

    private fun testArgMulti8Hook() {
        log("test ArgMulti8 Hook")
        var test = ArgMulti8Test()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test ArgMulti8 Hook failed")
        }
    }

    private fun testArgMultiIntHook() {
        log("test ArgMultiInt Hook")
        var test = ArgMultiIntTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test ArgMultiInt Hook failed")
        }
    }

    private fun testArgMultiLongHook() {
        log("test ArgMultiLong Hook")
        var test = ArgMultiLongTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test ArgMultiLong Hook failed")
        }
    }

    private fun testArgMultiIntStaticHook() {
        log("test ArgMultiIntStatic Hook")
        var test = ArgMultiIntStaticTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test ArgMultiIntStatic Hook failed")
        }
    }

    private fun testArgLLLILLZZZIIILHook() {
        log("test ArgLLLILLZZZIIIL Hook")
        var test = ArgLLLILLZZZIIILTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test ArgLLLILLZZZIIIL Hook failed")
        }
    }

    private fun testHookPrimitive() {
        log("test Hook Primitive")
        var test = HookPrimitiveTest()
        var testResult = test.run()
        if (testResult != Test.SUCCESS) {
            throw RuntimeException("test Hook Primitive failed")
        }
    }

//    private fun testHookReplacementPrimitive() {
//        //经过测试 Android 5.1,Android 7.1 会HOOK失败
//        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
//            return
//        }
//
//        log("test Hook Replacement Primitive")
//        var test = HookReplacementPrimitiveTest()
//        var testResult = test.run()
//        if (testResult != Test.SUCCESS) {
//            throw RuntimeException("test Hook Replacement Primitive failed")
//        }
//    }

    private fun testTouTiaoJSON() {
        val jsonClazz = MainActivity::class.java.classLoader.loadClass("org.json.JSONObject")
        val putMethod = jsonClazz.getDeclaredMethod("put", String::class.java, Object::class.java)
        Pierce.hook(putMethod, object : MethodHook() {
            override fun beforeCall(callFrame: Pierce.CallFrame) {
                jsonObjectPutCallCount.incrementAndGet()
                val args = callFrame.args
                if ("testJsonKey" == args[0] && args[1] is String && args[1] == "testJsonKey") {
                    args[1] = "hookTestJsonKey"
                }
            }
        })
        TTAppContextHolder.setContext(this)
        val ttConfig = TTAdConfig.Builder().appId("5001121").useTextureView(true)
            .appName("APP测试媒体").titleBarTheme(TTAdConstant.TITLE_BAR_THEME_DARK).allowShowNotify(true)
            .allowShowPageWhenScreenLock(true)
            .debug(true)
            .directDownloadNetworkType(TTAdConstant.NETWORK_STATE_WIFI, TTAdConstant.NETWORK_STATE_3G)
            .supportMultiProcess(false)
            .build()
        TTAdSdk.init(this, ttConfig, object : TTAdSdk.InitCallback {
            override fun success() {
                PierceDemoLogUtil.logI("TouTiao init success")
            }

            override fun fail(p0: Int, p1: String) {
                PierceDemoLogUtil.logI("TouTiao init error code:$p0, msg:$p1")
            }
        })
    }

}