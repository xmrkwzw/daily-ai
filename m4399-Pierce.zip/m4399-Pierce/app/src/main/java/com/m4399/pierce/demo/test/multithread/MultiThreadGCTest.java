package com.m4399.pierce.demo.test.multithread;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class MultiThreadGCTest extends MultiThreadTest {
    public MultiThreadGCTest() {

    }

    public static void hook() {
        hook(new MultiThreadGCTestMethodHook(), MultiThreadGCTest.class, "target", (Class<?>[]) null);
    }


    @Override
    protected int testImpl() {
        //延迟1S,5S调用GC
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Runtime.getRuntime().gc();

                    Thread.sleep(1000);
                    Runtime.getRuntime().gc();

                    Thread.sleep(5000);
                    Runtime.getRuntime().gc();
                } catch (InterruptedException e) {
                    PierceDemoLogUtil.logE("MultiThreadGCTest.testImpl thread run occur e=" + e, e);
                }
            }
        }).start();
        int ret = target();
        return ret;
    }

    static class MultiThreadGCTestMethodHook extends DefaultMethodHook {
        @Override
        public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
            super.beforeCall(callFrame);
            Runtime.getRuntime().gc();
        }

        @Override
        public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
            super.afterCall(callFrame);
            Runtime.getRuntime().gc();
            callFrame.setResultIfNoException(SUCCESS);
        }
    }


    private static int target() {
        calleeFunctionEnterCountAdd();
        try {
            for (int i = 0; i < 100; i++) {
                if ((i == 20) || (i == 40) || (i == 80)) {
                    Runtime.getRuntime().gc();
                }
                Thread.sleep(100);
            }

            PierceDemoLogUtil.logI("MultiThreadGCTest.target() finish");
            return FAILED;
        } catch (Exception exception) {
            return FAILED;
        }
    }
}
