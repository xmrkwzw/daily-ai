package com.m4399.pierce.demo.test.multithread;

import android.content.Intent;
import android.os.Bundle;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class MultiThreadArgLLLILLZZZIIILTest extends MultiThreadTest {
    private Object rawO;
    private Intent rawIntent1;
    private Bundle rawBundle1;
    private int rawI1, rawI2, rawI3, rawI4;
    private boolean rawZ1, rawZ2, rawZ3;
    private String rawS1, rawS2;

    public MultiThreadArgLLLILLZZZIIILTest() {

    }

    public static void hook() {
        hook(new MultiThreadArgLLLILLZZZIIILTestMethodHook(), MultiThreadArgLLLILLZZZIIILTest.class, "target", Object.class, Intent.class, int.class, String.class,
                Bundle.class, boolean.class, boolean.class, boolean.class, int.class, int.class,
                int.class, String.class);
    }

    @Override
    protected int testImpl() {
        rawO = new Object();
        rawIntent1 = new Intent();
        rawIntent1.setAction("1234" + System.currentTimeMillis());
        rawI1 = -1228444048;
        rawS1 = "rawS1";
        rawBundle1 = new Bundle();
        rawZ1 = true;
        rawZ2 = false;
        rawZ3 = true;
        rawI2 = 2071284368;
        rawI3 = 119479230;
        rawI4 = 258800479;
        rawS2 = "rawS2";
        return target(rawO, rawIntent1, rawI1, rawS1, rawBundle1, rawZ1, rawZ2, rawZ3, rawI2, rawI3,
                rawI4, rawS2);
    }

    private int target(Object o, Intent intent1, int i1, String s1, Bundle b1, boolean z1,
                       boolean z2, boolean z3, int i2, int i3, int i4, String s2) {
        calleeFunctionEnterCountAdd();
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (rawO != o) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] o mismatch, expected(rawO)=" + rawO + ", actual(arg)=" + o);
            ok = false;
        }
        if (rawIntent1 != intent1) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] intent1 mismatch, expected(rawIntent1)=" + rawIntent1 + ", actual(arg)=" + intent1);
            ok = false;
        }
        if (rawI1 != i1) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] i1 mismatch, expected(rawI1)=" + rawI1 + ", actual(arg)=" + i1);
            ok = false;
        }
        if (rawS1 != s1) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] s1 mismatch, expected(rawS1)=" + rawS1 + ", actual(arg)=" + s1);
            ok = false;
        }
        if (rawBundle1 != b1) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] b1 mismatch, expected(rawBundle1)=" + rawBundle1 + ", actual(arg)=" + b1);
            ok = false;
        }
        if (rawZ1 != z1) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] z1 mismatch, expected(rawZ1)=" + rawZ1 + ", actual(arg)=" + z1);
            ok = false;
        }
        if (rawZ2 != z2) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] z2 mismatch, expected(rawZ2)=" + rawZ2 + ", actual(arg)=" + z2);
            ok = false;
        }
        if (rawZ3 != z3) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] z3 mismatch, expected(rawZ3)=" + rawZ3 + ", actual(arg)=" + z3);
            ok = false;
        }
        if (rawI2 != i2) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] i2 mismatch, expected(rawI2)=" + rawI2 + ", actual(arg)=" + i2);
            ok = false;
        }
        if (rawI3 != i3) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] i3 mismatch, expected(rawI3)=" + rawI3 + ", actual(arg)=" + i3);
            ok = false;
        }
        if (rawI4 != i4) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] i4 mismatch, expected(rawI4)=" + rawI4 + ", actual(arg)=" + i4);
            ok = false;
        }

        if (!"rawS5".equals(s2)) {
            PierceDemoLogUtil.logE("MultiThreadArgLLLILLZZZIIILTest [Thread-" + tid + "] s2 mismatch, expected(s2)=" + "rawS5" + ", actual(arg)=" + s2);
            ok = false;
        }

        return ok ? SUCCESS : FAILED;
    }

    static class MultiThreadArgLLLILLZZZIIILTestMethodHook extends DefaultMethodHook {
        @Override
        public void beforeCall(Pierce.CallFrame callFrame) throws Throwable {
            super.beforeCall(callFrame);

            // 给最后一个参数设置新的值
            callFrame.args[11] = "rawS5";
        }
    }

}
