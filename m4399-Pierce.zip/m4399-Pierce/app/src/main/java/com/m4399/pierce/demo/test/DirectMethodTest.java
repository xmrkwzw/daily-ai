package com.m4399.pierce.demo.test;

import com.m4399.pierce.core.Pierce;
import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class DirectMethodTest extends Test {
    public DirectMethodTest() {
        super("target", (Class<?>[]) null);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("DirectMethodTest.testImpl() called");
        boolean targetRet = target();
        int ret = SUCCESS;
        if (!targetRet) {
            long tid = Thread.currentThread().getId();
            PierceDemoLogUtil.logE("DirectMethodTest.testImpl() [Thread-" + tid + "] targetRet mismatch, expected(targetRet)=" + true + ", actual(targetRet)=" + targetRet);
            ret = FAILED;
        }
        return ret;
    }

    /* private methods are direct method */
    private boolean target() {
        PierceDemoLogUtil.logI("DirectMethodTest.target() called");
        return false;
    }

    @Override
    public void afterCall(Pierce.CallFrame callFrame) throws Throwable {
        super.afterCall(callFrame);
        callFrame.setResultIfNoException(true);
    }
}
