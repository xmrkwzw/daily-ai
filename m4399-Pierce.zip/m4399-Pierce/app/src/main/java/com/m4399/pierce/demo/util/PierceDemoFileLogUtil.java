package com.m4399.pierce.demo.util;

import android.content.Context;
import android.util.Log;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.app.ActivityManager;
import java.util.List;

public class PierceDemoFileLogUtil {
    private static final String TAG = "PierceDemoFileLogUtil";
    private static final String logDirPath = "/pluginGame/logs";
    private static final String logFilePrefix = "pierce_demo_log_";
    private static final ThreadLocal<SimpleDateFormat> simpleDateFormat =
            new ThreadLocal<SimpleDateFormat>() {
                @Override
                protected SimpleDateFormat initialValue() {
                    //每个线程首次调用 simpleDateFormat.get() 时执行此方法，
                    //懒创建该线程独有的 SimpleDateFormat 实例。同一线程后续调用复用同一实例。
                    return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
                }
            };

    private static BufferedWriter bufferedWriter;
    private static boolean nullWarnLogged = false;

    public static synchronized void init(Context context) {
        if (context == null) {
            return;
        }

        if (bufferedWriter != null) {
            Log.w(TAG, "init have been done,ignored");
            return;
        }

        try {
            File externalFilesDir = context.getExternalFilesDir(null);
            if (externalFilesDir == null) {
                Log.w(TAG, "init getExternalFilesDir(null) return null.");
                return;
            }

            String dirFilePath = externalFilesDir.getAbsolutePath() + logDirPath;
            File dirFile = new File(dirFilePath);
            if (!dirFile.exists() && !dirFile.mkdirs()) {
                Log.w(TAG, "init " + dirFile.getAbsolutePath() + " mkdirs() failed.");
                return;
            }

            String processName = currentProcessName(context);
            SimpleDateFormat fileNameDateFormat = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss", Locale.US);
            String fileNameTime = fileNameDateFormat.format(new Date());
            int pid = android.os.Process.myPid();
            File file = new File(dirFile, logFilePrefix + fileNameTime + "_" + pid + "_" + processName + ".log");
            bufferedWriter = new BufferedWriter(new FileWriter(file, false));

            Log.i(TAG, "init success, file=" + file.getAbsolutePath());
        } catch (Throwable t) {
            Log.e(TAG, "init failed", t);
        }
    }

    private static String currentProcessName(Context ctx) {
        int pid = android.os.Process.myPid();
        String processName = "pid_" + pid;
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                List<ActivityManager.RunningAppProcessInfo> list = am.getRunningAppProcesses();
                if (list != null) {
                    for (ActivityManager.RunningAppProcessInfo info : list) {
                        if (info.pid == pid) {
                            processName = info.processName;
                            break;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "currentProcessName failed", t);
        }
        return processName;
    }

    public static synchronized void write(String level, String tag, String msg, Throwable msgThrowable) {
        if (bufferedWriter == null) {
            if (!nullWarnLogged) {
                Log.e(TAG, "bufferedWriter is null");
                nullWarnLogged = true;
            }
            return;
        }
        try {
            // 格式：2026-06-08 11:37:51.404  1668-1690 TAG I msg
            bufferedWriter.write(simpleDateFormat.get().format(new Date()));
            bufferedWriter.write("  ");
            bufferedWriter.write(String.valueOf(android.os.Process.myPid()));
            bufferedWriter.write('-');
            bufferedWriter.write(String.valueOf(android.os.Process.myTid()));
            bufferedWriter.write(' ');
            bufferedWriter.write(tag);
            bufferedWriter.write(' ');
            bufferedWriter.write(level);
            bufferedWriter.write(' ');
            bufferedWriter.write(msg == null ? "null" : msg);
            bufferedWriter.newLine();
            if (msgThrowable != null) {
                bufferedWriter.write(Log.getStackTraceString(msgThrowable));
            }
            bufferedWriter.flush();
        } catch (Throwable t) {
            Log.e(TAG, "write failed", t);
        }
    }
}
