package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg8448Test extends Test {
    public Arg8448Test() {
        super("target", long.class, int.class, int.class, long.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg8448Test.testImpl() called");
        return target(Long.MAX_VALUE, -179762943, -997519764, Long.MIN_VALUE);
    }

    private static int target(long l, int i, int i2, long l2) {
        PierceDemoLogUtil.logI("Arg8448Test.target() called with arg l " + l + ", i " + i + ", i2 " + i2 + ", l2 " + l2);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (l != Long.MAX_VALUE) {
            PierceDemoLogUtil.logE("Arg8448Test [Thread-" + tid + "] l mismatch, expected(l)=" + Long.MAX_VALUE + ", actual(l)=" + l);
            ok = false;
        }
        if (i != -179762943) {
            PierceDemoLogUtil.logE("Arg8448Test [Thread-" + tid + "] i mismatch, expected(i)=" + -179762943 + ", actual(i)=" + i);
            ok = false;
        }
        if (i2 != -997519764) {
            PierceDemoLogUtil.logE("Arg8448Test [Thread-" + tid + "] i2 mismatch, expected(i2)=" + -997519764 + ", actual(i2)=" + i2);
            ok = false;
        }
        if (l2 != Long.MIN_VALUE) {
            PierceDemoLogUtil.logE("Arg8448Test [Thread-" + tid + "] l2 mismatch, expected(l2)=" + Long.MIN_VALUE + ", actual(l2)=" + l2);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
