package com.m4399.pierce.demo.test;

import com.m4399.pierce.demo.util.PierceDemoLogUtil;

/**
 * @author canyie
 */
public class Arg484Test extends Test {
    public Arg484Test() {
        super("target", int.class, long.class, int.class);
    }

    @Override
    protected int testImpl() {
        PierceDemoLogUtil.logI("Arg484Test.testImpl() called");
        return target(777777777, 8804591237687636085L, -1);
    }

    private static int target(int i, long l, int i3) {
        PierceDemoLogUtil.logI("Arg484Test.target() called with arg i " + i + ", l " + l + ", i3 " + i3);
        boolean ok = true;
        long tid = Thread.currentThread().getId();

        if (i != 777777777) {
            PierceDemoLogUtil.logE("Arg484Test [Thread-" + tid + "] i mismatch, expected(i)=" + 777777777 + ", actual(i)=" + i);
            ok = false;
        }
        if (l != 8804591237687636085L) {
            PierceDemoLogUtil.logE("Arg484Test [Thread-" + tid + "] l mismatch, expected(l)=" + 8804591237687636085L + ", actual(l)=" + l);
            ok = false;
        }
        if (i3 != -1) {
            PierceDemoLogUtil.logE("Arg484Test [Thread-" + tid + "] i3 mismatch, expected(i3)=" + -1 + ", actual(i3)=" + i3);
            ok = false;
        }
        return ok ? SUCCESS : FAILED;
    }

}
